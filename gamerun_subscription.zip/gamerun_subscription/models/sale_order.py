# -*- coding: utf-8 -*-

import logging

from dateutil.relativedelta import relativedelta

from odoo import models, api, fields, Command, _
from odoo.exceptions import UserError, ValidationError
import base64

_logger = logging.getLogger(__name__)


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    @api.depends('start_date', 'state', 'next_invoice_date', 'is_1time_subscription')
    def _compute_last_invoice_date(self):
        for order in self:
            last_date = order.next_invoice_date and order.plan_id.billing_period and order.next_invoice_date - order.plan_id.billing_period
            start_date = order.start_date or fields.Date.today()
            if order.is_1time_subscription:
                last_date = start_date
            if order.state == 'sale' and last_date and last_date >= start_date:
                order.last_invoice_date = last_date
            else:
                order.last_invoice_date = False

    deposit_order_id = fields.Many2one('sale.order', string="Deposit Order", index=True)
    is_1time_subscription = fields.Boolean("One-time subscription")

    @api.depends('order_line', 'order_line.recurring_invoice')
    def _compute_has_recurring_line(self):
        recurring_product_orders = self.order_line.filtered(lambda l: l.product_id.recurring_invoice and not l.subscription_deposit_value and not l.force_skip_recurring).order_id
        recurring_product_orders.has_recurring_line = True
        (self - recurring_product_orders).has_recurring_line = False

    def _cart_update_order_line(self, product_id, quantity, order_line, **kwargs):
        product = self.env['product.product'].browse(product_id)

        # Extract selected_plan_id at the top level to ensure it's always available
        selected_plan_id = kwargs.get('plan_id', False)

        # Handle both naming conventions for deposit values
        deposit_value = kwargs.get('subscription_deposit_value', 0) or kwargs.get('deposit_value', 0)
        deposit_type = kwargs.get('subscription_deposit_type') or kwargs.get('deposit_type')
        calendar_booking_id = kwargs.get('calendar_booking_id', False)
        event_ticket_price = kwargs.get('event_ticket_price', 0)
        auto_payment_enabled = kwargs.get('auto_payment_enabled', False)

        if product.recurring_invoice and product.allow_initial_deposit:
            # Validate minimum deposit
            min_deposit = product.initial_deposit_value
            deposit_value = float(deposit_value)
            if quantity and deposit_type:
                if product.initial_deposit_type == 'percentage':
                    if deposit_value < min_deposit:
                        raise ValidationError(_('Deposit percentage must be at least %s%%') % min_deposit)
                else:
                    if deposit_value < min_deposit:
                        raise ValidationError(_('Deposit amount must be at least $%s') % min_deposit)

            if calendar_booking_id:
                calendar_booking = self.env['calendar.booking'].sudo().browse(calendar_booking_id)
                appointment_type = calendar_booking.appointment_type_id
                payment_end_date = calendar_booking.start - relativedelta(days=appointment_type.subscription_payment_duration)
                if appointment_type.is_single_subscription and payment_end_date.date() <= fields.Date.today():
                    if deposit_type == 'percentage' and deposit_value != 100.0:
                        raise ValidationError(_('Deposit should be 100%'))

                    if deposit_type == 'usd' and deposit_value != product.list_price:
                        raise ValidationError(_('Deposit amount must be 100% of the price'))

            if order_line and order_line.event_id and order_line.event_id.subscription_payment_duration:
                event_start_date = order_line.event_id.date_begin.date()
                payment_duration = order_line.event_id.subscription_payment_duration
                payment_deadline = event_start_date - relativedelta(days=payment_duration)
                today = fields.Date.today()

                if today >= payment_deadline:
                    if deposit_type == 'percentage' and deposit_value != 100.0:
                        raise ValidationError(_('Payment deadline has passed for this event. You must pay 100%% as deposit.'))
                    elif deposit_type == 'usd' and deposit_value != product.list_price:
                        raise ValidationError(_('Payment deadline has passed for this event. You must pay the full amount ($%.2f) as deposit.') % product.list_price)

        order_line = super()._cart_update_order_line(product_id, quantity, order_line, **kwargs)

        if product.recurring_invoice and deposit_value > 0 and order_line:
            if selected_plan_id and not order_line.selected_plan_id:
                order_line.selected_plan_id = int(selected_plan_id)
            elif not order_line.selected_plan_id and self.plan_id:
                order_line.selected_plan_id = self.plan_id.id

            self.plan_id = False
        return order_line

    def _prepare_order_line_values(self, product_id, quantity, deposit_type=False, deposit_value=False, **kwargs):
        values = super()._prepare_order_line_values(product_id, quantity, **kwargs)
        product = self.env['product.product'].browse(product_id)

        final_deposit_value = kwargs.get('subscription_deposit_value', 0) or deposit_value or 0
        final_deposit_type = kwargs.get('subscription_deposit_type') or deposit_type
        event_ticket_price = kwargs.get('event_ticket_price', 0)
        auto_payment_enabled = kwargs.get('auto_payment_enabled', False)

        if event_ticket_price > 0:
            values['event_ticket_price'] = event_ticket_price

        values['auto_payment_enabled'] = auto_payment_enabled

        if product.recurring_invoice and final_deposit_value and final_deposit_value > 0:
            min_deposit = product.initial_deposit_value
            final_deposit_value = float(final_deposit_value)
            if product.initial_deposit_type == 'percentage':
                if final_deposit_value < min_deposit:
                    raise UserError(_('Deposit percentage must be at least %s%%') % min_deposit)
            else:
                if final_deposit_value < min_deposit:
                    raise UserError(_('Deposit amount must be at least $%s.') % min_deposit)

            event_id = kwargs.get('event_id')
            if event_id:
                event = self.env['event.event'].browse(event_id)
                if event.subscription_payment_duration:
                    event_start_date = event.date_begin.date()
                    payment_duration = event.subscription_payment_duration
                    payment_deadline = event_start_date - relativedelta(days=payment_duration)
                    today = fields.Date.today()

                    if today >= payment_deadline:
                        if final_deposit_type == 'percentage' and final_deposit_value != 100.0:
                            raise UserError(_('Payment deadline has passed for this event. You must pay 100%% as deposit.'))
                        elif final_deposit_type == 'usd' and final_deposit_value != product.list_price:
                            raise UserError(_('Payment deadline has passed for this event. You must pay the full amount ($%.2f) as deposit.') % product.list_price)


            values['subscription_deposit_type'] = final_deposit_type
            values['subscription_deposit_value'] = final_deposit_value
            if kwargs.get('plan_id'):
                values['selected_plan_id'] = int(kwargs.get('plan_id'))
        return values

    def action_confirm(self):
        # implement installment for remaining
        res = super(SaleOrder, self).action_confirm()
        for so in self:
            so._process_subscription_deposits()
        return res

    def _send_order_confirmation_mail(self):
        if self.deposit_order_id:
            return
        return super(SaleOrder, self)._send_order_confirmation_mail()

    def _process_subscription_deposits(self):
        """Process subscription products with initial deposits"""
        deposit_lines = self.order_line.filtered(
            lambda l: l.product_id.recurring_invoice and
                     l.product_id.allow_initial_deposit and
                     l.subscription_deposit_value > 0 and
                     l.subscription_deposit_type
        )

        if not deposit_lines:
            return

        for line in deposit_lines:
            subscription_info = self._get_line_subscription_info(line)
            is_onetime_subscription = subscription_info['auto_payment_enabled']
            subscription_payment_duration = subscription_info['subscription_payment_duration']
            due_date = subscription_info['due_date']
            self._create_deposit_and_subscription_orders(line, is_onetime_subscription, subscription_payment_duration, due_date)

    def _get_line_subscription_info(self, line):
        """Helper method to get subscription payment duration and auto payment status for a line"""
        subscription_payment_duration = None
        auto_payment_enabled = line.auto_payment_enabled
        due_date = None

        if line.event_id and hasattr(line.event_id, 'subscription_payment_duration'):
            subscription_payment_duration = line.event_id.subscription_payment_duration
            if subscription_payment_duration > 0 and auto_payment_enabled:
                due_date = line.event_id.date_begin.date() - relativedelta(days=subscription_payment_duration)
        elif line.calendar_booking_ids and line.calendar_booking_ids[0].appointment_type_id:
            appointment_type = line.calendar_booking_ids[0].appointment_type_id
            if hasattr(appointment_type, 'subscription_payment_duration'):
                subscription_payment_duration = appointment_type.subscription_payment_duration

        return {
            'subscription_payment_duration': subscription_payment_duration,
            'auto_payment_enabled': auto_payment_enabled,
            'event_name': line.event_id.name if line.event_id else None,
            'appointment_name': line.calendar_booking_ids[0].appointment_type_id.name if line.calendar_booking_ids and line.calendar_booking_ids[0].appointment_type_id else None,
            'due_date': due_date
        }

    def _create_deposit_and_subscription_orders(self, line, is_onetime_subscription=False, subscription_payment_duration=None, due_date=None):
        """Create separate orders for deposit and subscription"""

        if line.event_ticket_price > 0.0:
            original_unit_price = line.event_ticket_price
        elif line.product_no_variant_attribute_value_ids:
            original_unit_price = line.product_id.list_price + line.product_id._get_no_variant_attributes_price_extra(line.product_no_variant_attribute_value_ids)
        else:
            original_unit_price = line.product_id.list_price
        original_total_price = original_unit_price * line.product_uom_qty

        deposit_amount = self._calculate_deposit_amount_from_original_price(line, original_total_price)
        remaining_amount = original_total_price - deposit_amount

        if remaining_amount <= 0:
            return

        subscription_order = self._create_subscription_order(line, remaining_amount, is_onetime_subscription, subscription_payment_duration, due_date)
        self._update_line_for_deposit(line, deposit_amount)

        return subscription_order

    def _calculate_deposit_amount(self, line):
        """Calculate the deposit amount based on type (legacy method)"""
        if line.subscription_deposit_type == 'usd':
            return min(line.subscription_deposit_value, line.price_subtotal)
        elif line.subscription_deposit_type == 'percentage':
            percentage = min(line.subscription_deposit_value, 100.0)
            return line.price_subtotal * (percentage / 100.0)
        return 0.0

    def _calculate_deposit_amount_from_original_price(self, line, original_total_price):
        """Calculate the deposit amount based on original product price"""
        if line.subscription_deposit_type == 'usd':
            # For event tickets, subscription_deposit_value is per-unit, so multiply by quantity
            if line.event_ticket_id and line.event_id:
                per_unit_deposit = line.subscription_deposit_value
                total_deposit = per_unit_deposit * line.product_uom_qty
                return min(total_deposit, original_total_price)
            else:
                # For non-event products, treat as total amount
                per_unit_deposit = line.subscription_deposit_value
                total_deposit = per_unit_deposit * line.product_uom_qty
                return min(total_deposit, original_total_price)
        elif line.subscription_deposit_type == 'percentage':
            percentage = min(line.subscription_deposit_value, 100.0)
            if line.event_ticket_id and line.event_id:
                # For event tickets, calculate percentage per ticket and multiply by quantity
                per_unit_price = original_total_price / line.product_uom_qty if line.product_uom_qty > 0 else 0
                per_unit_deposit = per_unit_price * (percentage / 100.0)
                total_deposit = per_unit_deposit * line.product_uom_qty
                return total_deposit
            else:
                # For non-event products, calculate percentage of total
                per_unit_price = original_total_price / line.product_uom_qty if line.product_uom_qty > 0 else 0
                per_unit_deposit = per_unit_price * (percentage / 100.0)
                total_deposit = per_unit_deposit * line.product_uom_qty
                return total_deposit
                # return original_total_price * (percentage / 100.0)
        return 0.0

    def _create_subscription_order(self, line, remaining_amount, is_onetime_subscription=False, subscription_payment_duration=None, due_date=False):
        """Create a subscription order for the remaining amount"""
        plan_id = self._get_subscription_plan(line)

        if not plan_id:
            raise UserError(_('No subscription plan found for product %s. Please configure a subscription plan.') % line.product_id.name)

        is_1time_subscription = is_onetime_subscription
        duration = plan_id.total_duration or 1

        if not is_onetime_subscription:
            new_unit_price = (remaining_amount / line.product_uom_qty) / duration
        else:
            new_unit_price = remaining_amount / line.product_uom_qty
        next_invoice_date = False

        if line.calendar_booking_ids and line.calendar_event_id:
            appointment_type = line.calendar_booking_ids[0].appointment_type_id
            if appointment_type.is_single_subscription:
                end_date = line.calendar_event_id.start - relativedelta(days=appointment_type.subscription_payment_duration)
                is_1time_subscription = True
                new_unit_price = remaining_amount
            else:
                next_invoice_date = due_date or self.date_order.date() + relativedelta(months=1)
                if due_date:
                    end_date = next_invoice_date + relativedelta(days=1)
                else:
                    end_date = next_invoice_date + relativedelta(months=duration) + relativedelta(days=1)
        else:
            next_invoice_date = due_date or self.date_order.date() + relativedelta(months=1)
            if due_date:
                end_date = next_invoice_date + relativedelta(days=1)
            else:
                end_date = next_invoice_date + relativedelta(months=duration) + relativedelta(days=1)

        deposit_order = line.order_id

        # Ensure start_date is not later than next_invoice_date to avoid constraint violation
        start_date = fields.Date.today()
        if next_invoice_date and next_invoice_date < start_date:
            start_date = next_invoice_date

        subscription_vals = {
            'partner_id': self.partner_id.id,
            'partner_invoice_id': self.partner_invoice_id.id,
            'partner_shipping_id': self.partner_shipping_id.id,
            'pricelist_id': self.pricelist_id.id,
            'currency_id': self.currency_id.id,
            'company_id': self.company_id.id,
            'plan_id': plan_id.id,
            'subscription_state': '1_draft',
            'is_subscription': True,
            'is_1time_subscription': is_1time_subscription,
            'origin': self.name,
            'start_date': start_date,
            'next_invoice_date': next_invoice_date,
            'end_date': end_date,
            'deposit_order_id': deposit_order.id
        }

        if deposit_order._check_token_saving_conditions():
            pay_token = deposit_order.transaction_ids.sudo()._get_last().token_id.id
            if pay_token:
                subscription_vals['payment_token_id'] = pay_token

        subscription_order = self.env['sale.order'].create(subscription_vals)

        line_vals = {
            'order_id': subscription_order.id,
            'product_id': line.product_id.id,
            'product_uom_qty': line.product_uom_qty,
            'product_uom': line.product_uom.id,
            'price_unit': new_unit_price,
            'name': line.name + _(' (Subscription)'),
            'tax_id': [Command.set(line.tax_id.ids)],
            'custom_subscription_price': True,
            'event_id': line.event_id.id,
            'event_ticket_id': line.event_ticket_id.id
        }

        subscription_line = self.env['sale.order.line'].create(line_vals)
        if self.state == 'sale':
            subscription_order.action_confirm()

        return subscription_order

    def _get_subscription_plan(self, line):
        """Get subscription plan for the product line"""
        if line.selected_plan_id:
            return line.selected_plan_id

        if self.plan_id:
            return self.plan_id

        if hasattr(line.product_id, 'subscription_plan_id') and line.product_id.subscription_plan_id:
            return line.product_id.subscription_plan_id

        plan = self.env['sale.subscription.plan'].search([
            ('billing_period_value', '=', 1),
            ('billing_period_unit', '=', 'month')
        ], limit=1)

        if not plan:
            plan = self.env['sale.subscription.plan'].create({
                'name': 'Monthly Plan',
                'billing_period_value': 1,
                'billing_period_unit': 'month',
            })

        return plan

    def _update_line_for_deposit(self, line, deposit_amount):
        """Update the order line to reflect only the deposit amount"""
        new_unit_price = deposit_amount / line.product_uom_qty

        line.write({
            'price_unit': new_unit_price,
            'name': line.name + _(' (Initial Deposit)'),
        })
