from odoo import api, fields, models


class ProductTemplate(models.Model):
    _inherit = "product.template"

    allow_initial_deposit = fields.Boolean("Allow initial deposit")
    initial_deposit_type = fields.Selection([
        ('usd', 'USD'),
        ('percentage', 'Percentage(%)')
    ], default='usd')
    initial_deposit_value = fields.Float(string="Deposit Value")

    @api.onchange('initial_deposit_type')
    def onchange_initial_deposit_type(self):
        if not self.initial_deposit_type:
            self.initial_deposit_value = 0.0

    def _get_additionnal_combination_info(self, product_or_template, quantity, date, website):
        res = super()._get_additionnal_combination_info(product_or_template, quantity, date, website)

        if not product_or_template.recurring_invoice:
            return res

        if product_or_template.allow_initial_deposit:
            if res.get('pricings', False):
                for pricing in res['pricings']:
                    pricing['price'] = pricing['table_name']

            if res.get('subscription_default_pricing_price', False):
                res['subscription_default_pricing_price'] = res['subscription_default_pricing_price'].split(':')[0]
            res['price'] = product_or_template.list_price

        return {
            **res,
            'allow_initial_deposit': product_or_template.allow_initial_deposit,
            'initial_deposit_type': product_or_template.initial_deposit_type,
        }
