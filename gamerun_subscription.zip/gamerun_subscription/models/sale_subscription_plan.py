# -*- coding: utf-8 -*-

from odoo import fields, models, api, _


class SaleSubscriptionPlan(models.Model):
    _inherit = 'sale.subscription.plan'

    @api.depends_context('lang')
    @api.depends('billing_period_value', 'billing_period_unit')
    def _compute_billing_period_display_sentence(self):
        for plan in self:
            if plan.billing_period_unit in ['week', 'month', 'year']:
                sentence = ''
            else:
                raise ValueError(f"Invalid Billing Period Unit {plan.billing_period_unit!r}")
            plan.billing_period_display_sentence = sentence

    total_duration = fields.Integer('Total Duration', help='Total number of installments, keep 0 for unlimited until closed/cancelled.', default=0)
