import logging
from odoo import api, fields, models, _

_logger = logging.getLogger(__name__)


class AppointmentType(models.Model):
    _inherit = 'appointment.type'

    is_single_subscription = fields.Boolean("Pay remaining amount in single order")
    subscription_payment_duration = fields.Integer("Pay Full Amount Before (Days)")
