from odoo import fields, models, api, _, Command
from odoo.exceptions import ValidationError


class SaleOrderLine(models.Model):
    _inherit = "sale.order.line"

    subscription_deposit_type = fields.Selection([
        ('usd', 'USD'),
        ('percentage', 'Percentage(%)')
    ])
    subscription_deposit_value = fields.Float(string="Deposit Value")
    event_ticket_price = fields.Float(string="Event Ticket Price")
    force_skip_recurring = fields.Boolean(default=False)
    auto_payment_enabled = fields.Boolean(
        string="Auto Payment Enabled",
        help="Whether automatic payment of remaining amount is enabled for this ticket"
    )
    # Field to store the selected subscription plan for this line
    selected_plan_id = fields.Many2one(
        'sale.subscription.plan',
        string="Selected Subscription Plan",
        help="The subscription plan selected by the user for this product"
    )

    # Field to mark lines that should keep custom pricing
    custom_subscription_price = fields.Boolean(
        string="Custom Subscription Price",
        default=False,
        help="If True, this line will keep its custom price and not be recomputed by subscription pricing"
    )

    @api.depends('product_id', 'product_uom', 'product_uom_qty', 'custom_subscription_price')
    def _compute_price_unit(self):
        """Override to prevent price recomputation for custom subscription prices"""
        lines_to_recompute = self.filtered(lambda l: not l.custom_subscription_price)
        lines_with_custom_price = self - lines_to_recompute

        custom_prices = {}
        for line in lines_with_custom_price:
            custom_prices[line.id] = line.price_unit

        super(SaleOrderLine, lines_to_recompute)._compute_price_unit()

        for line in lines_with_custom_price:
            if line.id in custom_prices:
                line.price_unit = custom_prices[line.id]

    def _get_display_price(self):
        if self.event_ticket_id and self.event_id and self.subscription_deposit_value > 0:
            if self.subscription_deposit_type == 'percentage':
                # For event tickets with percentage deposits, calculate per-unit amount
                price = self.event_ticket_price if self.event_ticket_price > 0 else self.product_id.list_price
                price = self.order_id.company_id.currency_id._convert(price, self.currency_id, self.company_id, fields.date.today())
                deposit_amount = (price * self.subscription_deposit_value / 100.0)
            else:
                # For USD deposits, subscription_deposit_value is already per-unit for event tickets
                deposit_amount = self.subscription_deposit_value
            return deposit_amount
        return super()._get_display_price()

    def get_selected_plan_info(self):
        """Debug method to check selected plan info"""
        return {
            'line_id': self.id,
            'product_name': self.product_id.name,
            'selected_plan_id': self.selected_plan_id.id if self.selected_plan_id else None,
            'selected_plan_name': self.selected_plan_id.name if self.selected_plan_id else None,
            'order_plan_id': self.order_id.plan_id.id if self.order_id.plan_id else None,
            'order_plan_name': self.order_id.plan_id.name if self.order_id.plan_id else None,
        }

    def _init_registrations(self):
        """ Create registrations linked to a sales order line. A sale
        order line has a product_uom_qty attribute that will be the number of
        registrations linked to this line. """
        registrations_vals = []
        for so_line in self:
            if so_line.service_tracking != 'event':
                continue

            if so_line.order_id.deposit_order_id:
                continue

            for _count in range(int(so_line.product_uom_qty) - len(so_line.registration_ids)):
                values = {
                    'sale_order_line_id': so_line.id,
                    'sale_order_id': so_line.order_id.id,
                }
                registrations_vals.append(values)

        if registrations_vals:
            self.env['event.registration'].sudo().create(registrations_vals)
        return True
