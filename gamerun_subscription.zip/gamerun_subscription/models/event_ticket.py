# -*- coding: utf-8 -*-

from odoo import models, fields


class Event(models.Model):
    _inherit = 'event.event'

    allow_installments = fields.Boolean("Allow Installments?")
    is_single_subscription = fields.Boolean("Pay remaining amount in single order")
    subscription_payment_duration = fields.Integer("Pay Full Amount Before (Days)")


class EventTicket(models.Model):
    _inherit = 'event.event.ticket'

    allow_initial_deposit = fields.Boolean("Allow initial deposit", related='product_id.allow_initial_deposit', readonly=True, store=True, index=True)
    initial_deposit_type = fields.Selection(related='product_id.initial_deposit_type', readonly=True, store=True, index=True)
    initial_deposit_value = fields.Float(related='product_id.initial_deposit_value', readonly=True, store=True, index=True)
