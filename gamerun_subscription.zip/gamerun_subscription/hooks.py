from odoo import fields, api, _
from odoo.addons.sale_subscription.models.sale_order import SaleOrder
from odoo.addons.sale_subscription.models.sale_order_line import SaleOrderLine
from odoo.addons.sale_subscription.models.product import product_template
from odoo.exceptions import UserError


def patch_sale_order():
    def action_quotation_send(self):
        if len(self) == 1:
            # Raise error before other popup if used on one SO.
            has_recurring_line = self.order_line.filtered(lambda l: l.product_id.recurring_invoice and not l.subscription_deposit_value)
            if has_recurring_line and not self.plan_id:
                raise UserError(_('Please set a recurring plan on the subscription before sending the email.'))
            if self.plan_id and not has_recurring_line:
                raise UserError(_('Please remove the recurring plan on the subscription before sending the email.'))
        return super(SaleOrder, self).action_quotation_send()

    def _get_pricelist_price(self):
        if self.recurring_invoice:
            if not self.subscription_deposit_value:
                pricing = self.env['sale.subscription.pricing']._get_first_suitable_recurring_pricing(self.product_id, self.order_id.plan_id, self.order_id.pricelist_id)
                if pricing:
                    return pricing.currency_id._convert(pricing.price, self.currency_id, self.company_id, fields.date.today())
            else:
                if self.subscription_deposit_type == 'percentage':
                    # For event tickets with percentage deposits, use event ticket price if available
                    if self.event_ticket_id and self.event_id and hasattr(self, 'event_ticket_price') and self.event_ticket_price > 0:
                        price = self.event_ticket_price
                    else:
                        if self.product_no_variant_attribute_value_ids:
                            price = self.product_id.list_price + self.product_id._get_no_variant_attributes_price_extra(self.product_no_variant_attribute_value_ids)
                        else:
                            price = self.product_id.list_price
                    price = self.order_id.company_id.currency_id._convert(price, self.currency_id, self.company_id, fields.date.today())
                    deposit_amount = (price * self.subscription_deposit_value / 100.0)
                else:
                    deposit_amount = self.subscription_deposit_value
                return deposit_amount
            return super(SaleOrderLine, self)._get_pricelist_price() or self.price_unit
        return super(SaleOrderLine, self)._get_pricelist_price()

    @api.model
    def _get_configurator_price(self, product_or_template, quantity, date, currency, pricelist, plan_id=None, **kwargs):
        price, pricelist_rule_id = super(product_template, self)._get_configurator_price(
            product_or_template, quantity, date, currency, pricelist, plan_id=plan_id, **kwargs
        )
        if (
            product_or_template.recurring_invoice and not product_or_template.allow_initial_deposit
            and (pricing := self._get_pricing(product_or_template, pricelist, plan_id=plan_id))
        ):
            return pricing.currency_id._convert(
                from_amount=pricing.price,
                to_currency=currency,
                company=self.env.company,
                date=date,
            ), False
        return price, pricelist_rule_id

    SaleOrder.action_quotation_send = action_quotation_send
    SaleOrderLine._get_pricelist_price = _get_pricelist_price
    product_template._get_configurator_price = _get_configurator_price

