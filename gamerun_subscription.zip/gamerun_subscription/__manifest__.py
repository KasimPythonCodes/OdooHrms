# noinspection PyStatementEffect
{
    'name': "GameRun Subscription & Payments",
    'author': "GameRun",
    'version': '18.0.1.0.12',
    'category': 'Website',
    'summary': "Subscription & Payments",
    'description': """
    """,
    'website': 'https://gamerun.ai',
    'depends': [
        'website_sale_subscription', 'gamerun_event', 'gamerun_appointment'
    ],
    'data': [
        'views/product_view.xml',
        'views/sale_subscription_plan.xml',
        'views/appointment.xml',
        'views/event_event.xml',
        'views/templates.xml'
    ],
    'assets': {
        'web.assets_frontend': [
            'gamerun_subscription/static/src/js/deposit.js',
            'gamerun_subscription/static/src/js/event_deposit.js',
            'gamerun_subscription/static/src/js/subscription.js',
            'gamerun_subscription/static/src/js/product.js',
            'gamerun_subscription/static/src/xml/pricing_view.xml',
            'gamerun_subscription/static/src/xml/product.xml',
        ]
    },
    'post_load': 'patch_sale_order',
    'auto_install': False,
    'installable': True,
    'license': 'LGPL-3',
}
