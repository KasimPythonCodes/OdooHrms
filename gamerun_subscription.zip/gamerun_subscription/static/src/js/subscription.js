/** @odoo-module **/

import VariantMixin from "@website_sale/js/sale_variant_mixin";
import { WebsiteSale } from '@website_sale/js/website_sale';

WebsiteSale.include({

    _updateRootProduct($form, productId, productTemplateId) {
        this._super(...arguments);
        const deposit_type = $form.find('#add_to_cart').data('subscription-deposit_type');
        const deposit_value = $form.find('.deposit_value_input').val();
        if (deposit_type) {
            Object.assign(this.rootProduct, {
                deposit_type: deposit_type,
                deposit_value: parseFloat(deposit_value || 0),
            });
        }
    },

});
