/** @odoo-module **/

import publicWidget from "@web/legacy/js/public/public_widget";

// Global deposit data storage
window.eventDepositData = {};
window.eventTicketPrices = {};
window.enforcingDeposit = {}; // Flag to prevent recursion

// Validate that payment option is selected when remaining > 0
function validatePaymentOptionRequired(ticketId) {
    const depositInput = document.querySelector(`[data-ticket-id="${ticketId}"].deposit-input`);
    const remainingInput = document.querySelector(`[data-ticket-id="${ticketId}"].remaining-display`);
    const planSelect = document.querySelector(`[data-ticket-id="${ticketId}"].plan-select`);
    const autoPaymentCheckbox = document.querySelector(`#auto_payment_${ticketId}`);
    const paymentOptionWarning = document.querySelector(`[data-ticket-id="${ticketId}"].payment-option-warning`);
    const minimumDepositWarning = document.querySelector(`[data-ticket-id="${ticketId}"].minimum-deposit-warning`);

    if (!depositInput || !remainingInput) return true; // No validation needed if no inputs

    const remainingValue = parseFloat(remainingInput.value) || 0;
    const depositValue = parseFloat(depositInput.value) || 0;
    const minValue = parseFloat(depositInput.dataset.min) || 0;
    const ticketPrice = parseFloat(depositInput.dataset.ticketPrice) || 0;
    const depositType = depositInput.dataset.depositType || 'usd';

    // Calculate actual deposit amount for validation
    let actualDepositAmount;
    if (depositType === 'percentage') {
        actualDepositAmount = (ticketPrice * depositValue / 100);
    } else {
        actualDepositAmount = depositValue;
    }

    // Check if any payment option is selected
    const planSelected = planSelect && planSelect.value && planSelect.value !== '';
    const autoPaymentSelected = autoPaymentCheckbox && autoPaymentCheckbox.checked;
    const paymentOptionSelected = planSelected || autoPaymentSelected;

    // Validation logic:
    // 0. If deposit is 0, skip all validation and hide warnings
    // 1. If deposit > ticket price, show maximum deposit error
    // 2. If deposit > 0 and < minimum, show minimum deposit error
    // 3. If remaining > 0 and no payment option selected, show payment option error
    let isInvalid = false;
    let errorMessage = '';
    let showPaymentOptionWarning = false;
    let showMinimumDepositWarning = false;

    if (depositValue === 0) {
        // No deposit, no validation needed - hide all warnings
        showPaymentOptionWarning = false;
        showMinimumDepositWarning = false;
        isInvalid = false;
        errorMessage = 'No deposit - no validation needed';
    } else if (actualDepositAmount > ticketPrice) {
        // Deposit exceeds ticket price
        isInvalid = true;
        showMinimumDepositWarning = true; // Reuse the same warning div for maximum deposit
        errorMessage = 'Deposit cannot exceed ticket price';
    } else if (depositValue > 0 && depositValue < minValue) {
        // Deposit is too low (regardless of payment options)
        isInvalid = true;
        showMinimumDepositWarning = true;
        errorMessage = 'Deposit below minimum amount';
    } else if (remainingValue > 0 && !paymentOptionSelected) {
        // Remaining balance but no payment option selected
        isInvalid = true;
        showPaymentOptionWarning = true;
        errorMessage = 'Payment option required when remaining > 0';
    }

    // Show/hide payment option warning
    if (paymentOptionWarning) {
        paymentOptionWarning.style.display = showPaymentOptionWarning ? 'block' : 'none';
    }

    // Show/hide minimum deposit warning
    if (minimumDepositWarning) {
        minimumDepositWarning.style.display = showMinimumDepositWarning ? 'block' : 'none';
    }

    // Update deposit input styling for minimum deposit violation
    if (showMinimumDepositWarning) {
        depositInput.classList.add('is-invalid');
        depositInput.style.borderColor = '#dc3545';
        depositInput.style.backgroundColor = '#f8d7da';
    } else {
        depositInput.classList.remove('is-invalid');
        depositInput.style.borderColor = '';
        depositInput.style.backgroundColor = '';
    }

    // Register button validation now handled by widget

    return !isInvalid;
}

// Check if ticket is valid (without updating UI)
function isTicketValid(ticketId) {
    const depositInput = document.querySelector(`[data-ticket-id="${ticketId}"].deposit-input`);
    const remainingInput = document.querySelector(`[data-ticket-id="${ticketId}"].remaining-display`);
    const planSelect = document.querySelector(`[data-ticket-id="${ticketId}"].plan-select`);
    const autoPaymentCheckbox = document.querySelector(`#auto_payment_${ticketId}`);

    if (!depositInput || !remainingInput) return true; // No validation needed if no inputs

    const remainingValue = parseFloat(remainingInput.value) || 0;
    const depositValue = parseFloat(depositInput.value) || 0;
    const minValue = parseFloat(depositInput.dataset.min) || 0;
    const ticketPrice = parseFloat(depositInput.dataset.ticketPrice) || 0;
    const depositType = depositInput.dataset.depositType || 'usd';

    // Calculate actual deposit amount for validation
    let actualDepositAmount;
    if (depositType === 'percentage') {
        actualDepositAmount = (ticketPrice * depositValue / 100);
    } else {
        actualDepositAmount = depositValue;
    }

    // Check if any payment option is selected
    const planSelected = planSelect && planSelect.value && planSelect.value !== '';
    const autoPaymentSelected = autoPaymentCheckbox && autoPaymentCheckbox.checked;
    const paymentOptionSelected = planSelected || autoPaymentSelected;

    // Validation logic:
    // 0. If deposit is 0, always valid
    // 1. If deposit > ticket price, invalid
    // 2. If deposit > 0 and < minimum, invalid
    // 3. If remaining > 0 and no payment option selected, invalid
    if (depositValue === 0) {
        return true; // No deposit, always valid
    } else if (actualDepositAmount > ticketPrice) {
        return false; // Deposit exceeds ticket price
    } else if (depositValue > 0 && depositValue < minValue) {
        return false; // Deposit below minimum amount
    } else if (remainingValue > 0 && !paymentOptionSelected) {
        return false; // Payment option required when remaining > 0
    }

    return true;
}

// OLD FUNCTION REMOVED - This was disabling the outside button!
// Now handled by ModalRegisterButtonValidation widget

// Check if payment deadline has passed for an event
function checkPaymentDeadline(ticketId) {
    const depositInput = document.querySelector(`[data-ticket-id="${ticketId}"].deposit-input`);
    const warningDiv = document.querySelector(`[data-ticket-id="${ticketId}"].payment-deadline-warning`);

    if (!depositInput || !warningDiv) return false;

    const eventStartStr = depositInput.dataset.eventStart;
    const paymentDurationStr = depositInput.dataset.paymentDuration;

    if (!eventStartStr || !paymentDurationStr) return false;

    const eventStartDate = new Date(eventStartStr);
    const paymentDuration = parseInt(paymentDurationStr);
    const today = new Date();

    // Calculate payment deadline: event start date - payment duration days
    const paymentDeadline = new Date(eventStartDate);
    paymentDeadline.setDate(paymentDeadline.getDate() - paymentDuration);

    // Check if today is past the payment deadline
    const deadlinePassed = today >= paymentDeadline;
    return deadlinePassed;
}

// Enforce 100% deposit when payment deadline has passed
function enforceFullDeposit(ticketId) {
    const depositInput = document.querySelector(`[data-ticket-id="${ticketId}"].deposit-input`);
    const warningDiv = document.querySelector(`[data-ticket-id="${ticketId}"].payment-deadline-warning`);

    if (!depositInput || !warningDiv) return;

    // Prevent recursion
    if (window.enforcingDeposit[ticketId]) return;

    const deadlinePassed = checkPaymentDeadline(ticketId);
    const depositValue = parseFloat(depositInput.value) || 0;
    const ticketPrice = parseFloat(depositInput.dataset.ticketPrice) || 0;
    const depositType = depositInput.dataset.depositType;

    // Calculate actual deposit amount
    let actualDepositAmount;
    if (depositType === 'percentage') {
        actualDepositAmount = (ticketPrice * depositValue / 100);
    } else {
        actualDepositAmount = depositValue;
    }

    // Show warning only if deadline passed AND deposit is less than full ticket price
    const shouldShowWarning = deadlinePassed && actualDepositAmount < ticketPrice;

    if (shouldShowWarning) {
        // Show warning message
        warningDiv.style.display = 'block';

        // Set deposit to 100% and make it readonly
        const maxValue = depositType === 'percentage' ? 100 : ticketPrice;

        // Set flag to prevent recursion
        window.enforcingDeposit[ticketId] = true;

        depositInput.value = maxValue;
        depositInput.readOnly = true;
        depositInput.style.backgroundColor = '#f8f9fa';

        // Update remaining amount without triggering enforcement again
        updateRemainingInternal(depositInput);

        // Clear flag
        window.enforcingDeposit[ticketId] = false;

    } else if (deadlinePassed && actualDepositAmount >= ticketPrice) {
        // Deadline passed but user already has 100% deposit - hide warning but keep readonly
        warningDiv.style.display = 'none';
        depositInput.readOnly = true;
        depositInput.style.backgroundColor = '#f8f9fa';
    } else {
        // Deadline not passed - hide warning and restore normal behavior
        warningDiv.style.display = 'none';
        depositInput.readOnly = false;
        depositInput.style.backgroundColor = '';
    }
}

// Handle mutual exclusion between plan selection and auto payment
function handlePlanAutoPaymentExclusion(ticketId) {
    const planSelect = document.querySelector(`[data-ticket-id="${ticketId}"].plan-select`);
    const autoPaymentCheckbox = document.querySelector(`#auto_payment_${ticketId}`);

    if (!planSelect || !autoPaymentCheckbox) return;

    // If auto payment is checked, disable and clear plan selection
    if (autoPaymentCheckbox.checked) {
        planSelect.disabled = true;
        planSelect.value = '';
        planSelect.style.opacity = '0.5';
    } else {
        planSelect.disabled = false;
        planSelect.style.opacity = '1';
    }
}

// Handle plan selection change
function handlePlanSelectionChange(ticketId) {
    const planSelect = document.querySelector(`[data-ticket-id="${ticketId}"].plan-select`);
    const autoPaymentCheckbox = document.querySelector(`#auto_payment_${ticketId}`);

    if (!planSelect || !autoPaymentCheckbox) return;

    // If a plan is selected, only uncheck auto payment but keep it enabled
    if (planSelect.value && planSelect.value !== '') {
        autoPaymentCheckbox.checked = false;
    } else {
        console.log(`📋 No plan selected for ticket ${ticketId} - Auto payment remains available`);
    }
}

// Update remaining amount when deposit changes
function updateRemaining(depositInput) {
    const ticketId = depositInput.dataset.ticketId;

    // Check payment deadline first - this may override the deposit value
    // Only if we're not already enforcing to prevent recursion
    if (!window.enforcingDeposit[ticketId]) {
        enforceFullDeposit(ticketId);
    }

    updateRemainingInternal(depositInput);
}

// Internal function to update remaining amount without deadline enforcement
function updateRemainingInternal(depositInput) {
    const ticketId = depositInput.dataset.ticketId;
    const remainingInput = document.querySelector(`[data-ticket-id="${ticketId}"].remaining-display`);
    let depositValue = parseFloat(depositInput.value) || 0;
    const minValue = parseFloat(depositInput.dataset.min) || 0;
    const depositType = depositInput.dataset.depositType || 'usd';
    const ticketPrice = parseFloat(depositInput.dataset.ticketPrice) || 0;

    // Cap deposit at maximum allowed value to prevent overpayment
    let maxDepositValue;
    if (depositType === 'percentage') {
        maxDepositValue = 100; // 100% maximum
        if (depositValue > maxDepositValue) {
            depositValue = maxDepositValue;
            depositInput.value = maxDepositValue;
        }
    } else {
        maxDepositValue = ticketPrice; // Ticket price maximum
        if (depositValue > maxDepositValue) {
            depositValue = maxDepositValue;
            depositInput.value = maxDepositValue.toFixed(2);
        }
    }

    // Store ticket price for later use
    window.eventTicketPrices[ticketId] = ticketPrice;

    if (remainingInput) {
        let actualDepositAmount;
        let remainingValue;

        if (depositType === 'percentage') {
            // Calculate actual deposit amount from percentage
            actualDepositAmount = (ticketPrice * depositValue / 100);
            remainingValue = Math.max(0, ticketPrice - actualDepositAmount);
        } else {
            // USD deposit
            actualDepositAmount = depositValue;
            remainingValue = Math.max(0, ticketPrice - depositValue);
        }

        remainingInput.value = remainingValue.toFixed(2);

        // Update hidden deposit value field
        const hiddenValueField = document.querySelector(`[data-ticket-id="${ticketId}"].deposit-hidden-value`);
        if (hiddenValueField) {
            // For percentage deposits, store the actual dollar amount
            hiddenValueField.value = depositType === 'percentage' ? actualDepositAmount : depositValue;
        }

        // Get payment option elements
        const planSelect = document.querySelector(`[data-ticket-id="${ticketId}"].plan-select`);
        const autoPaymentCheckbox = document.querySelector(`#auto_payment_${ticketId}`);

        // For multi-ticket template (col-12)
        let planContainer = planSelect ? planSelect.closest('.col-12') : null;
        let autoPaymentContainer = autoPaymentCheckbox ? autoPaymentCheckbox.closest('.col-12') : null;

        // For single ticket template (col-4)
        if (!planContainer && planSelect) {
            planContainer = planSelect.closest('.col-4');
        }
        if (!autoPaymentContainer && autoPaymentCheckbox) {
            autoPaymentContainer = autoPaymentCheckbox.closest('.col-4');
        }

        const orDivider = document.querySelector(`[data-ticket-id="${ticketId}"]`)?.closest('.row')?.querySelector('.col-1');

        // If deposit amount is zero OR remaining amount is zero, hide payment options
        if (depositValue === 0 || remainingValue <= 0) {
            // Hide plan selection
            if (planContainer) {
                planContainer.style.display = 'none';
                if (planSelect) planSelect.value = '';
            }

            // Hide auto payment
            if (autoPaymentContainer) {
                autoPaymentContainer.style.display = 'none';
                if (autoPaymentCheckbox) autoPaymentCheckbox.checked = false;
            }

            // Hide "or" divider
            if (orDivider) orDivider.style.display = 'none';

            // Hide payment option warning when deposit is 0 or remaining is 0
            const paymentOptionWarning = document.querySelector(`[data-ticket-id="${ticketId}"].payment-option-warning`);
            if (paymentOptionWarning) {
                paymentOptionWarning.style.display = 'none';
            }

            // Hide minimum deposit warning when deposit is 0
            const minimumDepositWarning = document.querySelector(`[data-ticket-id="${ticketId}"].minimum-deposit-warning`);
            if (minimumDepositWarning) {
                minimumDepositWarning.style.display = 'none';
            }

        } else {
            // Show payment options
            if (planContainer) planContainer.style.display = '';
            if (autoPaymentContainer) autoPaymentContainer.style.display = '';
            if (orDivider) orDivider.style.display = '';
        }

        // Validate payment option requirement
        validatePaymentOptionRequired(ticketId);

        // Store deposit data globally with plan and auto payment info
        if (depositValue > 0) {

            window.eventDepositData[ticketId] = {
                value: depositValue,
                type: depositType,
                actual_amount: actualDepositAmount,
                plan_id: planSelect && planSelect.value ? planSelect.value : '',
                auto_payment_enabled: autoPaymentCheckbox ? autoPaymentCheckbox.checked : false
            };

        } else {
            delete window.eventDepositData[ticketId];
        }
    }
}

// Function to populate deposit data in attendee form
function populateDepositDataInAttendeeForm() {
    const depositSections = document.querySelectorAll('.deposit-info-section');

    depositSections.forEach(section => {
        const depositInput = section.querySelector('.deposit-amount-input');
        const remainingInput = section.querySelector('.remaining-amount-display');
        const hiddenValueField = section.querySelector('.deposit-hidden-value');

        if (!depositInput) return;

        const ticketId = depositInput.dataset.ticketId;

        if (window.eventDepositData[ticketId]) {
            const depositInfo = window.eventDepositData[ticketId];
            const depositValue = depositInfo.value;
            const depositType = depositInfo.type || 'usd';

            const originalTicketPrice = window.eventTicketPrices && window.eventTicketPrices[ticketId] || 0;

            let actualDepositAmount;
            if (depositType === 'percentage') {
                actualDepositAmount = (originalTicketPrice * depositValue / 100);
            } else {
                actualDepositAmount = depositValue;
            }

            const remainingValue = Math.max(0, originalTicketPrice - actualDepositAmount);

            depositInput.value = depositValue.toFixed(depositType === 'percentage' ? 0 : 2);
            if (remainingInput) {
                remainingInput.value = remainingValue.toFixed(2);
            }

            if (hiddenValueField) {
                // For percentage deposits, store the actual dollar amount
                hiddenValueField.value = depositType === 'percentage' ? actualDepositAmount : depositValue;
            }

            // Set plan selection if available
            const planSelect = document.querySelector(`[data-ticket-id="${ticketId}"].plan-select`);
            if (planSelect && depositInfo.plan_id) {
                planSelect.value = depositInfo.plan_id;
            }

            // Set auto payment checkbox if available
            const autoPaymentCheckbox = document.querySelector(`#auto_payment_${ticketId}`);
            if (autoPaymentCheckbox) {
                autoPaymentCheckbox.checked = depositInfo.auto_payment_enabled || false;
            }

            // Apply mutual exclusion rules
            handlePlanAutoPaymentExclusion(ticketId);
            handlePlanSelectionChange(ticketId);
        } else {
            // Set to 0 if no deposit
            depositInput.value = '0.00';
            if (hiddenValueField) {
                hiddenValueField.value = '0';
            }
        }
    });
}

// Create a new widget to handle modal opening
publicWidget.registry.DepositModalHandler = publicWidget.Widget.extend({
    selector: 'button[data-bs-target="#modal_ticket_registration"]',
    events: {
        'click': '_onRegisterButtonClick',
    },

    _onRegisterButtonClick: function(ev) {
        // Wait for modal to be created and shown
        setTimeout(() => {
            // Hide all warning messages when modal opens
            document.querySelectorAll('.payment-option-warning').forEach(warning => {
                warning.style.display = 'none';
            });
            document.querySelectorAll('.minimum-deposit-warning').forEach(warning => {
                warning.style.display = 'none';
            });

            initializeDepositValues();
        }, 300);
    },
});

// BULLETPROOF Widget - Only affects MODAL button, never outside button
publicWidget.registry.ModalRegisterButtonValidation = publicWidget.Widget.extend({
    selector: '#modal_ticket_registration .o_wevent_js_ticket_details',  // VERY SPECIFIC - only inside modal
    events: {
        'change .form-select': '_onTicketQuantityChange',
        'input .deposit-input': '_onDepositChange',
        'change .plan-select': '_onPaymentOptionChange',
        'change .auto-payment-checkbox': '_onPaymentOptionChange',
    },

    start: function() {
        this._super.apply(this, arguments);
        // Disable button by default when modal opens (all quantities are 0)
        this._updateRegisterButtonState();
        return Promise.resolve();
    },

    _getTotalTicketCount: function() {
        var ticketCount = 0;
        // Only count selects INSIDE this modal widget
        const selectEls = this.el.querySelectorAll(".form-select");
        selectEls.forEach(function(selectEl) {
            ticketCount += parseInt(selectEl.value) || 0;
        });
        return ticketCount;
    },

    _needsPaymentOption: function(ticketId) {
        const depositInput = document.querySelector(`[data-ticket-id="${ticketId}"].deposit-input`);
        if (!depositInput) return false;

        const depositValue = parseFloat(depositInput.value) || 0;
        const remainingInput = document.querySelector(`[data-ticket-id="${ticketId}"].remaining-display`);
        const remainingValue = parseFloat(remainingInput?.value) || 0;

        if (depositValue > 0 && remainingValue > 0) {
            // Payment option required only when there's a remaining amount
            const planSelect = document.querySelector(`[data-ticket-id="${ticketId}"].plan-select`);
            const autoPaymentCheckbox = document.querySelector(`#auto_payment_${ticketId}`);

            const planSelected = planSelect && planSelect.value && planSelect.value !== '';
            const autoPaymentSelected = autoPaymentCheckbox && autoPaymentCheckbox.checked;

            const needsPayment = !(planSelected || autoPaymentSelected);
            return needsPayment;
        }

        // No payment option needed when remaining is 0 (full price deposit)
        return false;
    },

    _updateRegisterButtonState: function() {
        // BULLETPROOF selector - ONLY the modal submit button
        const registerButton = this.el.querySelector("button[type='submit'].btn-primary.a-submit");
        if (!registerButton) {
            return;
        }

        let shouldDisable = false;
        let disableReason = '';

        // Rule 1: Check if any tickets are selected
        const totalTickets = this._getTotalTicketCount();
        if (totalTickets === 0) {
            shouldDisable = true;
            disableReason = 'No tickets selected';
        } else {
            console.log(`✅ Quantity check passed: ${totalTickets} tickets selected`);
        }

        // Rule 2: Check deposit tickets for payment options
        if (!shouldDisable) {
            const depositInputs = document.querySelectorAll('.deposit-input');
            const quantitySelects = this.el.querySelectorAll(".form-select");

            depositInputs.forEach((input, index) => {
                const ticketId = input.dataset.ticketId;

                let ticketQuantity = 0;
                if (index < quantitySelects.length) {
                    ticketQuantity = parseInt(quantitySelects[index].value) || 0;
                }

                if (ticketQuantity > 0 && this._needsPaymentOption(ticketId)) {
                    shouldDisable = true;
                    disableReason = 'Payment option required for deposit tickets';
                }
            });
        }

        // Update ONLY the modal button
        registerButton.disabled = shouldDisable;
        if (shouldDisable) {
            registerButton.style.opacity = '0.5';
            registerButton.style.cursor = 'not-allowed';
            registerButton.title = disableReason;
        } else {
            registerButton.style.opacity = '';
            registerButton.style.cursor = '';
            registerButton.title = '';
        }
    },

    _onTicketQuantityChange: function() {
        this._updateRegisterButtonState();
    },

    _onDepositChange: function(ev) {
        // Update remaining amount first
        if (ev.target && ev.target.classList.contains('deposit-input')) {
            updateRemainingInternal(ev.target);
        }
        // Then update button state
        this._updateRegisterButtonState();
    },

    _onPaymentOptionChange: function() {
        this._updateRegisterButtonState();
    },
});

// Extend Odoo's EventRegistrationFormInstance to inject deposit data
publicWidget.registry.EventRegistrationFormInstance.include({
    start: function() {
        const result = this._super.apply(this, arguments);

        // Set up deposit input handlers
        this.el.addEventListener('input', function(event) {
            if (event.target.classList.contains('deposit-input')) {
                updateRemaining(event.target);
            }
        });

        // Set up plan selection handlers
        this.el.addEventListener('change', function(event) {
            if (event.target.classList.contains('plan-select')) {
                const ticketId = event.target.dataset.ticketId;
                handlePlanSelectionChange(ticketId);
                // Update deposit data when plan changes
                const depositInput = document.querySelector(`[data-ticket-id="${ticketId}"].deposit-input`);
                if (depositInput) {
                    updateRemaining(depositInput);
                }
            }
        });

        // Set up auto payment checkbox handlers
        this.el.addEventListener('change', function(event) {
            if (event.target.classList.contains('auto-payment-checkbox')) {
                const ticketId = event.target.id.replace('auto_payment_', '');
                handlePlanAutoPaymentExclusion(ticketId);
                // Update deposit data when auto payment changes
                const depositInput = document.querySelector(`[data-ticket-id="${ticketId}"].deposit-input`);
                if (depositInput) {
                    updateRemaining(depositInput);
                }
            }
        });

        // Override the instance's _getPost method to include deposit data
        if (this.instance && this.instance._getPost) {
            const originalGetPost = this.instance._getPost.bind(this.instance);

            this.instance._getPost = function() {
                const post = originalGetPost();

                // Add deposit data to the post
                Object.keys(window.eventDepositData).forEach(ticketId => {
                    const depositInfo = window.eventDepositData[ticketId];

                    if (depositInfo.type === 'percentage') {
                        // For percentage deposits, send both the percentage value and calculated amount
                        post[`${ticketId}-subscription_deposit_value`] = depositInfo.value; // Original percentage
                        post[`${ticketId}-subscription_deposit_amount`] = depositInfo.actual_amount; // Calculated dollar amount
                    } else {
                        // For USD deposits, send the dollar amount
                        post[`${ticketId}-subscription_deposit_value`] = depositInfo.value;
                    }

                    post[`${ticketId}-subscription_deposit_type`] = depositInfo.type;

                    // Add plan_id if selected
                    if (depositInfo.plan_id) {
                        post[`${ticketId}-plan_id`] = depositInfo.plan_id;
                    }

                    // Add auto_payment_enabled if checked
                    if (depositInfo.auto_payment_enabled) {
                        post[`${ticketId}-auto_payment_enabled`] = '1';
                    }

                });

                return post;
            };
        }

        return result;
    }
});

// Function to reset all form values when modal opens
function resetModalFormValues() {
    // 1. Reset all quantity selects to 0
    document.querySelectorAll('select[name*="nb_register"]').forEach(select => {
        select.value = '0';
    });

    // 2. Clear all plan selections
    document.querySelectorAll('.plan-select').forEach(planSelect => {
        planSelect.value = '';
    });

    // 3. Uncheck all auto-payment checkboxes
    document.querySelectorAll('.auto-payment-checkbox, input[type="checkbox"][id*="auto_payment"]').forEach(checkbox => {
        checkbox.checked = false;
    });

    // 4. Set deposits to minimum deposit amount by default
    document.querySelectorAll('.deposit-input').forEach(input => {
        const ticketId = input.dataset.ticketId;
        const depositType = input.dataset.depositType || 'usd';
        const ticketPrice = parseFloat(input.dataset.ticketPrice) || 0;
        const minDepositValue = parseFloat(input.dataset.min) || 0;

        // Set deposit to minimum deposit amount
        if (depositType === 'percentage') {
            input.value = minDepositValue.toString();
        } else {
            input.value = minDepositValue.toFixed(2);
        }

        // Calculate remaining amount based on minimum deposit
        const remainingInput = document.querySelector(`[data-ticket-id="${ticketId}"].remaining-display`);
        if (remainingInput) {
            let actualDepositAmount;
            if (depositType === 'percentage') {
                actualDepositAmount = (ticketPrice * minDepositValue / 100);
            } else {
                actualDepositAmount = minDepositValue;
            }
            const remainingAmount = Math.max(0, ticketPrice - actualDepositAmount);
            remainingInput.value = remainingAmount.toFixed(2);
        }

        // Update hidden deposit value field
        const hiddenValueField = document.querySelector(`[data-ticket-id="${ticketId}"].deposit-hidden-value`);
        if (hiddenValueField) {
            if (depositType === 'percentage') {
                hiddenValueField.value = (ticketPrice * minDepositValue / 100); // Actual dollar amount from percentage
            } else {
                hiddenValueField.value = minDepositValue;
            }
        }

        // Show/hide payment options based on remaining amount
        const remainingAmount = parseFloat(remainingInput?.value) || 0;
        const planSelect = document.querySelector(`[data-ticket-id="${ticketId}"].plan-select`);
        const autoPaymentCheckbox = document.querySelector(`#auto_payment_${ticketId}`);

        // Find containers for both multi-ticket (col-12) and single ticket (col-4) templates
        let planContainer = planSelect ? planSelect.closest('.col-12') : null;
        let autoPaymentContainer = autoPaymentCheckbox ? autoPaymentCheckbox.closest('.col-12') : null;

        if (!planContainer && planSelect) {
            planContainer = planSelect.closest('.col-4');
        }
        if (!autoPaymentContainer && autoPaymentCheckbox) {
            autoPaymentContainer = autoPaymentCheckbox.closest('.col-4');
        }

        const orDivider = document.querySelector(`[data-ticket-id="${ticketId}"]`)?.closest('.row')?.querySelector('.col-1');

        if (remainingAmount > 0) {
            // Show payment options when there's a remaining amount

            if (planContainer) {
                planContainer.style.display = 'block';
            }
            if (autoPaymentContainer) {
                autoPaymentContainer.style.display = 'block';
            }
            if (orDivider) {
                orDivider.style.display = 'block';
            }
        } else {
            // Hide payment options when remaining is 0 (when deposit equals full ticket price)

            if (planContainer) {
                planContainer.style.display = 'none';
                if (planSelect) planSelect.value = '';
            }
            if (autoPaymentContainer) {
                autoPaymentContainer.style.display = 'none';
                if (autoPaymentCheckbox) autoPaymentCheckbox.checked = false;
            }
            if (orDivider) {
                orDivider.style.display = 'none';
            }
        }

    });

}

// Legacy function name for backward compatibility
function initializeDepositValues() {
    resetModalFormValues();
}

// OLD FUNCTION REMOVED - Now handled by ModalRegisterButtonValidation widget

document.addEventListener('DOMContentLoaded', function() {
    // Check if deposit sections exist
    const depositSections = document.querySelectorAll('.deposit-section');

    // Set up initial handlers for existing inputs
    document.querySelectorAll('.deposit-input').forEach(input => {
        const ticketId = input.dataset.ticketId;

        // Initialize enforcement flag
        window.enforcingDeposit[ticketId] = false;

        // Initialize deposit to minimum deposit amount if not already set
        if (!input.value || input.value === '0' || input.value === '0.00') {
            const depositType = input.dataset.depositType || 'usd';
            const minDepositValue = parseFloat(input.dataset.min) || 0;

            if (depositType === 'percentage') {
                input.value = minDepositValue.toString();
            } else {
                input.value = minDepositValue.toFixed(2);
            }

            // Update remaining amount and show payment options
            updateRemainingInternal(input);
        } else {
            // Even if value is already set, make sure payment options are properly shown/hidden
            updateRemainingInternal(input);
        }

        // Check payment deadline on page load
        enforceFullDeposit(ticketId);

        input.addEventListener('input', () => {
            updateRemaining(input);
            // Validate payment option requirement when deposit changes
            validatePaymentOptionRequired(ticketId);
            // Note: Register button validation is now handled by the widget
        });
    });

    // Set up plan selection handlers
    document.querySelectorAll('.plan-select').forEach(select => {
        const ticketId = select.dataset.ticketId;
        select.addEventListener('change', () => {
            handlePlanSelectionChange(ticketId);
            const depositInput = document.querySelector(`[data-ticket-id="${ticketId}"].deposit-input`);
            if (depositInput) {
                updateRemaining(depositInput);
            }
            // Validate payment option requirement when plan changes
            validatePaymentOptionRequired(ticketId);
            // Note: Register button validation is now handled by the widget
        });
        // Initialize state
        handlePlanSelectionChange(ticketId);
    });

    // Set up auto payment checkbox handlers
    document.querySelectorAll('.auto-payment-checkbox').forEach(checkbox => {
        const ticketId = checkbox.id.replace('auto_payment_', '');
        checkbox.addEventListener('change', () => {
            handlePlanAutoPaymentExclusion(ticketId);
            const depositInput = document.querySelector(`[data-ticket-id="${ticketId}"].deposit-input`);
            if (depositInput) {
                updateRemaining(depositInput);
            }
            // Validate payment option requirement when checkbox changes
            validatePaymentOptionRequired(ticketId);
            // Note: Register button validation is now handled by the widget
        });
        // Initialize state
        handlePlanAutoPaymentExclusion(ticketId);
    });

    // Set up quantity selection handlers
    document.querySelectorAll('select[name*="nb_register"]').forEach(select => {
        select.addEventListener('change', () => {
            // Note: Register button validation is now handled by the widget
        });
    });

    // Initialize deposit values on page load
    initializeDepositValues();

    // Don't call updateModalRegisterButtonState() here - it should only run when modal is open

    // Initial validation for all tickets
    document.querySelectorAll('.deposit-input').forEach(input => {
        const ticketId = input.dataset.ticketId;
        validatePaymentOptionRequired(ticketId);
    });

    // Watch for modals to open and initialize deposit values
    const observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            if (mutation.type === 'childList' || mutation.type === 'attributes') {
                // Check for ticket registration modal
                const ticketModal = document.getElementById('modal_ticket_registration');
                if (ticketModal && ticketModal.classList.contains('show')) {
                    setTimeout(() => {
                        initializeDepositValues();

                        // Hide all warning messages on modal refresh
                        document.querySelectorAll('.payment-option-warning').forEach(warning => {
                            warning.style.display = 'none';
                        });
                        document.querySelectorAll('.minimum-deposit-warning').forEach(warning => {
                            warning.style.display = 'none';
                        });

                        // Validate all tickets after initialization
                        document.querySelectorAll('.deposit-input').forEach(input => {
                            const ticketId = input.dataset.ticketId;
                            validatePaymentOptionRequired(ticketId);
                        });

                        // Note: Register button validation is now handled by the widget
                    }, 100);
                }

                // Check for attendee modal
                const attendeeModal = document.getElementById('modal_attendees_registration');
                if (attendeeModal && attendeeModal.classList.contains('show')) {
                    // Use setTimeout to ensure the modal content is fully rendered
                    setTimeout(() => {
                        populateDepositDataInAttendeeForm();
                    }, 100);
                }
            }
        });
    });

    // Start observing
    observer.observe(document.body, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ['class']
    });

    // Add form submission prevention as a safety net
    document.addEventListener('submit', function(event) {
        // Check if this is an event registration form
        const form = event.target;
        if (form && (form.action.includes('/event/') || form.querySelector('.deposit-input'))) {
            let hasValidationErrors = false;
            let errorMessages = [];

            // Validate all tickets
            document.querySelectorAll('.deposit-input').forEach(input => {
                const ticketId = input.dataset.ticketId;
                if (!isTicketValid(ticketId)) {
                    hasValidationErrors = true;

                    const remainingInput = document.querySelector(`[data-ticket-id="${ticketId}"].remaining-display`);
                    const remainingValue = parseFloat(remainingInput?.value) || 0;
                    const depositValue = parseFloat(input.value) || 0;
                    const minValue = parseFloat(input.dataset.min) || 0;
                    const ticketPrice = parseFloat(input.dataset.ticketPrice) || 0;
                    const depositType = input.dataset.depositType || 'usd';

                    // Calculate actual deposit amount
                    let actualDepositAmount;
                    if (depositType === 'percentage') {
                        actualDepositAmount = (ticketPrice * depositValue / 100);
                    } else {
                        actualDepositAmount = depositValue;
                    }

                    if (actualDepositAmount > ticketPrice) {
                        const maxAllowed = depositType === 'percentage' ? '100%' : `$${ticketPrice}`;
                        errorMessages.push(`Ticket ${ticketId}: Deposit cannot exceed ticket price (max: ${maxAllowed})`);
                    } else if (depositValue > 0 && depositValue < minValue) {
                        const minRequired = depositType === 'percentage' ? `${minValue}%` : `$${minValue}`;
                        errorMessages.push(`Ticket ${ticketId}: Deposit below minimum amount (min: ${minRequired})`);
                    } else if (remainingValue > 0) {
                        errorMessages.push(`Ticket ${ticketId}: Payment option required when remaining balance > $0`);
                    }
                }
            });

            if (hasValidationErrors) {
                event.preventDefault();
                event.stopPropagation();

                const message = 'Please fix the following issues before registering:\n\n' + errorMessages.join('\n');
                alert(message);

                return false;
            }
        }
    });
});


