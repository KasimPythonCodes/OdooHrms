/** @odoo-module **/

import { patch } from '@web/core/utils/patch';
import {
    ComboConfiguratorDialog
} from '@sale/js/combo_configurator_dialog/combo_configurator_dialog';
import {
    ProductConfiguratorDialog
} from '@sale/js/product_configurator_dialog/product_configurator_dialog';
import { WebsiteSale } from '@website_sale/js/website_sale';
import { Product } from '@sale/js/product/product';
import { ProductList } from '@sale/js/product_list/product_list';
import { formatCurrency } from "@web/core/currency";

patch(ComboConfiguratorDialog, {
    props: {
        ...ComboConfiguratorDialog.props,
        subscriptionDepositType: { type: String, optional: true },
        subscriptionDepositValue: { type: Number, optional: true },
    },
});

patch(ComboConfiguratorDialog.prototype, {
    _getAdditionalRpcParams() {
        const params = super._getAdditionalRpcParams();
        if (this.props.subscriptionDepositType) {
            params.deposit_type = this.props.subscriptionDepositType;
            params.deposit_value = this.props.subscriptionDepositValue;
        }
        return params;
    },

    _getAdditionalDialogProps() {
        const props = super._getAdditionalDialogProps();
        if (this.props.subscriptionDepositType) {
            props.subscriptionDepositType = this.props.subscriptionDepositType;
            props.subscriptionDepositValue = this.props.subscriptionDepositValue;
        }
        return props;
    },
});

patch(ProductConfiguratorDialog, {
    props: {
        ...ProductConfiguratorDialog.props,
        subscriptionDepositType: { type: String, optional: true },
        subscriptionDepositValue: { type: Number, optional: true },
    },

});

patch(ProductConfiguratorDialog.prototype, {
    _getAdditionalRpcParams() {
        const params = super._getAdditionalRpcParams();
        if (this.props.subscriptionDepositType) {
            params.deposit_type = this.props.subscriptionDepositType;
            params.deposit_value = this.props.subscriptionDepositValue;
        }
        return params;
    },
});

patch(Product, {
    props: {
        ...Product.props,
        deposit_type: { type: String, optional: true },
        deposit_value: { type: Number, optional: true },
    },
});

patch(Product.prototype, {
    getFormattedDeposit() {
        return formatCurrency(this.props.deposit_value, this.env.currency.id);
    }
});


patch(ProductList, {
    props: {
        ...ProductList.props,
        deposit_type: { type: String, optional: true },
        deposit_value: { type: Number, optional: true },
    },
});


WebsiteSale.include({
    _getAdditionalDialogProps() {
        const props = this._super(...arguments);
        if (this.rootProduct.deposit_type) {
            props.subscriptionDepositType = this.rootProduct.deposit_type;
            props.subscriptionDepositValue = this.rootProduct.deposit_value;
        }
        return props;
    },

    _getAdditionalRpcParams() {
        const params = this._super(...arguments);
        if (this.rootProduct.deposit_type) {
            params.deposit_type = this.rootProduct.deposit_type;
            params.deposit_value = this.rootProduct.deposit_value;
        }
        return params;
    },
});