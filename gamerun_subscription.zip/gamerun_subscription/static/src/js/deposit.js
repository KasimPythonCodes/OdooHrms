/** @odoo-module **/

import publicWidget from "@web/legacy/js/public/public_widget";
import VariantMixin from "@website_sale/js/sale_variant_mixin";
import { rpc } from "@web/core/network/rpc";

publicWidget.registry.DepositAmountWidget = publicWidget.Widget.extend({
    selector: '.deposit_option',
    events: {
        'input .deposit_value_input': '_onDepositValueChange',
        'click .o_appointment_form_confirm_btn': '_onConfirmButtonClick',
        'change select[name="appointment_subscripition_plan_id"]': '_onInstallmentValueChange',
    },

    _validateDeposit(depositInput, confirmButton) {
        const price = parseFloat(document.querySelector('.deposit_price').getAttribute('data-price')) || 0;
        const isPercentage = depositInput.name === 'deposit_percentage';
        const installmentSelect = document.querySelector('select[name="appointment_subscripition_plan_id"]');
//        const depositInput = document.querySelector('.deposit_value_input');
        const errorElement = document.querySelector('.deposit_error');
        const paymentDetailElement = document.querySelector('.auto-payment-details');
        const errorList = [];

        if (!depositInput) {
            return { depositAmount: 0, errorList: [] };
        }

        const minDepositValue = parseFloat(depositInput.dataset.minDeposit || 0);
        const isSingleSubscription = depositInput.dataset.isSingleSubscription;
        const appointmentDateStr = document.querySelector('input[name="datetime_str"]')?.value;
        const appointmentDate = appointmentDateStr ? new Date(appointmentDateStr) : null;
        const paymentDuration = parseInt(depositInput.dataset.paymentDuration || 0);
        const today = new Date();
        const inputValue = parseFloat(depositInput.value || minDepositValue);

        let depositAmount = isPercentage
            ? (price * inputValue / 100).toFixed(2)
            : parseFloat(inputValue).toFixed(2);

        // Reset depositAmount to price if it exceeds price
        if (depositAmount > price) {
            depositAmount = price.toFixed(2);
            depositInput.value = isPercentage ? 100 : price;
            //errorList.push(`Deposit cannot exceed ${isPercentage ? '100%' : '$' + price}`);
            //input.classList.add('is-invalid');
        }

        if (isSingleSubscription && appointmentDate && paymentDuration && depositAmount < price) {
            const paymentDeadline = new Date(appointmentDate);
            paymentDeadline.setDate(paymentDeadline.getDate() - paymentDuration);
            if (today >= paymentDeadline) {
                errorList.push("Payment deadline has passed for this appointment. You must pay 100% as deposit");
                depositInput.classList.add('is-invalid');
                paymentDetailElement.classList.add('d-none');
            } else {
                depositInput.classList.remove('is-invalid');
                paymentDetailElement.classList.remove('d-none');
            }
        }

        if (inputValue < minDepositValue) {
            depositInput.classList.add('is-invalid');
            errorList.push(`Minimum deposit required: ${isPercentage ? minDepositValue + '%' : '$' + minDepositValue}`);
        } else if (!errorList.length) {
            depositInput.classList.remove('is-invalid');
        }
        // disable and remove required if depositAmount equals price
        if (installmentSelect) {
            if (depositAmount === price.toFixed(2)) {
                installmentSelect.disabled = true;
                installmentSelect.removeAttribute('required');
                installmentSelect.value = '';
            } else {
                installmentSelect.disabled = false;
                installmentSelect.setAttribute('required', '1');
            }

            const installmentSelectHasValue = installmentSelect.value.trim() !== '';
            if (installmentSelect.required && !installmentSelectHasValue) {
                errorList.push('Please select an installment plan.');
            }

        }

        this._displayErrors(errorElement, errorList, confirmButton);

        return { depositAmount, errorList };
    },

    _onDepositValueChange(ev) {
        const depositInput = ev.currentTarget;
        const confirmButton = document.querySelector('.o_appointment_form_confirm_btn');
        const { depositAmount, errorList } = this._validateDeposit(depositInput, confirmButton);
        const price = parseFloat(document.querySelector('.deposit_price').getAttribute('data-price')) || 0;
        document.querySelector('.deposit_price').textContent = depositAmount;
        document.querySelector('.remaining_price').textContent = (price - depositAmount).toFixed(2);
    },

    _onInstallmentValueChange(ev) {
        const installmentSelect = ev.currentTarget;
        const confirmButton = document.querySelector('.o_appointment_form_confirm_btn');
        const depositInput = document.querySelector('.deposit_value_input');
        const errorElement = document.querySelector('.deposit_error');
        if (installmentSelect) {
            const installmentSelectHasValue = installmentSelect.value.trim() !== '';
            const { errorList } = this._validateDeposit(depositInput, confirmButton);
            this._displayErrors(errorElement, errorList, confirmButton);
        }
    },

    _onConfirmButtonClick(ev) {
        const depositInput = document.querySelector('.deposit_value_input');
        const confirmButton = ev.currentTarget;
        const { errorList } = this._validateDeposit(depositInput, confirmButton);

        if (errorList.length > 0) {
            ev.preventDefault(); // Prevent form submission if there are errors
        }
    },

    _displayErrors(errorElement, errorList, confirmButton) {
        if (errorElement) {
            errorElement.innerHTML = '';
            if (errorList.length > 0) {
                errorList.forEach(error => {
                    const errorParagraph = document.createElement('p');
                    errorParagraph.textContent = error;
                    errorElement.appendChild(errorParagraph);
                });
                errorElement.classList.remove('d-none');
                if (confirmButton) {
                    confirmButton.disabled = true;
                }
            } else {
                errorElement.classList.add('d-none');
                if (confirmButton) {
                    confirmButton.disabled = false;
                }
            }
        }
    },

    start: function () {
        const depositInput = document.querySelector('.deposit_value_input');
        const confirmButton = document.querySelector('.o_appointment_form_confirm_btn');
        const { depositAmount, errorList } = this._validateDeposit(depositInput, confirmButton);
//        const price = parseFloat(document.querySelector('.deposit_price').getAttribute('data-price')) || 0;
//        document.querySelector('.deposit_price').textContent = depositAmount;
//        document.querySelector('.remaining_price').textContent = (price - depositAmount).toFixed(2);
//        const inputs = this.$el.find('.deposit_value_input');
//        inputs.each((index, input) => {
//            const event = new Event('input', { bubbles: true });
//            input.dispatchEvent(event);
//        });
//
//        return this._super.apply(this, arguments);
    },
});


publicWidget.registry.WebsiteSaleDepositVariant = publicWidget.Widget.extend(VariantMixin, {
    selector: '.oe_website_sale',
    events: {
        'change [data-attribute_exclusions]': '_onVariantValueChange'
    },

    _onVariantValueChange(ev) {
        var $parent = $(ev.target).closest('.js_product');
        if (!$parent.data('uniqueId')) {
            $parent.data('uniqueId', uniqueId());
        }

        if(!$parent.length){
            return Promise.resolve();
        }

        var self = this;
        var $price = $parent.find(".o_subscription_price_display .oe_price:first .oe_currency_value");
        var $depositPrice = $parent.find(".deposit_price");
        var $remainingPrice = $parent.find(".remaining_price");
        var $depositInput = $parent.find('.deposit_value_input');
        const minDeposit = parseFloat($depositInput.attr('data-min-deposit')) || 0;

        const combination = this.getSelectedVariantValues($parent);

        return rpc('/website_sale/get_combination_info', {
            'product_template_id': parseInt($parent.find('.product_template_id').val()),
            'product_id': this._getProductId($parent),
            'combination': combination,
            'add_qty': parseInt($parent.find('input[name="add_qty"]').val()),
            'parent_combination': [],
            'context': this.context,
            ...this._getOptionalCombinationInfoParam($parent),
        }).then((combinationData) => {
            if (this._shouldIgnoreRpcResult()) {
                return;
            }

            // Update main price
            $price.text(combinationData.list_price);

            // Update deposit price data attribute and calculate deposit amount
            $depositPrice.attr('data-price', combinationData.list_price);

            // Get deposit type and value from input fields
            const depositType = $parent.find('.deposit_value_input').attr('name') === 'deposit_percentage' ? 'percentage' : 'fixed';
            const depositValue = parseFloat($parent.find('.deposit_value_input').val()) || 0;
            var depositAmount = 0;
            if (depositValue == 0) {
                depositAmount = minDeposit.toFixed(2);
                $depositInput.val(minDeposit.toFixed(2));
                $depositPrice.text(depositAmount);
            } else {
                // Calculate deposit and remaining amounts
                depositAmount = depositType === 'percentage'
                    ? combinationData.list_price * depositValue / 100
                    : depositValue;
               $depositPrice.text(depositAmount.toFixed(2));
            }

            const remainingAmount = combinationData.list_price - depositAmount;

            // Update displayed amounts
            $remainingPrice.text(remainingAmount.toFixed(2));
        });
    },


});