from odoo.addons.website_sale_subscription.controllers import variant as portal
from odoo.addons.website_appointment_sale.controllers import appointment
from odoo.addons.website_event.controllers.main import WebsiteEventController
from odoo.addons.website_event_sale.controllers.main import WebsiteEventSaleController
from odoo.addons.gamerun_appointment.controllers.main import AppointmentController
from collections import defaultdict
from datetime import timedelta

from odoo.http import request, route
from odoo.addons.base.models.ir_qweb import keep_query
from odoo import fields
from odoo.exceptions import UserError

import logging

_logger = logging.getLogger(__name__)


class WebsiteSale(portal.WebsiteSale):

    def _get_shop_payment_values(self, order, **kwargs):
        is_deposit_order = False
        if order:
            is_deposit_order = order.order_line.filtered(lambda l: l.product_id.recurring_invoice and l.subscription_deposit_value) and True or False

        return {
            **super()._get_shop_payment_values(order, **kwargs),
            'is_deposit_order': is_deposit_order,
        }


class WebsiteAppointmentSale(appointment.WebsiteAppointmentSale):

    def _redirect_to_payment(self, calendar_booking):
        """ Override: when using a payment step, we go through the eCommerce flow instead,
            and link the booking to the SOL as one can go through the flow several times and book
            several slots of the same appointment type """
        order_sudo = request.website.sale_get_order(force_create=True)

        # Necessary to have a description matching the tz picked by partner.
        # See _prepare_order_line_values on sale.order model.
        tz = (request.session.get('timezone') or
              request.env.context.get('tz') or
              calendar_booking.appointment_type_id.appointment_tz)

        deposit_data = request.session.get('appointment_deposit_data', {})
        deposit_type = deposit_data.get('deposit_type', False)
        deposit_value = deposit_data.get('deposit_value', False)
        selected_plan_id = deposit_data.get('selected_plan_id', False)

        # Debug logging
        _logger.info(f"🔍 _redirect_to_payment debug:")
        _logger.info(f"   session deposit_data: {deposit_data}")
        _logger.info(f"   deposit_type: {deposit_type}")
        _logger.info(f"   deposit_value: {deposit_value}")
        _logger.info(f"   selected_plan_id: {selected_plan_id}")

        cart_values = order_sudo._cart_update(
            product_id=calendar_booking.appointment_type_id.product_id.id,
            set_qty=calendar_booking.asked_capacity,
            calendar_booking_id=calendar_booking.id,
            calendar_booking_tz=tz,
            deposit_type=deposit_type,
            deposit_value=deposit_value,
            plan_id=selected_plan_id
        )

        request.session.pop('appointment_deposit_data', None)
        if cart_values['quantity'] == calendar_booking.asked_capacity:  # Booking successfully added to cart
            return request.redirect("/shop/cart")

        # Slot not available. We remove booking and redirect to appointment.
        appointment_type = calendar_booking.appointment_type_id
        calendar_booking.sudo().unlink()
        error_state = 'failed-staff-user' if appointment_type.schedule_based_on == 'users' else 'failed-resource'
        return request.redirect('/appointment/%s?%s' % (appointment_type.id, keep_query('*', state=error_state)))


class AppointmentControllerSubscription(AppointmentController):
    """Controller to capture deposit values from appointment form submission"""

    @route()
    def appointment_form_submit(self, appointment_type_id, datetime_str, duration_str, name, phone, email, staff_user_id=None, available_resource_ids=None, asked_capacity=1, guest_emails_str=None, **kwargs):
        # Determine deposit type and value based on form fields
        if kwargs.get('deposit_percentage'):
            deposit_type = 'percentage'
            deposit_value = kwargs.get('deposit_percentage')
        elif kwargs.get('deposit_fixed_amount'):
            deposit_type = 'usd'
            deposit_value = kwargs.get('deposit_fixed_amount')
        else:
            # Fallback to other field names
            deposit_type = (kwargs.get('deposit_type') or
                           kwargs.get('subscription_deposit_type') or
                           kwargs.get('initial_deposit_type') or
                           'usd')
            deposit_value = (kwargs.get('deposit_value') or
                            kwargs.get('subscription_deposit_value') or
                            kwargs.get('initial_deposit_value', False))

        selected_plan_id = (kwargs.get('selected_plan_id') or
                           kwargs.get('plan_id') or
                           kwargs.get('subscription_plan_id') or
                           kwargs.get('appointment_subscripition_plan_id', False))

        auto_payment_enabled = (kwargs.get('auto_payment_enabled') or
                               kwargs.get('auto_payment', False))

        # Debug logging
        _logger.info(f"🔍 Appointment form submission debug:")
        _logger.info(f"   deposit_type: {deposit_type}")
        _logger.info(f"   deposit_value: {deposit_value}")
        _logger.info(f"   selected_plan_id: {selected_plan_id}")
        _logger.info(f"   auto_payment_enabled: {auto_payment_enabled}")
        _logger.info(f"   kwargs keys: {list(kwargs.keys())}")

        if deposit_type or deposit_value or selected_plan_id:
            request.session['appointment_deposit_data'] = {
                'deposit_type': deposit_type,
                'deposit_value': float(deposit_value) if deposit_value else False,
                'selected_plan_id': int(selected_plan_id) if selected_plan_id else False,
                'auto_payment_enabled': auto_payment_enabled
            }
        else:
            _logger.info(f"❌ No deposit data found in form submission")

        return super().appointment_form_submit(
            appointment_type_id, datetime_str, duration_str, name, phone, email,
            staff_user_id, available_resource_ids, asked_capacity, guest_emails_str, **kwargs
        )


class WebsiteEventDepositController(WebsiteEventSaleController):

    @route()
    def registration_new(self, event, **post):
        """Override to capture deposit data and plan_id data and pass to second modal"""

        deposit_data = {}
        for key, value in post.items():
            if key.endswith('-subscription_deposit_value') and value:
                ticket_id = key.replace('-subscription_deposit_value', '')
                deposit_type_key = f'{ticket_id}-subscription_deposit_type'
                deposit_amount_key = f'{ticket_id}-subscription_deposit_amount'
                plan_id_key = f'{ticket_id}-plan_id'
                auto_payment_key = f'{ticket_id}-auto_payment_enabled'
                deposit_value = float(value or 0)
                deposit_type = post.get(deposit_type_key, 'usd')
                plan_id = post.get(plan_id_key, '')
                auto_payment_enabled = post.get(auto_payment_key, '') == '1'

                if deposit_value > 0:
                    ticket = request.env['event.event.ticket'].sudo().browse(int(ticket_id))
                    actual_deposit_type = ticket.initial_deposit_type if ticket.exists() else 'usd'

                    if auto_payment_enabled and ticket.sudo().event_id.subscription_payment_duration > 0:
                        # Check if payment deadline has passed
                        event = ticket.sudo().event_id
                        event_start_date = fields.Date.from_string(event.date_begin.date()) if event.date_begin else None
                        payment_duration = event.subscription_payment_duration
                        today = fields.Date.today()

                        if event_start_date and payment_duration:
                            # Calculate payment deadline: event start date - payment duration days
                            payment_deadline = event_start_date - timedelta(days=payment_duration)

                            if today > payment_deadline:
                                raise UserError(
                                    f"Payment deadline has passed for event '{event.name}'. "
                                    f"The deadline was {payment_deadline.strftime('%B %d, %Y')}. "
                                    f"Auto-payment option is no longer available. Please pay the full amount as deposit."
                                )


                    if actual_deposit_type == 'percentage':
                        final_deposit_value = (ticket.price * deposit_value / 100) if ticket.exists() else deposit_value
                        final_deposit_type = 'usd'
                    else:
                        final_deposit_value = deposit_value
                        final_deposit_type = actual_deposit_type

                    deposit_data[ticket_id] = {
                        'value': final_deposit_value,
                        'type': final_deposit_type,
                        'original_percentage': deposit_value if actual_deposit_type == 'percentage' else None,
                        'plan_id': plan_id,
                        'auto_payment_enabled': auto_payment_enabled
                    }

        result = super().registration_new(event, **post)
        if deposit_data and result:
            request.session['modal_deposit_data'] = deposit_data
        return result

    @route()
    def registration_confirm(self, event, **post):
        """Override to capture deposit data from attendee form"""
        modal_deposit_data = request.session.get('modal_deposit_data', {})
        form_deposit_data = {}
        for key, value in post.items():
            if key.endswith('-subscription_deposit_value') and value:
                ticket_id = key.replace('-subscription_deposit_value', '')
                deposit_type_key = f'{ticket_id}-subscription_deposit_type'
                deposit_amount_key = f'{ticket_id}-subscription_deposit_amount'
                plan_id_key = f'{ticket_id}-plan_id'
                auto_payment_key = f'{ticket_id}-auto_payment_enabled'
                deposit_value = float(value or 0)
                deposit_type = post.get(deposit_type_key, 'usd')
                plan_id = post.get(plan_id_key, '')
                auto_payment_enabled = post.get(auto_payment_key, '') == '1'

                if deposit_value > 0:
                    ticket = request.env['event.event.ticket'].sudo().browse(int(ticket_id))
                    actual_deposit_type = ticket.initial_deposit_type if ticket.exists() else 'usd'
                    if actual_deposit_type == 'percentage':
                        final_deposit_value = (ticket.price * deposit_value / 100) if ticket.exists() else deposit_value
                        final_deposit_type = 'usd'
                    else:
                        final_deposit_value = deposit_value
                        final_deposit_type = actual_deposit_type

                    form_deposit_data[ticket_id] = {
                        'value': final_deposit_value,
                        'type': final_deposit_type,
                        'original_percentage': deposit_value if actual_deposit_type == 'percentage' else None,
                        'plan_id': plan_id,
                        'auto_payment_enabled': auto_payment_enabled
                    }

        deposit_data = modal_deposit_data if modal_deposit_data else form_deposit_data

        if deposit_data:
            request.session['event_deposit_data'] = deposit_data
            request.session['event_deposit_event_id'] = event.id
        else:
            pass

        request.session.pop('modal_deposit_data', None)
        return super().registration_confirm(event, **post)

    def _create_attendees_from_registration_post(self, event, registration_data):
        # we have at least one registration linked to a ticket -> sale mode activate
        if not any(info.get('event_ticket_id') for info in registration_data):
            return super()._create_attendees_from_registration_post(event, registration_data)

        event_ticket_ids = [registration['event_ticket_id'] for registration in registration_data if registration.get('event_ticket_id')]
        event_ticket_by_id = {
            event_ticket.id: event_ticket
            for event_ticket in request.env['event.event.ticket'].sudo().browse(event_ticket_ids)
        }

        if all(event_ticket.price == 0 for event_ticket in event_ticket_by_id.values()) and not request.website.sale_get_order().id:
            # all chosen tickets are free AND no existing SO -> skip SO and payment process
            return super()._create_attendees_from_registration_post(event, registration_data)

        order_sudo = request.website.sale_get_order(force_create=True)
        if order_sudo.state != 'draft':
            request.website.sale_reset()
            order_sudo = request.website.sale_get_order(force_create=True)

        tickets_data = defaultdict(int)
        for data in registration_data:
            event_ticket_id = data.get('event_ticket_id')
            if event_ticket_id:
                tickets_data[event_ticket_id] += 1

        # Get deposit data from session
        deposit_data = request.session.get('event_deposit_data', {})
        deposit_event_id = request.session.get('event_deposit_event_id')

        cart_data = {}
        for ticket_id, count in tickets_data.items():
            ticket_sudo = event_ticket_by_id.get(ticket_id)
            deposit = deposit_data.get(str(ticket_id), False)

            cart_params = {
                'product_id': ticket_sudo.product_id.id,
                'add_qty': count,
                'event_ticket_id': ticket_id,
                'subscription_deposit_value': deposit and deposit['value'] or False,
                'subscription_deposit_type': deposit and deposit['type'] or False,
                'event_ticket_price': ticket_sudo.price  # Add actual ticket price
            }

            if deposit and deposit.get('plan_id'):
                cart_params['plan_id'] = deposit['plan_id']

            if deposit and deposit.get('auto_payment_enabled') is not None:
                cart_params['auto_payment_enabled'] = deposit['auto_payment_enabled']

            cart_values = order_sudo._cart_update(**cart_params)
            cart_data[ticket_id] = cart_values['line_id']

        for data in registration_data:
            event_ticket_id = data.get('event_ticket_id')
            event_ticket = event_ticket_by_id.get(event_ticket_id)
            if event_ticket:
                data['sale_order_id'] = order_sudo.id
                data['sale_order_line_id'] = cart_data[event_ticket_id]

        request.session['website_sale_cart_quantity'] = order_sudo.cart_quantity
        # Clean up session
        request.session.pop('event_deposit_data', None)
        request.session.pop('event_deposit_event_id', None)
        return WebsiteEventController._create_attendees_from_registration_post(self, event, registration_data)
