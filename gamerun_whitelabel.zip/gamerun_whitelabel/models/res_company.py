from odoo import fields, models, tools
import base64


class Company(models.Model):
    _inherit = "res.company"

    def _default_favicon(self):
        with tools.file_open('web/static/img/favicon.ico', 'rb') as f:
            return base64.b64encode(f.read())

