from bs4 import BeautifulSoup
from odoo import models, api


class MailTemplateInherit(models.Model):
    _inherit = 'mail.template'

    def set_powered_by_gamerun(self):
        for template in self.search([]):
            template.body_html = template._replace_powered_by(template.body_html)

    @api.model
    def replace_powered_by_odoo(self):
        for template in self.search([]):
            template.body_html = template._replace_powered_by(template.body_html)

    def _replace_powered_by(self, html):
        if not html:
            return html

        soup = BeautifulSoup(html, 'html.parser')

        # Find all links containing odoo.com
        for a in soup.find_all('a', href=lambda x: x and 'odoo.com' in x):
            a['href'] = 'https://gamerun.ai'
            if 'Powered by' in a.text:
                a.string = 'Powered by GameRun'
            elif 'Odoo' in a.text:
                a.string = 'GameRun'

        return str(soup)

    @api.model
    def create(self, vals):
        """Override create to handle new templates"""
        if 'body_html' in vals:
            vals['body_html'] = self._replace_powered_by(vals['body_html'])
        return super().create(vals)

    def write(self, vals):
        """Override write to handle existing templates"""
        if 'body_html' in vals:
            vals['body_html'] = self._replace_powered_by(vals['body_html'])
        return super().write(vals)
