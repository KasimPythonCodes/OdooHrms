# kasim start 8/dec/25 bugid-'https://gitlab.rmgtoday.com/hrms/hrms_updation/-/issues/10'

from odoo import models, fields, api
from odoo.exceptions import ValidationError
import uuid
from odoo.http import request

class HrPayrollConfigureTemplates(models.Model):
    _name = "hr.payroll.configure.templates"
    _description = "Hr Payroll Configure Templates"
    _order = "id desc"
    name = fields.Char("Reference")
    state =  fields.Char("State")
    mw = fields.Float(string='Minimum Wages')  # Minimum Wages
    basic = fields.Float(string='Basic')
    hra = fields.Float(string='HRA')
    statuary_bonus = fields.Float(string='Statuary Bonus')
    special_allow = fields.Float(string='Special Allowance')
    gross = fields.Float(string='Gross')
    esic_ded = fields.Char(string='ESIC Deduction')
    pf = fields.Float(string='PF')
    pf_admin_ch = fields.Float(string='PF Admin Charges')
    esic = fields.Float(string='ESIC')
    ctc = fields.Float(string='CTC')
    pf_emp = fields.Float(string='PF Employee')
    esic_emp = fields.Float(string='ESIC Employer')
    nth = fields.Float(string='Net Salary')

    # @api.model_create_multi
    # def create(self, vals_list):
    #     ip = request.httprequest.environ.get('REMOTE_ADDR')
    #     print(ip,"IIIIIIIIIIIIIIPPPPPPPPPPPPPPPPPPPPPPPPPPPPPIIIIIIIIIIIIIIIIIIIIIIIIIIIIIPPPPPPPPPPPPPPPPPPPIPIPIPIIPPPPPPPPPPPPPIIIIIIIIIIIIIIIIPPPPP............................................")
    #     if isinstance(vals_list, dict):
    #         vals_list = [vals_list]
    #     records = super(HrPayrollConfigureTemplates, self).create(vals_list)
    #     for res, vals in zip(records, vals_list):
    #         try:
    #             if 'state' in vals:
    #                 vals.pop('state')
    #
    #             st_type_id = self.env['hr.payroll.structure.type'].search(
    #                 [('name', 'in', ['employee', 'Employee'])], limit=1
    #             )
    #
    #             struct_id = self.env['hr.payroll.structure'].sudo().search([
    #                 ('name', '=', "FOS-TL-Structure-" + res.state)
    #             ], limit=1)
    #
    #             DISPLAY_NAMES = {
    #                 "mw": "Minimum Wages",
    #                 "hra": "HRA",
    #                 "gross": "Gross",
    #                 "statuary_bonus": "Statuary Bonus",
    #                 "basic": "Basic Salary",
    #                 "special_allow": "Special Allowance",
    #                 "esic": "ESIC",
    #                 "esic_ded": "ESIC Deduction",
    #                 "pf": "Provident Fund",
    #                 "pf_admin_ch": "PF Admin Charge + EDLI",
    #                 "ctc": "CTC",
    #                 "pf_emp": "PF Employee",
    #                 "esic_emp": "ESIC Employer",
    #                 "nth": "Net Salary"
    #             }
    #
    #             DISPLAY_CODES = {
    #                 "mw": "MW",
    #                 "hra": "HRA",
    #                 "gross": "GSS",
    #                 "statuary_bonus": "SBA",
    #                 "basic": "BASIC",
    #                 "special_allow": "SAA",
    #                 "esic": "ESIC",
    #                 "esic_ded": "ESICD",
    #                 "pf": "PFD",
    #                 "pf_admin_ch": "PFACEDLI",
    #                 "ctc": "CTC",
    #                 "pf_emp": "PFEMPR",
    #                 "esic_emp": "ESIC EMPR",
    #                 "nth": "NET"
    #             }
    #
    #             DISPLAY_CATEGORIES = {
    #                 "mw": "Wages",
    #                 "hra": "Allowance",
    #                 "gross": "Gross",
    #                 "statuary_bonus": "Allowance",
    #                 "basic": "Basic",
    #                 "special_allow": "Allowance",
    #                 "esic": "Deduction",
    #                 "esic_ded": "Deduction",
    #                 "pf": "Deduction",
    #                 "pf_admin_ch": "Deduction",
    #                 "ctc": "Gross",
    #                 "pf_emp": "Deduction",
    #                 "esic_emp": "Deduction",
    #                 "nth": "Net"
    #             }
    #
    #             rule_lines = []
    #
    #             for index, key in enumerate(vals.keys(), start=1):
    #                 if DISPLAY_CODES.get(key)=='MW':
    #                     continue
    #                 category = self.env['hr.salary.rule.category'].search(
    #                     ['|',
    #                      ('name', '=', DISPLAY_CATEGORIES.get(key)),
    #                      ('code', '=', DISPLAY_CODES.get(key))],
    #                     limit=1
    #                 )
    #
    #                 if not category:
    #                     category = self.env['hr.salary.rule.category'].create({
    #                         'name': DISPLAY_CATEGORIES.get(key),
    #                         'code': DISPLAY_CODES.get(key)
    #                     })
    #
    #                 rule_lines.append(
    #                     (0, 0, {
    #                         'category_id': category.id,
    #                         'name': DISPLAY_NAMES.get(key),
    #                         'code': DISPLAY_CODES.get(key),
    #                         'sequence': index,
    #                         'active': True,
    #                         'appears_on_payslip': True,
    #                         'appears_on_employee_cost_dashboard': True,
    #                         'appears_on_payroll_report': True,
    #                         'condition_select': 'none',
    #                         'amount_select': 'fix' if DISPLAY_CODES.get(key)=='MW' else 'code',
    #                         # 'amount_select': 'code',
    #                         'quantity': 1,
    #                         'amount_fix': vals.get(key) if not isinstance(vals.get(key), str) else 0,
    #                     })
    #                 )
    #
    #             if not struct_id:
    #                 struct_id = self.env['hr.payroll.structure'].sudo().create({
    #                     "name": "FOS-TL-Structure-" + res.state,
    #                     'type_id': st_type_id.id,
    #                     'use_worked_day_lines': True,
    #                     'country_id': self.env['res.country'].search([('name', '=', 'India')], limit=1).id,
    #                     'report_id': self.env['ir.actions.report'].search([('name', '=', 'Payslip')], limit=1).id,
    #                     'schedule_pay': 'monthly',
    #                     'rule_ids': rule_lines,
    #                 })
    #             else:
    #                 struct_id.sudo().write({
    #                     'rule_ids': rule_lines
    #                 })
    #
    #         except Exception as e:
    #             print("ERROR:", str(e))
    #
    #     return records

    @api.model_create_multi
    def create(self, vals_list):
        ip = request.httprequest.environ.get('REMOTE_ADDR')
        print(f"IP ADDRESS ID {ip} -:------++++++++++------------++++++++++++++")
        if isinstance(vals_list, dict):
            vals_list = [vals_list]
        records = super(HrPayrollConfigureTemplates, self).create(vals_list)
        for res, vals in zip(records, vals_list):
            try:
                if 'state' in vals:
                    vals.pop('state')

                st_type_id = self.env['hr.payroll.structure.type'].search(
                    [('name', 'in', ['employee', 'Employee'])], limit=1
                )

                struct_id = self.env['hr.payroll.structure'].sudo().search([
                    ('name', '=', "FOS-TL-Structure-" + res.state)
                ], limit=1)

                DISPLAY_NAMES = {
                    "mw": "Minimum Wages",
                    "hra": "HRA",
                    "gross": "Gross",
                    "statuary_bonus": "Statuary Bonus",
                    "basic": "Basic Salary",
                    "special_allow": "Special Allowance",
                    "esic": "ESIC",
                    "esic_ded": "ESIC Deduction",
                    "pf": "Provident Fund",
                    "pf_admin_ch": "PF Admin Charge + EDLI",
                    "ctc": "CTC",
                    "pf_emp": "PF Employee",
                    "esic_emp": "ESIC Employer",
                    "nth": "Net Salary"
                }

                DISPLAY_CODES = {
                    "mw": "MW",
                    "hra": "hra_allowance",
                    "gross": "GSS",
                    "statuary_bonus": "sb_allowance",
                    "basic": "BASIC",
                    "special_allow": "sa",
                    "esic": "esic_deduction",
                    "esic_ded": "esicd_deduction",
                    "pf": "pfd_deduction",
                    "pf_admin_ch": "pfacedlt_deduction",
                    "ctc": "CTC",
                    "pf_emp": "pfempr_deduction",
                    "esic_emp": "esic_empr_deduction",
                    "nth": "net"
                }

                DISPLAY_CATEGORIES = {
                    "mw": "Wages",
                    "hra": "Allowance",
                    "gross": "Gross",
                    "statuary_bonus": "Allowance",
                    "basic": "Basic",
                    "special_allow": "Allowance",
                    "esic": "Deduction",
                    "esic_ded": "Deduction",
                    "pf": "Deduction",
                    "pf_admin_ch": "Deduction",
                    "ctc": "Gross",
                    "pf_emp": "Deduction",
                    "esic_emp": "Deduction",
                    "nth": "Net"
                }

                rule_lines = []

                for index, key in enumerate(vals.keys(), start=1):
                    if DISPLAY_CODES.get(key) == 'MW':
                        continue
                    category = self.env['hr.salary.rule.category'].search(
                        [
                         ('name', '=', DISPLAY_CATEGORIES.get(key)),
                         ('code', '=', DISPLAY_CODES.get(key))],
                        limit=1
                    )

                    if not category:
                        category = self.env['hr.salary.rule.category'].create({
                            'name': DISPLAY_CATEGORIES.get(key),
                            'code': DISPLAY_CODES.get(key)
                        })

                    rule_lines.append(
                        (0, 0, {
                            'category_id': category.id,
                            'name': DISPLAY_NAMES.get(key),
                            'code': DISPLAY_CODES.get(key),
                            'sequence': index,
                            'active': True,
                            'appears_on_payslip': True,
                            'appears_on_employee_cost_dashboard': True,
                            'appears_on_payroll_report': True,
                            'condition_select': 'none',
                            # 'amount_select': 'fix' if DISPLAY_CODES.get(key)=='MW' else 'code',
                            'amount_select': 'code' if DISPLAY_CODES.get(key) in ['BASIC','net'] else 'fix' ,
                            # 'amount_select': 'code',
                            'quantity': 1,
                            'amount_fix': vals.get(key) if not isinstance(vals.get(key), str) else 0,
                        })
                    )

                if not struct_id:
                    self.env['hr.payroll.structure'].sudo().create({
                    "name": "FOS-TL-Structure-" + res.state,
                    'type_id': st_type_id.id,
                    'use_worked_day_lines': True,
                    'country_id': self.env['res.country'].search([('name', '=', 'India')], limit=1).id,
                    'report_id': self.env['ir.actions.report'].search([('name', '=', 'Payslip')], limit=1).id,
                    'schedule_pay': 'monthly',
                    'rule_ids': rule_lines,
                    })
                else:
                    struct_id.sudo().write({
                        'rule_ids': rule_lines
                    })

            except Exception as e:
                print("ERROR:", str(e))

        return records

# kasim end 8/dec/25 bugid-'https://gitlab.rmgtoday.com/hrms/hrms_updation/-/issues/10'


# class CustomSalaryRule(models.Model):
#     _name = 'custom.salary.rule'
#     _description = 'Custom Salary Rule'
#
#     name = fields.Char(string="Rule Name", required=True)
#     category = fields.Char("Category")
#     code = fields.Char(string="Code", required=True)
#     sequence = fields.Integer(string="Sequence")
#     structure = fields.Char(string="Salary Structure")
#     active = fields.Boolean(string="Active", default=True)
#     appears_on_payslip = fields.Boolean(string="Appears on Payslip", default=True)
#     view_on_employer_cost_dashboard = fields.Boolean(string="View on Employer Cost Dashboard")
#     view_on_payroll_reporting = fields.Boolean(string="View on Payroll Reporting")
#     description = fields.Text(string="Description")
#     condition_based_on = fields.Char(string="Condition Based on?")
#     condition_range_min = fields.Float(string="Minimum Range")
#     condition_range_max = fields.Float(string="Maximum Range")
#     condition_python = fields.Text(string="Python Condition")
#     amount_type = fields.Char(string="Amount Type?")
#     quantity = fields.Float(string="Quantity", default=1.0)
#     fixed_amount = fields.Float(string="Fixed Amount")
#     percentage = fields.Float(string="Percentage (%)")
#     percentage_base = fields.Char(string="Percentage Base",help="Example: basic, gross, hra")
#     amount_python_compute = fields.Text(string="Python Code for Amount Compute")
#     partner_id = fields.Many2one('res.partner', string="Partner")


# class HrPayrollStructure(models.Model):
#     _inherit = 'hr.payroll.structure'
#
#     company_id = fields.Many2one('res.company', string="Company", default=lambda self: self.env.company)
#
# class HrSalaryRule(models.Model):
#     _inherit = 'hr.salary.rule'
#     company_id = fields.Many2one('res.company', string="Company", default=lambda self: self.env.company)

from calendar import monthrange

class HrPayslip(models.Model):
    _inherit = 'hr.payslip'

    month_days = fields.Integer(compute='_compute_month_days', store=True)

    def _compute_month_days(self):
        for slip in self:
            slip.month_days = monthrange(
                slip.date_from.year,
                slip.date_from.month
            )[1]

# kasim start 19/jan/26 bugid-'https://gitlab.rmgtoday.com/hrms/hrms_updation/-/issues/10'

class Contract(models.Model):
    _inherit = 'hr.contract'

    state_wise_struct_id = fields.Many2one('hr.payroll.structure','State Structure')

    def write(self, vals):
        res = super().write(vals)
        set_basic_amount_flag = request.session.get('set_basic_amount_flag')
        if not set_basic_amount_flag:
            for contract in self:
                state_changed_to_open = vals.get('state') == 'open'
                state_changed_to_open1 = vals.get('state') == 'draft'
                struct_changed = 'state_wise_struct_id' in vals
                if contract.state == 'open' and contract.state_wise_struct_id and state_changed_to_open:
                    basic_rule = contract.state_wise_struct_id.rule_ids.filtered(
                        lambda r: r.code == 'BASIC'
                    )[:1]

                    if basic_rule:
                        contract.wage = basic_rule.amount_fix
                        print(contract.wage,"KKKKKKKKKKKKKKKKKKK")
                if state_changed_to_open1:
                    contract.wage = 0.0
        request.session['set_basic_amount_flag']=False
        return res

    @api.onchange('state_wise_struct_id')
    def stateStructure(self):
        basic_rule=self.state_wise_struct_id.rule_ids.filtered(lambda r: r.code == 'BASIC')[:1]
        if basic_rule:
            request.session['set_basic_amount_flag']=True
            self.wage = basic_rule.amount_fix



# kasim end 19/jan/26 bugid-'https://gitlab.rmgtoday.com/hrms/hrms_updation/-/issues/10'
