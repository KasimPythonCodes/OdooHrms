/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import { ControlButtons } from
    "@point_of_sale/app/screens/product_screen/control_buttons/control_buttons";
import { useService } from "@web/core/utils/hooks";
import { AlertDialog } from "@web/core/confirmation_dialog/confirmation_dialog";
import { rpc } from "@web/core/network/rpc";

patch(ControlButtons.prototype, {
    setup() {
        super.setup();
        console.log("✅ Custom Patch Active");

        this.orm = useService("orm");
        this.dialog = useService("dialog");
    },

    async onClickButton() {
        try {
            // RPC CALL (POS SAFE)
//            const res = await rpc("/pos/custom/data");
            window.open("/pos/custom/data", "_blank");
        } catch (error) {
            console.error("Failed:", error);

            await this.dialog.add(AlertDialog, {
                title: "Error",
                body: "Server error while sending request",
            });
        }
    },
});






