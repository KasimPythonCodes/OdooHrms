{
    "name": "POS Custom Button",
    "version": "18.0.1.0.0",
    "category": "Point of Sale",
    "depends": ["base","point_of_sale"],
    "data":['views/pso_prd_tem.xml'],
    "assets": {
        "point_of_sale._assets_pos": [
            "pos_custom_page/static/src/app/CustomPage.js",
            "pos_custom_page/static/src/app/CustomPage.xml",
        ],
    },
    "installable": True,
}
