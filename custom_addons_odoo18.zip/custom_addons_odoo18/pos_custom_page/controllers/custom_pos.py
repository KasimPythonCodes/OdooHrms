from odoo import http
from odoo.http import request

class PosCustomController(http.Controller):

    @http.route("/pos/custom/data", type="http", auth="user",csrf=False)
    def get_custom_data(self,**kwargs):
        products = request.env["product.product"].sudo().search([])
        return request.render(
            'pos_custom_page.pos_custom_products_template',
            {'products': products,
             }
        )

