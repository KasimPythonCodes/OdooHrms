from odoo import models,fields,api,_


class OtpSend(models.Model):
    _name = 'otp.send'
    _description = 'OTP Send'

    account_sid = fields.Char(string='Account SID', required=True)
    auth_token = fields.Char(string='Auth Token', required=True)
    from_number = fields.Char(string="From Number")
    message_body = fields.Html(string='Your Massage', translate=True)
    otp_id = fields.Char(string="Otp Code")
    expiry_time = fields.Datetime('Expiry Time')

