{
    "name": "Sign OTP Integration",
    "version": "1.0",
    "summary": "Twilio OTP verification before signing documents",
    "category": "Sign",
    "author": "Your Name",
    "depends": ["sign","mail_mobile"],
    "assets": {
        # 'sign.assets_public_sign': [
        #     "sign_otp_integration/static/src/js/sign_otp_button.js",
        # ],
# "web.assets_backend": [
#             "sign_otp_integration/static/src/js/sign_otp_button.js",
#         ],
 "web.assets_frontend": [
        "sign_otp_integration/static/src/js/sign_otp_button.js",
    ],

    },
    "data": [
        "security/ir.model.access.csv",
        "views/sign_doc_sign_inherit.xml",
        "views/otp_form_view.xml",
    ],
    "application": False,
    "installable": True,
}
