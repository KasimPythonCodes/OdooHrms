{
    "name": "Employee Extension",
    "version": "1.0",
    "summary": "Employee Attendence",
    "author": "Salman",
    "depends": ['base','hr','hr_attendance'],
    "data": [
            'security/ir.model.access.csv',
            'data/ir_cron_auto_attendance.xml',
            'views/hr_attendence_inherit.xml',
            'views/hr_employee_inherit.xml',
            'views/announcement_view.xml',
    ],
    "application": False,
    "installable": True,
}
