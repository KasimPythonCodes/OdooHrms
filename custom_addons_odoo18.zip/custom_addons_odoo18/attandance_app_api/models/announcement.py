from odoo import models,fields,api,_
from datetime import date

class Announcement(models.Model):
    _name = 'event.announcement'
    _description = 'Event Announcements'

    user_name = fields.Char("User Name")
    user_img = fields.Binary("User Image")
    event_title = fields.Char("Event Title")
    event_img = fields.Binary("Event Image")
    event_time = fields.Datetime("Event Time")
    event_description =fields.Text("Event Description")