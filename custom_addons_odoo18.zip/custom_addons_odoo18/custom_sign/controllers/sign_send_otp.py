from odoo import http
from odoo.http import request
import random

class SignOTPController(http.Controller):

    @http.route('/sign/send_otp', type='json', auth='public', csrf=False, cors='*')
    def send_otp(self, phone):
        """Send OTP to user’s phone"""
        if not phone:
            return {"status": 400, "message": "Please enter a mobile number."}

        otp = random.randint(1000, 9999)

        # Example logic to store the OTP in session
        request.session['sign_otp'] = otp

        # Here you can integrate Twilio, MSG91, etc.
        # For now, just respond for debugging:
        return {"status": 200, "message": f"OTP {otp} sent to {phone}"}

