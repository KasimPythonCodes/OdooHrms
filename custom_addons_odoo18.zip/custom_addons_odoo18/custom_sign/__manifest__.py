# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
{
    'name': 'Custom Sign',
    'version': '1.0',
    'category': 'Sales/Sign',
    'sequence': 106,
    'summary': "Send documents to sign online and handle filled copies",
    'description': """
Sign and complete your documents easily. Customize your documents with text and signature fields and send them to your recipients.\n
Let your customers follow the signature process easily.
    """,
    'website': 'https://www.odoo.com/app/sign',
    'depends': ['mail', 'attachment_indexation', 'portal', 'sms','web'],
    'data': [
        'views/sign_send_otp.xml',
    ],
    'demo': [
    ],
    'application': True,
    'installable': True,
    'license': 'OEEL-1',
    'assets': {
        # 👇 Use this for the Sign document public page
        'sign.assets_public_sign': [  # web.assets_frontend
            '/custom_sign/static/src/js/sign_send_otp.js',
        ],
    },
}
