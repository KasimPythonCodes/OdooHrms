/** @odoo-module **/

/** @odoo-module **/

import { registry } from "@web/core/registry";
import { patch } from "@web/core/utils/patch";
import { SignableDocument } from "@sign/signing/signable_document";
import { rpc } from "@web/core/network/rpc";

console.log("✅ Custom Sign OTP JS loaded");

patch(SignableDocument.prototype, {
    setup() {
        super.setup();
        console.log("Custom Sign Patch Active");
        setTimeout(this._attachOtpEvents.bind(this), 2000); // ensure DOM is ready
    },

    _attachOtpEvents() {
        const sendBtn = document.querySelector(".o_send_otp_button");
        const verifyBtn = document.querySelector(".o_verify_otp_button");
        const phoneInput = document.querySelector("#otp_number");
        const otpInput = document.querySelector("#otp_input");
        const otpSection = document.querySelector("#otp_verify_section");
        const responseBox = document.querySelector("#otp_response");

        if (!sendBtn) {
            console.warn("OTP UI not found in sign iframe");
            return;
        }

        console.log("OTP UI found and events attached");

        sendBtn.addEventListener("click", async () => {
            const phone = phoneInput?.value?.trim();
            if (!phone) {
                responseBox.textContent = "Please enter a mobile number.";
                responseBox.style.color = "red";
                return;
            }

            try {
                const res = await rpc("/sign/send_otp", { phone });
                if (res.status === 200) {
                    responseBox.textContent = "OTP sent successfully!";
                    responseBox.style.color = "green";
                    otpSection.style.display = "block";
                } else {
                    responseBox.textContent = res.message || "Failed to send OTP.";
                    responseBox.style.color = "red";
                }
            } catch (error) {
                console.error("Send OTP failed:", error);
                responseBox.textContent = "Server error while sending OTP.";
                responseBox.style.color = "red";
            }
        });

        verifyBtn?.addEventListener("click", async () => {
            const otp = otpInput?.value?.trim();
            const phone = phoneInput?.value?.trim();
            if (!otp) {
                responseBox.textContent = "Please enter OTP.";
                responseBox.style.color = "red";
                return;
            }

            try {
                const res = await rpc("/sign/verify_otp", { phone, otp });
                if (res.status === 200) {
                    responseBox.textContent = "OTP verified successfully!";
                    responseBox.style.color = "green";
                } else {
                    responseBox.textContent = res.message || "Invalid OTP.";
                    responseBox.style.color = "red";
                }
            } catch (error) {
                console.error("Verify OTP failed:", error);
                responseBox.textContent = "Server error while verifying OTP.";
                responseBox.style.color = "red";
            }
        });
    },
});










///** @odoo-module **/
//
//import { rpc } from "@web/core/network/rpc";
//
//console.log("custom sign_send_otp.js loaded...");
//
//// ✅ Ensure DOM is ready (works even in sign iframe)
//document.addEventListener("DOMContentLoaded", () => {
//    console.log("✅custom DOM ready in Sign page");
//
//    const button = document.querySelector(".o_send_otp_button");
//    const input = document.querySelector("#otp_number");
//    const responseBox = document.querySelector("#otp_response");
//
//    if (!button) {
//        console.warn("OTP button not found");
//        return;
//    }
//
//    button.addEventListener("click", async () => {
//        const phone = input?.value?.trim();
//        if (!phone) {
//            responseBox.textContent = "Please enter a phone number";
//            responseBox.style.color = "red";
//            return;
//        }
//
//        try {
//            const res = await rpc("/sign/send_otp", { phone });
//            responseBox.textContent = res.message || "OTP sent!";
//            responseBox.style.color = res.status === 200 ? "green" : "red";
//        } catch (error) {
//            console.error("OTP send failed", error);
//            responseBox.textContent = "Failed to send OTP";
//            responseBox.style.color = "red";
//        }
//    });
//});
