from django.db import models
import constants
from django.core.validators import validate_email, RegexValidator


# Create your models here.


class ContactDetails(models.Model):
    firstName = models.CharField(max_length=constants.CHAR_LENGTH)
    lastName = models.CharField(max_length=constants.CHAR_LENGTH)
    email = models.EmailField(validators=[validate_email])
    phone = models.CharField(max_length=20, validators=[RegexValidator(regex=r'^\+?1?\d{9,15}$',
                                                                       message="Phone number must be entered in the format: '+999999999'. Up to 15 digits allowed.")])
    agenda = models.CharField(max_length=constants.CHAR_LENGTH)
    comments = models.CharField(max_length=constants.CHAR_LENGTH)

