from django.db import models
import constants

# Create your models here.


class Image(models.Model):
    imageId = models.IntegerField(blank=True, null=True)
    imageName = models.CharField(max_length=constants.CHAR_LENGTH, blank=True, null=True)
    imageUrl = models.URLField(max_length=constants.CHAR_LENGTH, blank=True, null=True)
    uploadedAt = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.imageUrl
