from rest_framework.response import Response
from django.http import JsonResponse
from bs4 import BeautifulSoup
import requests
import constants


def fetch_post_content(postname, site_url):

    api_url = f"{site_url}/wp-json/wp/v2/posts?slug={postname}"
    response = requests.get(api_url)

    if response.status_code == 200:
        post_data = response.json()
        return post_data[0]['content']['rendered'], post_data[0]['id']  # HTML content
    else:
        return JsonResponse({'status':'false','message': constants.CONTENT_ERROR}, status=500)


def extract_paragraphs_from_html(html_content: str):
    soup = BeautifulSoup(html_content, 'html.parser')
    paragraphs = [p.get_text() for p in soup.find_all('p')]
    return paragraphs


def create_structured_json(paragraphs: list):
    result = {}  # Initialize an empty dictionary to hold different parts

    for i in paragraphs:
        if ":" in i:
            # Split by the first occurrence of ":" to get the key and value
            key, value = i.split(":", 1)

            # Extract the part number from the prefix (e.g., '1-', '2-')
            part_number = key.split("-", 1)[0].strip()  # Get the numeric part like '1' or '2'
            part_key = f"Part{part_number}"  # Create part key dynamically (e.g., 'Part1', 'Part2')

            # Remove the numeric prefix from the key and clean it up
            key = key.split("-", 1)[1].strip()
            value = value.strip()  # Trim any extra spaces

            # Add the key-value pair to the correct part in the dictionary
            if part_key not in result:
                result[part_key] = {}  # Initialize the part if it doesn't exist

            result[part_key][key] = value  # Add the key-value pair to the correct part
        else:
            raise ValueError(f"Input string '{i}' doesn't contain a ':' separator")
    return result
