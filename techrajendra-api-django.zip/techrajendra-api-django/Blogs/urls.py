from django.urls import path
from .views import *

urlpatterns = [
    path('post/<slug:postname>/', Content.as_view(), name='content'),
    path('upload/image/<int:image_id>', ImageUploadView.as_view(), name='image')
]