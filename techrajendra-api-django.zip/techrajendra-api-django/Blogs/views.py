from rest_framework.exceptions import APIException
import boto3
from botocore.exceptions import NoCredentialsError
from rest_framework.views import APIView
from rest_framework import status
from django.conf import settings
import constants
from .utils import *
from .models import Image
from tech_rajendra_backend import settings

# Create your views here.
class Content(APIView):
    def get(self, request, postname):
        try:
            site_url = constants.SITE_URL
            # Fetch post content
            html_content, post_id = fetch_post_content(postname, site_url)
            print("Content fetched correctly.....!!!", html_content, post_id)

            # Extract paragraphs from HTML
            paragraphs = extract_paragraphs_from_html(html_content)

            # Create structured JSON
            structured_json = create_structured_json(paragraphs)
            image_url = Image.objects.filter(imageId=post_id).values('imageUrl')
            structured_json['image_url'] = image_url

            # Convert structured data to JSON format
            return Response(structured_json)

        except Exception as ex:
            raise APIException(f"An error occurred: {str(ex)}", code=500)


class ImageUploadView(APIView):
    def post(self, request, image_id, *args, **kwargs):
        print("POST method called")
        image = request.FILES.get("image", None)
        print("image------------------------>", image)

        if not image:
            return Response({"error": "No image provided"}, status=status.HTTP_400_BAD_REQUEST)

        s3_client = boto3.client(
            "s3",
            aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
            aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY,
            region_name=settings.AWS_S3_REGION_NAME,
            endpoint_url=f"https://s3.{settings.AWS_S3_REGION_NAME}.amazonaws.com"
        )
        print("s3--------------------------->>>", s3_client)

        try:
            print("in try reached---------------->>>>")
            file_name = image.name
            print("File name----------------->>", file_name)
            # Add metadata to indicate the content type as PNG
            s3_client.upload_fileobj(
                image,
                settings.AWS_STORAGE_BUCKET_NAME,
                file_name,
                ExtraArgs={"ContentType": "image/png"}
            )
            print("images uploaded successfully----------------------->>>>")

            imageName = file_name
            imageId = image_id
            imageUrl = f"https://{settings.AWS_STORAGE_BUCKET_NAME}.s3.amazonaws.com/{file_name}"

            print("name----------------->>>>", imageName, type(imageName))
            print("id------------------>>>", imageId, type(imageId))
            print("url-------------------------->>>>>>>>>", imageUrl, type(imageUrl))


            # Save the image URL to the database
            image_record = Image.objects.create(imageId=imageId, imageName=imageName, imageUrl=imageUrl)
            print('image record------------------', image_record)

            return Response({"image_url": image_record.imageUrl}, status=status.HTTP_201_CREATED)
        except NoCredentialsError:
            return Response({"error": "AWS credentials not found"}, status=status.HTTP_403_FORBIDDEN)
        except Exception as e:
            print("error-------------------->>>>")
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
