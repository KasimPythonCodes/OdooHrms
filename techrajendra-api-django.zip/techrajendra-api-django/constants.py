SITE_URL = "http://api.techrajendra.com"
CHAR_LENGTH = 500
CONTENT_ERROR = "Unable to fetch Content."
