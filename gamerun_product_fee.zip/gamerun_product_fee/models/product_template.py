# gamerun_product_fee/models/product_template.py
from odoo import models, fields, api


class ProductTemplate(models.Model):
    _inherit = 'product.template'

    is_service_charge = fields.Boolean('Service Charge Fee?')
    service_charge_type = fields.Selection([
        ('usd', 'USD'),
        ('percentage', 'Percentage(%)')
    ], default='usd')
    service_charge_value = fields.Float(string="Service Charge Value")

    @api.model
    def default_get(self, fields_list):
        defaults = super(ProductTemplate, self).default_get(fields_list)
        company = self.env.company
        if 'service_charge_type' in fields_list:
            defaults['service_charge_type'] = company.service_charge_type
        if 'service_charge_value' in fields_list:
            defaults['service_charge_value'] = company.service_charge_value or 0.0
        return defaults

    @api.onchange('service_charge_type')
    def onchange_service_charge_type(self):
        if not self.service_charge_type:
            self.service_charge_value = 0.0