# -*- coding: utf-8 -*-
from odoo import api, fields, models, _

class AccountMove(models.Model):
    _inherit = 'account.move'

    @api.depends(
        'invoice_line_ids.currency_rate',
        'invoice_line_ids.tax_base_amount',
        'invoice_line_ids.tax_line_id',
        'invoice_line_ids.price_total',
        'invoice_line_ids.price_subtotal',
        'invoice_payment_term_id',
        'partner_id',
        'currency_id',
    )
    def _compute_tax_totals(self):
        """Include the total ecommerce service fee into the base & total amounts."""
        super()._compute_tax_totals()
        for move in self:
            tax_totals = move.tax_totals
            subtotal = tax_totals['subtotals'][0]

            total_service_fee = 0
            # Sum only eCommerce fees
            for line in move.line_ids.filtered(lambda l: l.service_fee_ids):
                line_fees = line.service_fee_ids.filtered(lambda s: s.scope != 'pos')
                total_service_fee += sum(line_fees.mapped('fixed_fee'))

            subtotal['base_amount'] += total_service_fee
            subtotal['base_amount_currency'] += total_service_fee
            tax_totals['total_amount_currency'] += total_service_fee
            tax_totals['total_amount'] += total_service_fee

    @api.depends(
        'line_ids.matched_debit_ids.debit_move_id.move_id.origin_payment_id.is_matched',
        'line_ids.matched_debit_ids.debit_move_id.move_id.line_ids.amount_residual',
        'line_ids.matched_debit_ids.debit_move_id.move_id.line_ids.amount_residual_currency',
        'line_ids.matched_credit_ids.credit_move_id.move_id.origin_payment_id.is_matched',
        'line_ids.matched_credit_ids.credit_move_id.move_id.line_ids.amount_residual',
        'line_ids.matched_credit_ids.credit_move_id.move_id.line_ids.amount_residual_currency',
        'line_ids.balance',
        'line_ids.currency_id',
        'line_ids.amount_currency',
        'line_ids.amount_residual',
        'line_ids.amount_residual_currency',
        'line_ids.payment_id.state',
        'line_ids.full_reconcile_id',
        'state')
    def _compute_amount(self):
        """Add total ecommerce service fees to untaxed/total when website_id is present."""
        super()._compute_amount()
        for move in self:
            if move.website_id:
                total_service_fee = 0
                # Only ecommerce fees
                for line in move.line_ids.filtered(lambda l: l.service_fee_ids):
                    line_fees = line.service_fee_ids.filtered(lambda s: s.scope != 'pos')
                    total_service_fee += sum(line_fees.mapped('fixed_fee'))

                move.amount_untaxed += total_service_fee
                move.amount_total += total_service_fee


class AccountMoveLine(models.Model):
    _inherit = "account.move.line"

    service_fee_ids = fields.Many2many(related="product_id.service_fee_ids")
    global_service_fee_id = fields.Many2one("gamerun_product_fee.service_fee")
    price_before_fees = fields.Monetary(string='Total Before Fees', currency_field='currency_id')

    @api.depends('quantity', 'discount', 'price_unit', 'tax_ids', 'currency_id')
    def _compute_totals(self):
        """If line has eCommerce service fees, add them to the line's subtotal & total."""
        super()._compute_totals()
        order_lines = self.filtered(lambda l: l.service_fee_ids)
        for line in order_lines:
            if line.move_id.website_id:
                service_fee = sum(line.service_fee_ids.filtered(lambda s: s.scope != 'pos').mapped('fixed_fee'))
                line.price_subtotal += service_fee
                line.price_total += service_fee
