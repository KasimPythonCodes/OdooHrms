from . import sale
from . import custom_fee
from . import pos_sale
from . import product_template
# from . import account_move
from . import invoice
from . import company
from . import res_config_settings
