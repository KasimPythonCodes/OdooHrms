from odoo import _, api, fields, models


class ResCompany(models.Model):
    _inherit = "res.company"

    service_charge_type = fields.Selection([
        ('usd', 'USD'),
        ('percentage', 'Percentage(%)')
    ], default='usd')
    service_charge_value = fields.Float(string="Service Charge Value")

