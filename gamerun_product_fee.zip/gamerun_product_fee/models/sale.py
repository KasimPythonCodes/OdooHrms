# -*- coding: utf-8 -*-

import itertools
from collections import defaultdict
from odoo import api, fields, models, _

import logging
_logger = logging.getLogger(__name__)


class SaleOrder(models.Model):
    _inherit = "sale.order"

    @api.depends('order_line.price_subtotal', 'currency_id', 'company_id')
    def _compute_amounts(self):
        super(SaleOrder, self)._compute_amounts()
        for order in self:
            order.amount_untaxed = order.amount_untaxed - order.total_service_charge

    @api.depends('order_line.price_total', 'order_line.product_id')
    def _compute_service_charge_total(self):
        for order in self:
            total_fee = 0.0
            for line in order.order_line:
                if line.product_id.is_service_charge:
                    total_fee += line.price_unit
            order.total_service_charge = total_fee

    total_service_charge = fields.Monetary(
        string="Total Service Charge",
        currency_field='currency_id',
        compute="_compute_service_charge_total",
        store=True
    )
    # has_percentage_fee = fields.Boolean(
    #     compute="_compute_service_charge_total",
    #     store=True
    # )
    # percentage_fee_value = fields.Float(
    #     compute="_compute_service_charge_total",
    #     store=True
    # )

    def _discountable_order(self, reward):
        """Compute the `discountable` amount (and amounts per tax group) for the current order.

        :param reward: if provided, the reward whose discountable amounts must be computed.
            It must be applicable at the order level.
        :type reward: `loyalty.reward` record, can be empty to compute the amounts regardless of the
            program configuration

        :return: A tuple with the first element being the total discountable amount of the order,
            and the second a dictionary mapping each non-fixed taxes group to its corresponding
            total untaxed amount of the eligible order lines.
        :rtype: tuple(float, dict(account.tax: float))
        """
        self.ensure_one()
        reward.ensure_one()
        assert reward.discount_applicability == 'order'

        if reward.program_id.is_payment_program:
            # Gift cards and eWallets are applied on the total order amount
            lines = self.order_line
        else:
            # Other types of programs are not expected to apply on delivery lines
            lines = self.order_line - self._get_no_effect_on_threshold_lines()

        lines = lines.filtered(lambda li: not li.product_id.is_service_charge)

        discountable = 0
        discountable_per_tax = defaultdict(float)

        AccountTax = self.env['account.tax']
        order_lines = self.order_line.filtered(lambda x: not x.display_type)
        base_lines = []
        for line in order_lines:
            if line.product_id.is_service_charge:
                continue
            base_line = line._prepare_base_line_for_taxes_computation()
            taxes = base_line['tax_ids'].flatten_taxes_hierarchy()
            if not reward.program_id.is_payment_program:
                # To compute the discountable amount we get the subtotal and add
                # non-fixed tax totals. This way fixed taxes will not be discounted
                # This does not apply to Gift Cards and e-Wallet, where the total
                # order amount may be paid with the card balance
                taxes = taxes.filtered(lambda t: t.amount_type != 'fixed')
            base_line['discount_taxes'] = taxes
            base_lines.append(base_line)
        AccountTax._add_tax_details_in_base_lines(base_lines, self.company_id)
        AccountTax._round_base_lines_tax_details(base_lines, self.company_id)

        def grouping_function(base_line, tax_data):
            if not tax_data:
                return None
            return {
                'taxes': base_line['discount_taxes'],
                'skip': (
                    tax_data['tax'] not in base_line['discount_taxes']
                    or base_line['record'] not in lines
                ),
            }

        base_lines_aggregated_values = AccountTax._aggregate_base_lines_tax_details(base_lines, grouping_function)
        values_per_grouping_key = AccountTax._aggregate_base_lines_aggregated_values(base_lines_aggregated_values)
        for grouping_key, values in values_per_grouping_key.items():
            if grouping_key and grouping_key['skip']:
                continue

            taxes = grouping_key['taxes'] if grouping_key else self.env['account.tax']
            discountable += values['raw_base_amount_currency'] + values['raw_tax_amount_currency']
            discountable_per_tax[taxes] += (
                values['raw_base_amount_currency']
                + sum(
                    tax_data['raw_tax_amount_currency']
                    for base_line, taxes_data in values['base_line_x_taxes_data']
                    for tax_data in taxes_data
                    if tax_data and tax_data['tax'].price_include
                )
            )
        return discountable, discountable_per_tax

    def _discountable_specific(self, reward):
        """
        Special function to compute the discountable for 'specific' types of discount.
        The goal of this function is to make sure that applying a 5$ discount on an order with a
         5$ product and a 5% discount does not make the order go below 0.

        Returns the discountable and discountable_per_tax for a discount that only applies to specific products.
        """
        self.ensure_one()
        assert reward.discount_applicability == 'specific'

        lines_to_discount = self._get_specific_discountable_lines(reward).filtered(
            lambda line: bool(line.product_uom_qty and line.price_total and not line.product_id.is_service_charge)
        )
        discount_lines = defaultdict(lambda: self.env['sale.order.line'])
        order_lines = self.order_line - self._get_no_effect_on_threshold_lines()
        remaining_amount_per_line = defaultdict(int)
        for line in order_lines:
            if not line.product_uom_qty or not line.price_total or line.product_id.is_service_charge:
                continue
            remaining_amount_per_line[line] = line.price_total
            if line.reward_id.reward_type == 'discount':
                discount_lines[line.reward_identifier_code] |= line

        order_lines -= self.order_line.filtered("reward_id")
        cheapest_line = False
        for lines in discount_lines.values():
            line_reward = lines.reward_id
            discounted_lines = order_lines
            if line_reward.discount_applicability == 'cheapest':
                cheapest_line = cheapest_line or self._cheapest_line()
                discounted_lines = cheapest_line
            elif line_reward.discount_applicability == 'specific':
                discounted_lines = self._get_specific_discountable_lines(line_reward)
            if not discounted_lines:
                continue
            common_lines = discounted_lines & lines_to_discount
            if line_reward.discount_mode == 'percent':
                for line in discounted_lines:
                    if line_reward.discount_applicability == 'cheapest':
                        remaining_amount_per_line[line] *= (1 - line_reward.discount / 100 / line.product_uom_qty)
                    else:
                        remaining_amount_per_line[line] *= (1 - line_reward.discount / 100)
            else:
                non_common_lines = discounted_lines - lines_to_discount
                # Fixed prices are per tax
                discounted_amounts = defaultdict(int, {
                    line.tax_id.filtered(lambda t: t.amount_type != 'fixed'): abs(line.price_total)
                    for line in lines
                })
                for line in itertools.chain(non_common_lines, common_lines):
                    # For gift card and eWallet programs we have no tax but we can consume the amount completely
                    if lines.reward_id.program_id.is_payment_program:
                        discounted_amount = discounted_amounts[lines.tax_id.filtered(lambda t: t.amount_type != 'fixed')]
                    else:
                        discounted_amount = discounted_amounts[line.tax_id.filtered(lambda t: t.amount_type != 'fixed')]
                    if discounted_amount == 0:
                        continue
                    remaining = remaining_amount_per_line[line]
                    consumed = min(remaining, discounted_amount)
                    if lines.reward_id.program_id.is_payment_program:
                        discounted_amounts[lines.tax_id.filtered(lambda t: t.amount_type != 'fixed')] -= consumed
                    else:
                        discounted_amounts[line.tax_id.filtered(lambda t: t.amount_type != 'fixed')] -= consumed
                    remaining_amount_per_line[line] -= consumed

        discountable = 0
        discountable_per_tax = defaultdict(int)
        for line in lines_to_discount:
            discountable += remaining_amount_per_line[line]
            line_discountable = line.price_unit * line.product_uom_qty * (1 - (line.discount or 0.0) / 100.0)
            # line_discountable is the same as in a 'order' discount
            #  but first multiplied by a factor for the taxes to apply
            #  and then multiplied by another factor coming from the discountable
            taxes = line.tax_id.filtered(lambda t: t.amount_type != 'fixed')
            discountable_per_tax[taxes] += line_discountable *\
                (remaining_amount_per_line[line] / line.price_total)
        return discountable, discountable_per_tax

    def _discountable_cheapest(self, reward):
        """
        Returns the discountable and discountable_per_tax for a discount that applies to the cheapest line
        """
        self.ensure_one()
        assert reward.discount_applicability == 'cheapest'

        cheapest_line = self._cheapest_line()
        if not cheapest_line:
            return False, False

        discountable = 0
        discountable_per_tax = defaultdict(int)
        for line in cheapest_line:
            if line.product_id.is_service_charge:
                continue
            discountable += line.price_total
            taxes = line.tax_id.filtered(lambda t: t.amount_type != 'fixed')
            discountable_per_tax[taxes] += line.price_unit * (1 - (line.discount or 0) / 100)

        return discountable, discountable_per_tax

    @api.model_create_multi
    def create(self, vals_list):
        orders = super(SaleOrder, self).create(vals_list)
        for order in orders:
            order.add_service_charges()
        return orders

    def write(self, vals):
        res = super(SaleOrder, self).write(vals)
        self.add_service_charges()
        return res

    def _add_product_level_fee_lines(self):
        service_charge_product = self.env.ref('gamerun_product_fee.service_charge', raise_if_not_found=False)
        if not service_charge_product:
            return

        if self.state != 'draft':
            return

        existing_fee_lines = self.order_line.filtered(
            lambda l: l.product_id == service_charge_product
        )
        existing_fee_lines.unlink()

        reward_lines = self.order_line.filtered(lambda l: l.is_reward_line)
        product_lines = self.order_line.filtered(
            lambda l: l.product_id != service_charge_product and not l.is_reward_line
        )

        # Dictionary to hold discounted amount for each product line, starting with full subtotal
        discounted_amounts = {line.id: line.price_subtotal for line in product_lines}

        # Process each reward line to apportion its discount to affected product lines
        for reward_line in reward_lines:
            if not reward_line.reward_id:
                continue
            reward = reward_line.reward_id
            program = reward.program_id
            discount_amount = abs(reward_line.price_subtotal)

            # Get qualifying lines for this program's rules
            qualifying_lines = product_lines.filtered(
                lambda l: self._is_line_qualifying_for_program(l, program)
            )
            if not qualifying_lines:
                continue

            # Get applicable lines based on reward's apply_on
            applicable_lines = self._get_applicable_lines_for_reward(qualifying_lines, reward)
            if not applicable_lines:
                continue

            base_total = sum(applicable_lines.mapped('price_subtotal'))
            if base_total <= 0:
                continue

            # Apportion the actual discount amount proportionally
            for line in applicable_lines:
                line_proportion = line.price_subtotal / base_total
                line_discount_amount = discount_amount * line_proportion
                discounted_amounts[line.id] = max(discounted_amounts[line.id] - line_discount_amount, 0.0)

        # Now create fee lines using the discounted amounts
        for line in product_lines:
            discounted_amount = discounted_amounts.get(line.id, line.price_subtotal)
            product = line.product_id.product_tmpl_id
            qty = line.product_uom_qty

            fee = 0.0
            if product.service_charge_value:
                if product.service_charge_type == 'usd':
                    fee = product.service_charge_value * qty
                elif product.service_charge_type == 'percentage':
                    fee = discounted_amount * (product.service_charge_value / 100.0)

            if fee > 0:
                self.env['sale.order.line'].create({
                    'order_id': self.id,
                    'product_id': service_charge_product.id,
                    'product_uom_qty': 1.0,
                    'product_uom': service_charge_product.uom_id.id,
                    'price_unit': fee,
                    'tax_id': [(6, 0, service_charge_product.taxes_id.ids)],
                    'name': _("Service Charge for %s") % (line.product_id.display_name,),
                })

    def _get_applicable_lines_for_reward(self, qualifying_lines, reward):
        """Determine the product lines affected by the given reward."""
        apply_on = reward.discount_applicability
        if apply_on == 'order':
            return qualifying_lines
        elif apply_on == 'specific':
            applicable = self.env['sale.order.line']
            if not reward.discount_product_ids and not reward.discount_product_category_id and not reward.discount_product_tag_id:
                return qualifying_lines
            if reward.discount_product_ids:
                applicable |= qualifying_lines.filtered(
                    lambda l: l.product_id in reward.discount_product_ids
                )
            if reward.discount_product_category_id:
                applicable |= qualifying_lines.filtered(
                    lambda l: l.product_id.categ_id == reward.discount_product_category_id
                )
            if reward.discount_product_tag_id:
                applicable |= qualifying_lines.filtered(
                    lambda l: reward.discount_product_tag_id in l.product_id.product_tag_ids
                )
            return applicable if applicable else self.env['sale.order.line']
        elif apply_on == 'cheapest':
            if qualifying_lines:
                # Cheapest based on price_unit
                cheapest_line = min(qualifying_lines, key=lambda l: l.price_unit)
                return cheapest_line
        return self.env['sale.order.line']

    def _is_line_qualifying_for_program(self, line, program):
        """Check if a sale order line qualifies for the program's rules."""
        if not program.rule_ids:
            return True

        product = line.product_id

        for rule in program.rule_ids:
            matches = True
            if rule.product_ids and product not in rule.product_ids:
                matches = False
            if rule.product_category_id and product.categ_id != rule.product_category_id:
                matches = False
            if matches:
                return True
        return False

    def add_service_charges(self):
        for order in self:
            order._add_product_level_fee_lines()
        self.invalidate_recordset(['amount_total', 'order_line'])

    def _recompute_prices(self):
        super(SaleOrder, self)._recompute_prices()

    def _cart_update_order_line(self, product_id, quantity, order_line, **kwargs):
        res = super(SaleOrder, self)._cart_update_order_line(product_id, quantity, order_line, **kwargs)
        self.add_service_charges()
        return res

    def action_confirm(self):
        self.add_service_charges()
        _logger.info("Service charges applied before confirmation for order %s", self.name)
        return super(SaleOrder, self).action_confirm()


class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'

    def _show_in_cart(self):
        self.ensure_one()
        return not self.product_id.is_service_charge and super()._show_in_cart()
