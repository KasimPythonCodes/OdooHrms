from odoo import api, fields, models, _
from odoo.tools.misc import formatLang

class CustomFee(models.Model):
    _name = 'gamerun_product_fee.service_fee'
    _description = "Custom Service Fee"
    _order = "active desc, name"

    active = fields.Boolean(default=True)
    name = fields.Char(string='Name', required=True)
    # Renamed 'fixed' -> 'usd' in the selection
    type = fields.Selection([
        ('usd', 'USD'),
        ('percentage', 'Percentage(%)'),
    ], default='usd', string="Type")

    currency_id = fields.Many2one(
        'res.currency', 'Currency',
        default=lambda self: self.env.company.currency_id.id)
    # This field remains 'fixed_fee'; it stores a USD amount.
    fixed_fee = fields.Monetary(
        string='Service Fee', currency_field="currency_id", default=0.00)
    percentage_fee = fields.Float(string='Percentage Fee')
    fee = fields.Char(compute="_compute_fee_label", string='Fee')
    global_level = fields.Boolean('Global')
    description = fields.Text(string='Description')
    scope = fields.Selection([
        ('ecommerce', 'eCommerce'),
        ('pos', 'Point of Sale'),
        ('both', 'Both eCommerce and Point of Sale'),
    ], default='ecommerce', string="Apply on")

    product_ids = fields.Many2many(
        'product.template',
        'service_fee_product_rel', 'service_fee_ids', 'product_ids',
        string='Products'
    )

    def get_service_charge_product(self):
        return self.env.ref('gamerun_product_fee.service_charge').id

    def _get_integer(self):
        self.ensure_one()
        value = round(self.percentage_fee * 100, 2)
        return int(value) if value.is_integer() else value

    @api.depends('percentage_fee', 'fixed_fee', 'type')
    def _compute_fee_label(self):
        for item in self:
            if item.type == 'usd':
                item.fee = formatLang(
                    item.env, item.fixed_fee, dp="Product Price",
                    currency_obj=item.currency_id
                ).replace(' ', '')
            elif item.type == 'percentage':
                percentage = item._get_integer()
                item.fee = _("%(percentage)s%%", percentage=percentage)
            else:
                # Fallback if type is missing or invalid
                item.fee = "0.00"


class Product(models.Model):
    _inherit = "product.template"

    service_fee_ids = fields.Many2many(
        'gamerun_product_fee.service_fee',
        'service_fee_product_rel',
        'product_ids',
        'service_fee_ids',
        domain="[('global_level', '=', False)]",
        string='Service Fees'
    )
