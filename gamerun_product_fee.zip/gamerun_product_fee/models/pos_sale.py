# -*- coding: utf-8 -*-
from odoo import api, fields, models, _

class POSCustomFee(models.Model):
    _name = 'gamerun_product_fee.service_fee'
    _inherit = ['gamerun_product_fee.service_fee', 'pos.load.mixin']

    @api.model
    def _load_pos_data_domain(self, data):
        return [('active', '=', True), ('scope', '!=', 'ecommerce')]


class PosOrder(models.Model):
    _inherit = 'pos.order'

    def add_service_charges(self, scope=False):
        """Fetch all global service fees for POS and add them to the order lines."""
        service_charge_product = self.env.ref('gamerun_product_fee.service_charge', raise_if_not_found=False)
        if not service_charge_product:
            return

        existing_service_lines = self.order_line.filtered(lambda l: l.product_id.id == service_charge_product.id)
        domain = [('global_level', '=', True), ('scope', '!=', 'ecommerce')]
        service_fees = self.env['gamerun_product_fee.service_fee'].search(domain)
        last_sequence = max((self.order_line - existing_service_lines).mapped('sequence') + [0])

        if not service_fees or self.order_line == existing_service_lines:
            existing_service_lines.unlink()
            return

        # Process each service fee
        for fee in service_fees:
            last_sequence += 1
            fee_order_line = existing_service_lines.filtered(lambda l: l.global_service_fee_id.id == fee.id)

            # Calculate numeric amount for this fee
            # If 'usd', use fee.fixed_fee; if 'percentage', handle differently if needed.
            # But your original code is storing line price as fee.fee (string).
            # We'll keep the logic consistent with your approach:
            amount = fee.fee  # string usage in original code
            if fee_order_line:
                if fee_order_line.price_unit != amount or fee_order_line.name != fee.name:
                    fee_order_line.write({
                        'price_unit': amount,
                        'name': fee.name,
                        'sequence': last_sequence,
                    })
            else:
                self.write({'order_line': [(0, 0, {
                    'global_service_fee_id': fee.id,
                    'product_id': service_charge_product.id,
                    'product_uom_qty': 1,
                    'price_unit': amount,
                    'name': fee.name,
                    'sequence': last_sequence,
                })]})

        # Remove lines that are no longer relevant
        lines_for_removal = existing_service_lines.filtered(
            lambda l: l.global_service_fee_id.id not in service_fees.ids
        )
        if lines_for_removal:
            lines_for_removal.unlink()


class PosOrderLine(models.Model):
    _inherit = 'pos.order.line'

    service_fee_ids = fields.Many2many(related="product_id.service_fee_ids")
    global_service_fee_id = fields.Many2one("gamerun_product_fee.service_fee", string="Global Service")

    @api.model
    def _load_pos_data_fields(self, config_id):
        params = super()._load_pos_data_fields(config_id)
        params += ['global_service_fee_id']
        return params

    def _prepare_tax_base_line_values(self):
        """Use price_subtotal as the base for tax if service fees exist."""
        lines = super()._prepare_tax_base_line_values()
        for line in lines:
            product_id = line['product_id']
            if product_id.service_fee_ids:
                order_line = line['record']
                line['price_unit'] = order_line.price_subtotal
        return lines


class PosSession(models.Model):
    _inherit = "pos.session"

    @api.model
    def _load_pos_data_models(self, config_id):
        data = super()._load_pos_data_models(config_id)
        data += ["gamerun_product_fee.service_fee"]
        return data

    def _load_pos_data(self, data):
        data = super()._load_pos_data(data)
        data['data'][0]['_service_charge'] = self.env.ref('gamerun_product_fee.service_charge').id
        return data


class ProductProduct(models.Model):
    _name = 'product.product'
    _inherit = ['product.product', 'pos.load.mixin']

    @api.model
    def _load_pos_data_fields(self, config_id):
        params = super()._load_pos_data_fields(config_id)
        params += ['service_fee_ids']
        return params
