# -*- coding: utf-8 -*-

from odoo import api, models, _


class AccountMove(models.Model):
    _inherit = 'account.move'

    def _add_product_level_fee_lines(self):
        # Only process customer invoices in draft state
        if self.move_type not in ('out_invoice', 'out_refund') or self.state != 'draft':
            return

        service_charge_product = self.env.ref('gamerun_product_fee.service_charge', raise_if_not_found=False)
        if not service_charge_product:
            return

        existing_fee_lines = self.invoice_line_ids.filtered(lambda l: l.product_id == service_charge_product)
        existing_fee_lines.unlink()

        for line in self.invoice_line_ids.filtered(lambda l: l.product_id != service_charge_product):
            product = line.product_id.product_tmpl_id
            fee = 0.0
            qty = line.quantity

            if product.service_charge_value:
                if product.service_charge_type == 'usd':
                    fee = product.service_charge_value
                elif product.service_charge_type == 'percentage':
                    qty = 1
                    fee = line.price_subtotal * (product.service_charge_value / 100.0)

            if fee > 0:
                self.env['account.move.line'].create({
                    'move_id': self.id,
                    'product_id': service_charge_product.id,
                    'quantity': qty,
                    'price_unit': fee,
                    'tax_ids': [(6, 0, service_charge_product.taxes_id.ids)],
                    'name': _("Service Charge for %s") % (line.product_id.display_name,),
                    'account_id': service_charge_product.property_account_income_id.id or
                                  service_charge_product.categ_id.property_account_income_categ_id.id,
                })

    @api.model_create_multi
    def create(self, vals_list):
        moves = super(AccountMove, self).create(vals_list)
        for move, vals in zip(moves, vals_list):
            if not move.invoice_line_ids.filtered(lambda aml: aml.product_id.is_service_charge):
                move._add_product_level_fee_lines()
        return moves

    def _refresh_service_charges(self):
        """Remove all service charges and add them again based on current invoice lines"""
        for move in self.filtered(lambda m: m.move_type in ('out_invoice', 'out_refund') and m.state == 'draft'):
            service_charge_product = self.env.ref('gamerun_product_fee.service_charge', raise_if_not_found=False)
            if not service_charge_product:
                continue

            existing_fee_lines = move.invoice_line_ids.filtered(lambda l: l.product_id == service_charge_product)
            if existing_fee_lines:
                existing_fee_lines.unlink()

            move._add_product_level_fee_lines()

    def write(self, vals):
        res = super(AccountMove, self).write(vals)
        if 'invoice_line_ids' in vals:
            for move in self:
                move._refresh_service_charges()
        return res
