# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import _, api, fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    service_charge_type = fields.Selection(related='company_id.service_charge_type', readonly=False)
    service_charge_value = fields.Float(string="Service Charge Value", related='company_id.service_charge_value', readonly=False)
