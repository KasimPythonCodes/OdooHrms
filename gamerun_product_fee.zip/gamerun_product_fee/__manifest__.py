# noinspection PyStatementEffect
{
    'name': "GameRun Service Charge",
    'version': "18.0.2.0.12",
    'author': "GameRun",
    'license': "LGPL-3",
    'category': 'Sales/CRM',
    'website': 'https://www.gamerun.ai',
    'depends': ['base', 'product', 'web',
                'sale_management',
                'website_sale',
                'point_of_sale'],
    'assets': {
        'point_of_sale._assets_pos': [
            'gamerun_product_fee/static/src/js/pos.js',
        ],
        'point_of_sale.assets_prod': [
            'gamerun_product_fee/static/src/js/pos.js',
        ],
        
    },
    'data': [
        'security/ir.model.access.csv',
        'data/product_data.xml',
        'views/product_view.xml',
        'views/service_charge_view.xml',
        'views/pos_order_view.xml',
        'views/website_sale_view.xml',
        'views/res_config_settings.xml',
     ],
    'installable': True,
}
