/** @odoo-module **/

import { PosOrderline } from "@point_of_sale/app/models/pos_order_line";
import { PosOrder } from "@point_of_sale/app/models/pos_order";
import { OrderSummary } from "@point_of_sale/app/screens/product_screen/order_summary/order_summary";
import { PosStore } from "@point_of_sale/app/store/pos_store";
import { patch } from "@web/core/utils/patch";
import { usePos } from "@point_of_sale/app/store/pos_hook";
import { formatMonetary, formatText } from "@web/views/fields/formatters";
import { roundCurrency } from "@point_of_sale/app/models/utils/currency";
import { roundPrecision } from "@web/core/utils/numbers";

patch(PosStore.prototype, {
    async setup() {
        await super.setup(...arguments);
        // Load Service Charge Product
        this.service_product_id = await this.data.read("product.product", [this.session._service_charge]);
        // Load all global fees
        this.general_fee = this.models["gamerun_product_fee.service_fee"]
            .getAll()
            .filter((fee) => fee.global_level);
        if (this.get_order().lines.length > 0) {
            this.update_service_charges();
        }
    },

    get_order_total() {
        // Sum all non-service-charge lines
        const currentOrder = this.get_order();
        if (!currentOrder) {
            return 0;
        }
        const lines = currentOrder.lines.filter((line) => !line.global_service_fee_id);
        let total = 0;
        lines.forEach((line) => {
            const rounding = line.currency.rounding;
            total += roundPrecision(line.get_unit_price() * line.get_quantity(), rounding);
        });
        return total;
    },

    async set_global_service_products() {
        const currentOrder = this.get_order();
        const order_total = this.get_order_total();
        if (!this.service_product_id.length) {
            console.log("Service Charge Product not found");
            return;
        }
        // For each global fee, add or update line
        await this.general_fee.forEach((fee) => {
            let line = currentOrder.lines.find(
                (line) => line.global_service_fee_id && line.global_service_fee_id.id === fee.id
            );
            let fee_value = 0;
            if (fee.type === "usd") {
                fee_value = fee.fixed_fee;
            } else if (fee.type === "percentage") {
                const price = order_total * fee.percentage_fee;
                fee_value = roundCurrency(price, this.currency).toFixed(2);
            }
            if (line) {
                if (line.price_unit !== fee_value) {
                    line.set_unit_price(fee_value);
                }
                if (line.full_product_name !== fee.name) {
                    line.full_product_name = fee.name;
                }
            } else {
                this.models["pos.order.line"].create({
                    order_id: currentOrder,
                    product_id: this.service_product_id[0],
                    price_unit: fee_value,
                    global_service_fee_id: fee,
                    qty: 1,
                    price_type: "manual",
                    customer_note: fee.description,
                });
            }
        });
    },

    clean_remnant_service_charges() {
        const currentOrder = this.get_order();
        const general_fee_ids = this.general_fee.map((fee) => fee.id);
        const empty_order = currentOrder.lines.every((l) => l.global_service_fee_id);
        const order_total = this.get_order_total();
        let line2remove = currentOrder.lines.filter(
            (line) => line.global_service_fee_id && !general_fee_ids.includes(line.global_service_fee_id.id)
        );
        if (order_total === 0 || empty_order) {
            line2remove = currentOrder.lines.filter((line) => line.global_service_fee_id);
        }
        if (line2remove) {
            line2remove.forEach((line) => {
                line.delete();
            });
        }
    },

    async update_service_charges() {
        const currentOrder = this.get_order();
        if (currentOrder.lines) {
            await this.set_global_service_products();
            this.clean_remnant_service_charges();
            currentOrder.recomputeOrderData();
            currentOrder.lines = currentOrder.get_orderlines();
        }
    },

    async addLineToCurrentOrder(vals, opt = {}, configure = true) {
        const result = await super.addLineToCurrentOrder(vals, opt, configure);
        await this.update_service_charges();
        return result;
    },
});

patch(PosOrderline.prototype, {
    setup(vals) {
        return super.setup(...arguments);
    },

    getDisplayClasses() {
        // Italic for service charge lines
        return {
            ...super.getDisplayClasses(),
            "fst-italic": this.global_service_fee_id,
        };
    },

    set_full_product_name() {
        super.set_full_product_name();
        if (this.global_service_fee_id) {
            this.full_product_name = this.global_service_fee_id.name;
        }
    },

    get_service_fee_notes() {
        // For product-level fees on POS
        const service_fees = this.product_id.service_fee_ids.filter((fee) => fee.scope !== "ecommerce");
        let text = "";
        if (service_fees.length && this.get_unit_price() > 0 && this.get_quantity() > 0) {
            text = "\nIncludes ";
            const fee_text_lines = [];
            service_fees.forEach((fee) => {
                if (fee.type === "usd") {
                    const price = formatMonetary(fee.fixed_fee, { currencyId: this.currency });
                    fee_text_lines.push(
                        this.currency.symbol + formatText([price, fee.name.toLowerCase()].join(" "))
                    );
                } else if (fee.type === "percentage") {
                    fee_text_lines.push(formatText([fee.fee, fee.name.toLowerCase()].join(" ")));
                }
            });
            text += fee_text_lines.join(", ") + ".";
        }
        return text;
    },

    getDisplayData() {
        const result = super.getDisplayData();
        result.customerNote = result.customerNote + this.get_service_fee_notes();
        return result;
    },

    prepareBaseLineForTaxesComputationExtraValues(customValues = {}) {
        const extraValues = super.prepareBaseLineForTaxesComputationExtraValues(customValues);
        const service_fees = this.product_id.service_fee_ids.filter((fee) => fee.scope !== "ecommerce");
        if (service_fees.length && this.get_unit_price() > 0) {
            let total_fixed_fee = 0;
            const usd_fees = service_fees.filter((fee) => fee.type === "usd");
            const percent_fees = service_fees.filter((fee) => fee.type === "percentage");
            // Sum all fixed fees
            total_fixed_fee += usd_fees.reduce((sum, fee) => sum + fee.fixed_fee, 0);
            // Sum percentage fees
            percent_fees.forEach((fee) => {
                const price_fee = this.get_unit_price() * fee.percentage_fee;
                total_fixed_fee += price_fee;
            });
            extraValues.price_unit = this.get_unit_price() + total_fixed_fee;
        }
        return extraValues;
    },
});

patch(PosOrder.prototype, {
    get_orderlines() {
        // Put fee lines at the bottom
        const orderlines = super.get_orderlines(this, arguments);
        const FeeLines = [];
        const nonFeeLines = [];
        for (const line of orderlines) {
            if (line.global_service_fee_id) {
                FeeLines.push(line);
            } else {
                nonFeeLines.push(line);
            }
        }
        return [...nonFeeLines, ...FeeLines];
    },
});

patch(OrderSummary.prototype, {
    async updateSelectedOrderline({ buffer, key }) {
        const order = this.pos.get_order();
        const selectedLine = order.get_selected_orderline();
        if (selectedLine && selectedLine.global_service_fee_id) {
            this.numberBuffer.reset();
            return;
        }
        const result = await super.updateSelectedOrderline({ buffer, key });
        if (selectedLine && !selectedLine.global_service_fee_id) {
            await this.pos.set_global_service_products();
        }
        if (
            selectedLine &&
            (!selectedLine.get_unit_price() || !selectedLine.get_quantity()) ||
            key === "Backspace" ||
            key === "Delete"
        ) {
            const total = this.pos.get_order_total();
            if (total === 0) {
                this.pos.clean_remnant_service_charges();
            }
        }
        return result;
    },
    _setValue(val) {
        super._setValue(val);
        // Remove service charges if the order is empty
        if (val === "remove") {
            const currentOrder = this.pos.get_order();
            const empty_order = currentOrder.lines.every((l) => l.global_service_fee_id);
            if (empty_order) {
                let line2remove = currentOrder.lines.filter((line) => line.global_service_fee_id);
                line2remove.forEach((line) => line.delete());
            }
        }
    },
});
