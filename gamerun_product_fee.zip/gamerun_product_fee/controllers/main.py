# -*- coding: utf-8 -*-

from odoo.addons.website_sale.controllers.main import WebsiteSale
from odoo.http import request, route


class WebsiteSaleExtended(WebsiteSale):

    @route(['/shop/confirmation'], type='http', auth="public", website=True)
    def shop_payment_confirmation(self, **post):
        order = request.website.sale_get_order()
        if order:
            order = order.sudo()
            order.add_service_charges()  # ✅ Ensure service charges are applied before rendering
            order._recompute_prices()

        return super(WebsiteSaleExtended, self).shop_payment_confirmation(**post)
