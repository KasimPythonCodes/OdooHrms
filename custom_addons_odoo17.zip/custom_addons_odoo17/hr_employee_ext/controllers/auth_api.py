from odoo import http
from odoo.http import request,Response
from odoo.exceptions import AccessDenied
import json
from odoo.addons.portal.controllers.web import Home


class EmployeeAuthAPI(http.Controller):

    @http.route('/api/login', type='http', auth='public', methods=['POST'], csrf=False)
    def login(self, **params):
        print("jjjjjjjjjjjjjjjjjjj",params)
        email = params.get('email')
        password = params.get('password')
        print("jjjjjjjjjjjjjjjjjjj",email,password)

        # try:
        #     if not email or not password:
        #         return {"status": "error", "message": "Missing email or password"}
        # except Exception as e:
        #     print(e,"uuuuuuuuuuuuuuuuuuuuuuuuuuuuu")
        if not email or not password:
            return Response(
                json.dumps({"status": "error", "message": "Missing email or password"}),
                content_type='application/json;charset=utf-8'
            )

        user = request.env['res.users'].sudo().search([('login', '=', email)], limit=1)
        if not user:
            return  Response(json.dumps({"status": "error", "message": "User not found"},
                       content_type='application/json;charset=utf-8'
                       ),)
        request.session.authenticate(request.env.cr.dbname, email, password)
        return Response(
            json.dumps({
                "status": "success",
                "message": "Login successful",
                "session_id": request.session.sid,
                "user_id": user.id
            }),
            content_type='application/json;charset=utf-8'
        )

        #  Authenticate user if exists
        # try:
            # request.session.authenticate(request.env.cr.dbname, email, password)
        #     return {
        #         "status": "success",
        #         "message": "Login successful",
        #         "session_id": request.session.sid,
        #         "user_id": user.id
        #     }
        # except AccessDenied:
        #     return {"status": "error", "message": "Invalid password"}

    @http.route('/api/logout', auth='public', type='http', csrf=False, methods=['POST'])
    def logout(self, **params):
        request.session.logout()
        return Response(
            json.dumps({'status': 'success', 'message': 'Logged out'}),
            content_type='application/json;charset=utf-8',
        )




