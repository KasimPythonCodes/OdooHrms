from odoo import http
from odoo.http import request
from odoo.exceptions import ValidationError

class GradeMasterController(http.Controller):

    @http.route('/api/grades', type='json', auth='user', methods=['GET'], csrf=False)
    def get_grades(self):
        grades = request.env['grade.master'].sudo().search([])
        data = []
        for grade in grades:
            data.append({
                'id': grade.id,
                'grade_name': grade.grade_name,
                'grade_code': grade.grade_code,
                'grade_level': grade.grade_level,
                'grade_description': grade.grade_description,
                'job_family': grade.job_family_id.job_function if grade.job_family_id else None,
                'min_salary': grade.min_salary,
                'max_salary': grade.max_salary,
                'default_designation': grade.default_designation_id.name if grade.default_designation_id else None,
                'status': grade.status,
                'employee_count': grade.employee_count,
                'company': grade.company_id.name if grade.company_id else None,
            })
        return {'grades': data}

    @http.route('/api/grades', type='json', auth='user', methods=['POST'], csrf=False)
    def create_grade(self, **kwargs):
        try:
            # Validation: default_designation_id must be provided
            if not kwargs.get('default_designation_id'):
                return {'status': 'error', 'message': 'Default Designation is required.'}

            company_id = request.env.user.company_id.id
            grade_code = kwargs.get('grade_code')

            # Validation: enforce unique (grade_code + company)
            existing = request.env['grade.master'].sudo().search([
                ('grade_code', '=', grade_code),
                ('company_id', '=', company_id)
            ])
            if existing:
                return {'status': 'error', 'message': 'Grade code already exists for this company.'}

            values = {
                'grade_name': kwargs.get('grade_name'),
                'grade_code': grade_code,
                'grade_level': kwargs.get('grade_level'),
                'grade_description': kwargs.get('grade_description'),
                'job_family_id': kwargs.get('job_family_id'),
                'min_salary': kwargs.get('min_salary'),
                'max_salary': kwargs.get('max_salary'),
                'default_designation_id': kwargs.get('default_designation_id'),
                'status': kwargs.get('status', 'active'),
                'company_id': company_id,
            }

            new_grade = request.env['grade.master'].sudo().create(values)
            return {'status': 'success', 'id': new_grade.id}

        except Exception as e:
            return {'status': 'error', 'message': str(e)}


    @http.route('/api/grades/<int:grade_id>', type='json', auth='user', methods=['PATCH'], csrf=False)
    def update_grade(self, grade_id, **kwargs):
        grade = request.env['grade.master'].sudo().browse(grade_id)
        if not grade.exists():
            return {'status': 'error', 'message': 'Grade not found.'}

        try:
            # Validation: default_designation_id must be present if being updated
            if 'default_designation_id' in kwargs and not kwargs.get('default_designation_id'):
                return {'status': 'error', 'message': 'Default Designation is required.'}

            # If grade_code is being updated, check uniqueness per company
            new_grade_code = kwargs.get('grade_code')
            if new_grade_code and new_grade_code != grade.grade_code:
                existing = request.env['grade.master'].sudo().search([
                    ('grade_code', '=', new_grade_code),
                    ('company_id', '=', grade.company_id.id),
                    ('id', '!=', grade.id)
                ])
                if existing:
                    return {'status': 'error', 'message': 'Grade code already exists for this company.'}

            grade.sudo().write(kwargs)
            return {'status': 'success', 'message': 'Grade updated successfully.'}

        except Exception as e:
            return {'status': 'error', 'message': str(e)}


    @http.route('/api/grades/<int:grade_id>', type='json', auth='user', methods=['DELETE'], csrf=False)
    def delete_grade(self, grade_id):
        grade = request.env['grade.master'].sudo().browse(grade_id)
        if not grade.exists():
            return {'status': 'error', 'message': 'Grade not found.'}

        try:
            grade.sudo().unlink()
            return {'status': 'success', 'message': 'Grade deleted successfully.'}
        except Exception as e:
            return {'status': 'error', 'message': str(e)}
