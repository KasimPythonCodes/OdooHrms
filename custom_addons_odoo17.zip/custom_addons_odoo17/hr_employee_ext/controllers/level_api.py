from odoo import http
from odoo.http import request
from odoo.exceptions import ValidationError
import json


class LevelMasterController(http.Controller):

    @http.route('/api/levels', type='json', auth='user', methods=['GET'], csrf=False)
    def get_levels(self):
        levels = request.env['level.master'].sudo().search([])
        data = []
        for level in levels:
            total_employees = sum(level.grade_ids.mapped(
                lambda g: g.default_designation_id and g.default_designation_id.employee_ids and len(g.default_designation_id.employee_ids) or 0
            ))

            data.append({
                'id': level.id,
                'level_code': level.level_code,
                'level_name': level.level_name,
                'job_family': level.job_family_id.job_function if level.job_family_id else None,
                'description': level.description,
                'performance_band': level.performance_band,
                'is_active': level.is_active,
                'grade_ids': [g.id for g in level.grade_ids],
                'designation_ids': [d.id for d in level.designation_ids],
                'employee_count': total_employees,
            })
        return {'levels': data}

    @http.route('/api/levels', type='json', auth='user', methods=['POST'], csrf=False)
    def create_level(self, **kwargs):
        try:
            if not kwargs.get('level_code') or not kwargs.get('level_name'):
                return {'status': 'error', 'message': 'level_code and level_name are required'}

            company_id = request.env.user.company_id.id
            existing = request.env['level.master'].sudo().search([
                ('level_code', '=', kwargs.get('level_code'))
            ])
            if existing:
                return {'status': 'error', 'message': 'Level code already exists'}

            level = request.env['level.master'].sudo().create({
                'level_code': kwargs.get('level_code'),
                'level_name': kwargs.get('level_name'),
                'job_family_id': kwargs.get('job_family_id'),
                'description': kwargs.get('description'),
                'performance_band': kwargs.get('performance_band'),
                'is_active': kwargs.get('is_active', True),
                'grade_ids': [(6, 0, kwargs.get('grade_ids', []))],
                'designation_ids': [(6, 0, kwargs.get('designation_ids', []))],
            })

            return {'status': 'success', 'id': level.id}

        except Exception as e:
            return {'status': 'error', 'message': str(e)}

    @http.route('/api/levels/<int:level_id>', type='json', auth='user', methods=['PATCH'], csrf=False)
    def update_level(self, level_id, **kwargs):
        level = request.env['level.master'].sudo().browse(level_id)
        if not level.exists():
            return {'status': 'error', 'message': 'Level not found'}

        try:
            updates = {}
            if 'level_name' in kwargs:
                updates['level_name'] = kwargs['level_name']
            if 'job_family_id' in kwargs:
                updates['job_family_id'] = kwargs['job_family_id']
            if 'description' in kwargs:
                updates['description'] = kwargs['description']
            if 'performance_band' in kwargs:
                updates['performance_band'] = kwargs['performance_band']
            if 'is_active' in kwargs:
                updates['is_active'] = kwargs['is_active']
            if 'grade_ids' in kwargs:
                updates['grade_ids'] = [(6, 0, kwargs['grade_ids'])]
            if 'designation_ids' in kwargs:
                updates['designation_ids'] = [(6, 0, kwargs['designation_ids'])]

            level.write(updates)
            return {'status': 'success'}

        except Exception as e:
            return {'status': 'error', 'message': str(e)}

    @http.route('/api/levels/<int:level_id>', type='json', auth='user', methods=['DELETE'], csrf=False)
    def delete_level(self, level_id):
        level = request.env['level.master'].sudo().browse(level_id)
        if not level.exists():
            return {'status': 'error', 'message': 'Level not found'}

        try:
            level.unlink()
            return {'status': 'success', 'message': 'Deleted'}
        except Exception as e:
            return {'status': 'error', 'message': str(e)}
