from odoo import http
from odoo.http import request, Response
import json

class MyController(http.Controller):

    @http.route('/api/employees', auth='public', type='http', csrf=False, methods=['GET', 'POST'])
    def get_employees(self, **kw):
        employees = request.env['hr.employee'].sudo().search([])
        data = [{
            'id': emp.id,
            'name': emp.name,
            'work_email': emp.work_email,
        } for emp in employees]

        return Response(
            json.dumps({'status': 'success', 'employees': data}),
            content_type='application/json;charset=utf-8',
        )

    @http.route('/api/employee', auth='public', type='http', csrf=False, methods=['GET'])
    def get_employee_by_id(self, **kw):
        emp_id = kw.get('id')
        if not emp_id:
            return Response(
                json.dumps({'status': 'error', 'message': 'Missing employee ID'}),
                content_type='application/json;charset=utf-8',
                status=400
            )

        employee = request.env['hr.employee'].sudo().browse(int(emp_id))
        if not employee.exists():
            return Response(
                json.dumps({'status': 'error', 'message': 'Employee not found'}),
                content_type='application/json;charset=utf-8',
                status=404
            )

        data = {
            'id': employee.id,
            'name': employee.name,
            'work_email': employee.work_email,
            'work_phone': employee.work_phone,
            'mobile_phone': employee.mobile_phone,
        }

        return Response(
            json.dumps({'status': 'success', 'employee': data}),
            content_type='application/json;charset=utf-8'
        )

    @http.route('/api/employee/create', auth='public', type='http', csrf=False, methods=['POST'])
    def create_employee(self):
        try:
            data = json.loads(request.httprequest.data or '{}')
            if not data.get('name'):
                return Response(
                    json.dumps({'status': 'error', 'message': 'Name is required'}),
                    content_type='application/json;charset=utf-8',
                    status=400
                )
            employee = request.env['hr.employee'].sudo().create({
                'name': data['name'],
                'work_email': data.get('work_email'),
                'work_phone': data.get('work_phone'),
            })
            return Response(
                json.dumps({'status': 'success', 'employee_id': employee.id}),
                content_type='application/json;charset=utf-8'
            )
        except Exception as e:
            request.env.cr.rollback()
            return Response(
                json.dumps({'status': 'error', 'message': str(e)}),
                content_type='application/json;charset=utf-8',
                status=500
            )

    @http.route('/api/employee/edit', auth='public', type='http', csrf=False, methods=['POST'])
    def edit_employee(self, **kwargs):
        try:
            data = json.loads(request.httprequest.data or '{}')
        except Exception:
            data = kwargs

        emp_id = data.get('id')
        name = data.get('name')
        work_email = data.get('work_email')

        if not emp_id:
            return request.make_response(
                json.dumps({'error': 'Employee ID is required'}),
                headers=[('Content-Type', 'application/json')]
            )

        employee = request.env['hr.employee'].sudo().browse(int(emp_id))
        if not employee.exists():
            return request.make_response(
                json.dumps({'error': 'Employee not found'}),
                headers=[('Content-Type', 'application/json')]
            )


        vals = {}
        if name:
            vals['name'] = name
        if work_email:
            vals['work_email'] = work_email
        if vals:
            employee.write(vals)

        data = {
            'id': employee.id,
            'name': employee.name,
            'work_email': employee.work_email,
        }

        return request.make_response(
            json.dumps({'success': True, 'employee': data}),
            headers=[('Content-Type', 'application/json')]
        )

    @http.route('/api/employee/delete', auth='public', type='http', csrf=False, methods=['POST'])
    def delete_employee(self):
        try:
            data = json.loads(request.httprequest.data or '{}')
            emp_id = data.get('id')
            if not emp_id:
                return Response(
                    json.dumps({'status': 'error', 'message': 'Employee ID is required'}),
                    content_type='application/json;charset=utf-8',
                    status=400
                )

            employee = request.env['hr.employee'].sudo().browse(emp_id)
            if not employee.exists():
                return Response(
                    json.dumps({'status': 'error', 'message': 'Employee not found'}),
                    content_type='application/json;charset=utf-8',
                    status=404
                )

            # ✅ Check if employee is referenced in hr_salary_calculation_custom
            linked_records = request.env['hr.salary.calculation.custom'].sudo().search([('employee_id', '=', emp_id)])
            if linked_records:
                return Response(
                    json.dumps({
                        'status': 'error',
                        'message': f'Cannot delete Employee ID {emp_id} because it is linked to salary calculation records.'
                    }),
                    content_type='application/json;charset=utf-8',
                    status=409  # Conflict
                )

            # Safe to delete
            employee.unlink()
            return Response(
                json.dumps({'status': 'success', 'message': f'Employee ID {emp_id} deleted successfully'}),
                content_type='application/json;charset=utf-8',
                status=200
            )

        except Exception as e:
            request.env.cr.rollback()
            return Response(
                json.dumps({'status': 'error', 'message': str(e)}),
                content_type='application/json;charset=utf-8',
                status=500
            )