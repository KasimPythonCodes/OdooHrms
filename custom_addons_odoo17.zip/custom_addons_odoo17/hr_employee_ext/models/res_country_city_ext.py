from odoo import models, fields, api


class ResCountryCity(models.Model):
    _name = 'res.country.city'
    _description = 'City'


    name = fields.Char(string='City')
    state_id = fields.Many2one('res.country.state',string='State', required=True)
    country_id = fields.Many2one('res.country', string='Country', default='India', required=True)

    @api.model_create_multi
    def create(self, vals):
        res = super(ResCountryCity, self).create(vals)
        return res

    def write(self, vals):
        result = super(ResCountryCity, self).write(vals)
        return result


class ResCompany(models.Model):
    _inherit = 'res.company'

    city_id = fields.Many2one('res.country.city', string="City",domain="[('state_id', '=', state_id)]")
    sgst = fields.Char(String="SGST")
    cgst = fields.Char(String="CGST")

    @api.onchange('city_id')
    def set_city(self):
        self.city = self.city_id.name
