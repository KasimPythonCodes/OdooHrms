from odoo import models, fields, api
from datetime import datetime


class GradeMaster(models.Model):
    _name = 'grade.master'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Grade Master'
    _rec_name = 'grade_name'
    _order = 'grade_level'
    _sql_constraints = [
        ('unique_grade_code_per_family_company', 'unique(grade_code, job_function, company_id)', 'Grade Code must be unique per company.')
    ]

    company_id = fields.Many2one('res.company', string="Company", required=True, default=lambda self: self.env.company)
    grade_name = fields.Char("Grade Name", required=True) # e.g., G1, G2, L5
    grade_code = fields.Char("Grade Code")
    grade_level = fields.One2many("level.master", "grade_id", string="Grade Levels")
    grade_description = fields.Char("Grade Description", required=True) # e.g., Entry, Senior, Lead
    # pay_band_id = fields.Many2one('hr.payroll.structure', string="Payroll Structure", tracking=True)
    min_salary = fields.Float("Salary Range (min)")
    max_salary = fields.Float("Salary Range (max)")
    job_function = fields.Many2one('hr.job', string="Designation")
    # promotion_criteria = fields.Text("Promotion Criteria")
    status = fields.Selection(
        selection=[
            ('draft', 'Draft'),
            ('active', 'Active'),
            ('archived', 'Archived')
        ],
        string="Status",
        default='active',
        required=True
    )
    employee_count = fields.Integer(
        string="Employee Count",
        store=True
    )

    @api.model
    def create(self, vals):
        # 1. Generate grade_code if not set
        if not vals.get('grade_code') and vals.get('grade_name'):
            prefix = vals['grade_name'][:3].upper()
            existing_codes = self.search([('grade_code', '=like', f'{prefix}%')], order='grade_code desc', limit=1)
            next_number = 1
            if existing_codes:
                last_code = existing_codes.grade_code[-3:]
                if last_code.isdigit():
                    next_number = int(last_code) + 1
            vals['grade_code'] = f"{prefix}{str(next_number).zfill(3)}"

        # 2. Create the Grade record
        grade = super(GradeMaster, self).create(vals)

        # 3. Propagate company_id and job_function to linked level.master
        if grade:
            level_model = self.env['level.master'].sudo()
            levels = level_model.search([('grade_id', '=', grade.id)])
            for level in levels:
                level.write({
                    'company_id': grade.company_id.id,
                    'job_function': [(6, 0, [grade.job_function.id])] if grade.job_function else False
                })

        return grade

class Job(models.Model):
    _inherit = 'hr.job'

    grade_id = fields.Many2one('grade.master', string="Job Grade")

class HrEmployee(models.Model):
    _inherit = 'hr.employee'

    grade_id = fields.Many2one('grade.master', string="Grade")
    level_id = fields.Many2one('level.master', string="Level")

    @api.onchange('level_id')
    def _onchange_level_id(self):
        if self.level_id:
            self.grade_id = self.level_id.grade_id

    @api.onchange('grade_id','level_id')
    def _onchange_grade_employee_count(self):
        # for grade in self:
        employees = self.env['hr.employee'].search([
            ('grade_id', '=', self.grade_id.id)
        ])
        self.grade_id.employee_count = len(employees)