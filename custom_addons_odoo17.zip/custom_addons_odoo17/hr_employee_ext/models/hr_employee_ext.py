from odoo import models, fields, api

class HrEmployee(models.Model):
    _inherit = 'hr.employee'

    city_id = fields.Many2one('res.country.city',string='City',domain="[('state_id', '=', private_state_id)]")

    @api.onchange('city_id')
    def set_city(self):
        self.private_city = self.city_id.name