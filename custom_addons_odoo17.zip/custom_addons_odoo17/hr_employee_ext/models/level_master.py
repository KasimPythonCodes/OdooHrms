from odoo import api, models, fields
from odoo.exceptions import ValidationError

class LevelMaster(models.Model):
    _name = 'level.master'
    _description = 'Level Master'
    _rec_name = 'level_name'
    _order = 'level_code'
    _sql_constraints = [
        ('unique_level_code_per_function_company',
         'unique(level_code, job_function, company_id)',
         'Each Level Code must be unique within the same Job function and Company.')
    ]

    company_id = fields.Many2one('res.company', string='Company', required=True, default=lambda self: self.env.company)
    level_code = fields.Text("Level Code", required=True)  # L1, L2, etc.
    level_name = fields.Text("Level Name", required=True)  # Entry, Mid, etc.
    description = fields.Text("Level Description")
    min_salary = fields.Float("Salary Range (min)")
    max_salary = fields.Float("Salary Range (max)")
    grade_id = fields.Many2one('grade.master', string="Grade", required=True)
    job_function = fields.Many2one('hr.job', string="Department")
    status = fields.Selection(
        selection=[
            ('draft', 'Draft'),
            ('active', 'Active'),
            ('archived', 'Archived')
        ],
        string="Status",
        default='active',
        required=True
    )


    @api.constrains('min_salary', 'max_salary', 'grade_id')
    def _check_salary_range(self):
        for rec in self:
            if rec.min_salary >= rec.max_salary:
                raise ValidationError("Min salary must be less than max salary.")

            if rec.min_salary < rec.grade_id.min_salary or rec.max_salary > rec.grade_id.max_salary:
                raise ValidationError("Level salary must be within the Grade's compensation band.")

