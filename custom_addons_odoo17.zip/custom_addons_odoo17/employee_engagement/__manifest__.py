{
    'name': 'Employee Engagement - Surveys & Polls',
    'version': '1.0',
    'summary': 'Employee engagement surveys and polls for HR',
    'depends': ['hr', 'mail'],  # using hr for employees, mail for notifications
    'data': [
        'security/ir.model.access.csv',
        'views/survey_views.xml',
        'views/nomination_views.xml',
        'views/communication_views.xml',
    ],
    'installable': True,
    'application': True,
}
