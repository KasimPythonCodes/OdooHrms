from odoo import models, fields

class EmployeeSurveyResponse(models.Model):
    _name = "employee.survey.response"
    _description = "Survey Response"

    survey_id = fields.Many2one(
        "employee.survey",
        string="Survey",
        required=True,
        ondelete="cascade"
    )
    employee_id = fields.Many2one("hr.employee", string="Employee")
    submitted = fields.Boolean(default=False)

    response_line_ids = fields.One2many(
        "employee.survey.response.line",
        "response_id",
        string="Answers"
    )

    response_text = fields.Text(string='Response Text')
    company_id = fields.Many2one(
        'res.company',
        string="Company",
        default=lambda self: self.env.company.id,
        required=True
    )


class EmployeeSurveyResponseLine(models.Model):
    _name = "employee.survey.response.line"
    _description = "Survey Response Line"

    response_id = fields.Many2one(
        "employee.survey.response", string="Response", required=True, ondelete="cascade"
    )
    question_ids = fields.One2many("employee.survey.question", "survey_id")
    option_id = fields.Many2one(
        "employee.survey.option", string="Option"
    )
    rating_value = fields.Integer()
    answer_text = fields.Text()
