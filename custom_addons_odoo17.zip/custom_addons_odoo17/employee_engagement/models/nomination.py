from odoo import models, fields, api
from odoo.exceptions import ValidationError


class NominationCategory(models.Model):
    _name = "employee.nomination.category"
    _description = "Nomination Category"

    name = fields.Char("Category Name", required=True)
    description = fields.Text("Description")


class EmployeeNomination(models.Model):
    _name = "employee.nomination"
    _description = "Employee Nomination"
    _inherit = ["mail.thread", "mail.activity.mixin"]

    name = fields.Char("Nomination Title", required=True, tracking=True)
    nominee_id = fields.Many2one("hr.employee", string="Nominee", required=True, tracking=True)
    nominator_id = fields.Many2one("hr.employee", string="Nominated By", required=True, tracking=True)
    category_id = fields.Many2one("employee.nomination.category", string="Category", required=True)
    reason = fields.Text("Reason for Nomination", tracking=True)
    deadline = fields.Date("Deadline")
    company_id = fields.Many2one("res.company", string="Company", default=lambda self: self.env.company.id)

    state = fields.Selection([
        ("draft", "Draft"),
        ("submitted", "Submitted"),
        ("approved", "Approved"),
        ("rejected", "Rejected"),
    ], default="draft", string="Status", tracking=True)

    @api.constrains("deadline")
    def _check_deadline(self):
        for rec in self:
            if rec.deadline and rec.deadline < fields.Date.today():
                raise ValidationError("Deadline cannot be in the past.")

    def action_submit(self):
        for rec in self:
            rec.state = "submitted"

    def action_approve(self):
        for rec in self:
            rec.state = "approved"

    def action_reject(self):
        for rec in self:
            rec.state = "rejected"
