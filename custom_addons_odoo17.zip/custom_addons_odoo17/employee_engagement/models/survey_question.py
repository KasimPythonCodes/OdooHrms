from odoo import models, fields

class EmployeeSurveyQuestion(models.Model):
    _name = "employee.survey.question"
    _description = "Survey Question"

    survey_id = fields.Many2one(
        "employee.survey",
        string="Survey",
        required=True,
        ondelete="cascade"
    )
    question_text = fields.Char(required=True)
    question_type = fields.Selection([
        ('text', 'Text Input'),
        ('mcq', 'Multiple Choice'),
        ('rating', 'Rating Scale')
    ], default="text")
    answers = fields.Char("Answers")
    company_id = fields.Many2one(
        'res.company',
        string="Company",
        default=lambda self: self.env.company.id,
        required=True
    )

    option_ids = fields.One2many(
        "employee.survey.option",
        "question_id",
        string="Options"
    )
