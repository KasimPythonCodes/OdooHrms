from odoo import models, fields

class EmployeeSurveyOption(models.Model):
    _name = "employee.survey.option"
    _description = "Survey Option"

    question_id = fields.Many2one(
        "employee.survey.question", string="Question", required=True, ondelete="cascade"
    )
    option_text = fields.Char(required=True)
    company_id = fields.Many2one(
        'res.company',
        string="Company",
        default=lambda self: self.env.company.id,
        required=True
    )
