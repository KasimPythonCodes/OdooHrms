from odoo import models, fields, api
from odoo.exceptions import UserError


class EmployeeSurvey(models.Model):
    _name = "employee.survey"
    _description = "Employee Survey"

    name = fields.Char(string="Survey Title", required=True)
    description = fields.Text(string="Description")
    target_audience = fields.Char(string="Target Audience")
    target_persons = fields.Many2many("hr.employee", string="Target Persons")
    deadline = fields.Date(string="Deadline")
    state = fields.Selection([
        ('draft', 'Draft'),
        ('published', 'Published'),
        ('closed', 'Closed')
    ], default='draft')
    company_id = fields.Many2one(
        'res.company',
        string="Company",
        default=lambda self: self.env.company.id,
        required=True
    )

    question_ids = fields.One2many(
        "employee.survey.question",
        "survey_id",
        string="Questions"
    )

    response_ids = fields.One2many(
        "employee.survey.response",
        "survey_id",
        string="Responses"
    )

    total_responses = fields.Integer(
        compute="_compute_total_responses",
        store=True
    )

    survey_type = fields.Char(string="Survey type")

    @api.depends("response_ids")
    def _compute_total_responses(self):
        for survey in self:
            survey.total_responses = len(survey.response_ids)

    def action_publish(self):
        self.write({"state": "published"})

    def action_close(self):
        self.write({"state": "closed"})

    def action_send_survey_reminder(self):
        """Send survey invitation mail to selected employees"""
        for rec in self:
            if not rec.target_persons:
                raise UserError("Please select at least one employee to send the survey.")

            if not rec.deadline_date:
                raise UserError("Please set a deadline before sending the survey.")

            # Get all email addresses
            emails = rec.target_persons.mapped("work_email")
            emails = [e for e in emails if e]  # Remove empty ones

            if not emails:
                raise UserError("Selected employees don't have work emails configured.")

            # Mail subject & body
            subject = f"Survey Invitation: {rec.name}"
            body = f"""
                <p>Dear Employee,</p>
                <p>You are invited to participate in the survey: <b>{rec.name}</b>.</p>
                <p><b>Deadline:</b> {rec.deadline_date}</p>
                <p>Please make sure to complete the survey before the deadline.</p>
                <p>Thank you.</p>
            """

            # Send mail to each employee
            for employee in rec.target_persons:
                if employee.work_email:
                    rec.env['mail.mail'].create({
                        'subject': subject,
                        'body_html': body,
                        'email_to': employee.work_email,
                        'author_id': rec.env.user.partner_id.id,
                    }).send()



