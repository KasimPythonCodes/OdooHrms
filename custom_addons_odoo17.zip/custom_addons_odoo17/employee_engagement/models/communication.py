from odoo import models, fields, api


class CompanyAnnouncement(models.Model):
    _name = "company.announcement"
    _description = "Company Announcements"
    _order = "date_posted desc"

    title = fields.Char("Title", required=True)
    content = fields.Html(
        "Content",
        required=True,
        help="Supports text, images, videos, and links",
    )
    date_posted = fields.Datetime("Posted On", default=fields.Datetime.now)
    posted_by = fields.Many2one(
        "res.users", string="Posted By", default=lambda self: self.env.user
    )

    like_count = fields.Integer("Likes", compute="_compute_likes_comments", store=True)
    comment_count = fields.Integer(
        "Comments", compute="_compute_likes_comments", store=True
    )

    engagement_ids = fields.One2many(
        "announcement.engagement", "announcement_id", string="Engagements"
    )
    company_id = fields.Many2one("res.company", string="Company", default=lambda self: self.env.company.id)


    @api.depends("engagement_ids.engagement_type")
    def _compute_likes_comments(self):
        for rec in self:
            rec.like_count = len(
                rec.engagement_ids.filtered(lambda e: e.engagement_type == "like")
            )
            rec.comment_count = len(
                rec.engagement_ids.filtered(lambda e: e.engagement_type == "comment")
            )



class AnnouncementEngagement(models.Model):
    _name = "announcement.engagement"
    _description = "Announcement Engagements"

    announcement_id = fields.Many2one(
        "company.announcement", required=True, ondelete="cascade"
    )
    user_id = fields.Many2one(
        "res.users", string="User", default=lambda self: self.env.user
    )
    engagement_type = fields.Selection(
        [("like", "Like"), ("comment", "Comment")], required=True
    )
    comment_text = fields.Text("Comment")
    company_id = fields.Many2one("res.company", string="Company", default=lambda self: self.env.company.id)



class CollaborationForum(models.Model):
    _name = "collaboration.forum"
    _description = "Internal Collaboration Forum"

    name = fields.Char("Topic", required=True)
    description = fields.Text("Description")
    created_by = fields.Many2one(
        "res.users", string="Created By", default=lambda self: self.env.user
    )
    post_ids = fields.One2many("forum.post", "forum_id", string="Posts")
    company_id = fields.Many2one("res.company", string="Company", default=lambda self: self.env.company.id)



class ForumPost(models.Model):
    _name = "forum.post"
    _description = "Forum Posts"

    forum_id = fields.Many2one(
        "collaboration.forum", required=True, ondelete="cascade"
    )
    author_id = fields.Many2one(
        "res.users", string="Author", default=lambda self: self.env.user
    )
    content = fields.Html("Post Content", required=True)
    date_posted = fields.Datetime("Posted On", default=fields.Datetime.now)
    tagged_users = fields.Many2many("res.users", string="Tagged Users")
    company_id = fields.Many2one("res.company", string="Company", default=lambda self: self.env.company.id)



class EmployeeCommunication(models.Model):
    _name = "employee.communication"
    _description = "Employee Communication"

    name = fields.Char(string="Subject", required=True)
    message = fields.Text(string="Message", required=True)
    date = fields.Date(string="Date", default=fields.Date.today)
    company_id = fields.Many2one("res.company", string="Company")