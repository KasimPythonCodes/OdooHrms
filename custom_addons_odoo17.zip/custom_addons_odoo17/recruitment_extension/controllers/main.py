import logging
import os.path
import pprint
import traceback
from typing import Any
from collections import defaultdict
import werkzeug
import datetime
from datetime import timedelta

from docutils.nodes import attention

from odoo import http, _, fields
from odoo.addons.test_inherit.models import res_partner
from odoo.http import request
from odoo.exceptions import ValidationError
from odoo.osv import expression
from odoo.tools.config import config
import base64
import functools
import json
import random
import uuid
import re
import time
from itertools import chain
import timeit
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT as DF, append_content_to_html
from werkzeug.exceptions import BadRequest
from odoo import api, http, SUPERUSER_ID, _
from odoo import registry as registry_get
from passlib.context import CryptContext
import jwt

global config
set_config = config.get('config')
import pytz
from odoo.tools import html2plaintext

def many2one_to_object(value):
    if isinstance(value, (list, tuple)) and len(value) == 2:
        return {'id': value[0], 'name': value[1]}
    return None

class UserAuth(http.Controller):

    @http.route('/login', type='json', auth='none', csrf=False, cors="*", website=True)
    def login(self, **kwargs):
        resp={}
        try:
            data = json.loads(request.httprequest.data.decode()) if request.httprequest.data else {}
            if data:
                email = data.get("email") or kwargs.get("email")
                password = data.get("password") or kwargs.get("password")
                dbname = request.env.cr.dbname
                # login_creds ={'login':email,'password':password,'type':'password'}

                if not email or not password:
                    resp["status"]=400
                    resp["message"]="Email and password are required!"
                    return resp
                # uid = request.session.authenticate(dbname, login_creds)
                uid = request.session.authenticate(dbname, email,password)
                user = request.env['res.users'].sudo().search([('id','=',uid)],limit=1)
                if uid and user:
                    expiry_minutes = 24*60
                    expiry_seconds = expiry_minutes * 60
                    # expiry_seconds = 10
                    expiry_time = datetime.datetime.utcnow() + timedelta(seconds=expiry_seconds)
                    request.session.timeout = expiry_seconds
                    request.session['expire_at'] = expiry_time.isoformat() + 'Z'

                    data={
                        "emp_id": uid or user.id,
                        "name": user.name,
                        "email": user.email,
                        "token": request.session.sid,
                        "token_expire_at": expiry_time.isoformat() + 'Z',
                        "expires_in_seconds": expiry_minutes
                    }
                    resp["status"] = 200
                    resp["message"] = "Login successfull"
                    resp['data']=data

                    return resp
                else:
                    invalid= {"status": 401, "message": "Invalid credentials"}
                    resp['message']=invalid
                    return resp
        except Exception as e:
            r1={"status": 500, "errorMessage": "Email or Password Do Not Match", "error": str(e)}
            resp['message']=r1
        return resp

    @http.route('/forget', type='json', auth='none', csrf=False, cors="*", website=True)
    def forget(self,**kwargs):
        resp={}
        try:
            data = json.loads(request.httprequest.data.decode()) if request.httprequest.data else {}
            if data:
                otp = random.randint(100000,999999)
                email = data.get("email")
                if not email:
                    resp["status"] = 400
                    resp["message"] = "Email is required!"
                    return resp

                user = request.env['res.users'].sudo().search([('login', '=', email)], limit=1)
                if not user:
                    resp["status"] = 404
                    resp["message"] = f"No user found with email!: {email}"
                    return resp
                expiry = datetime.datetime.now() + datetime.timedelta(minutes=5)

                request.env['res.user.otp'].sudo().search([('user_id', '=', user.id)]).create({
                        'user_id':user.id,
                        'otp':otp,
                        'otp_expiry':expiry
                    })
                # token = str(uuid.uuid4())
                # created_at = datetime.datetime.utcnow().isoformat()
                # config = request.env['ir.config_parameter'].sudo()
                # config.set_param(f'password_reset_token_{user.id}', token)
                # config.set_param(f'password_reset_token_time_{user.id}', created_at)
                base_url = request.env['ir.config_parameter'].sudo().get_param('forentend.web.base.url')
                reset_url = f"{base_url}/reset_password?token={request.session.sid}&email={email}"
                subject = "Password Reset Request"
                # body_html = f"""
                #         <p>Hello {user.name},</p>
                #         <p>Your OTP Is {otp},</p>
                #         <p>We received a request to reset your password.</p>
                #         <p>Click <a href="{reset_url}">here</a> to reset it. This link is valid for 15 minutes.</p>
                #         <p>If you didn’t request this, please ignore this email.</p>
                #         """
                body_html = f"""
                            <p>Hello {user.name},</p>
                            <p>Your OTP Is {otp},</p>
                            <p>We received a request to reset your password.</p>
                            <p>If you didn’t request this, please ignore this email.</p>
                            """
                mail_values = {
                    'subject': subject,
                    'body_html': body_html,
                    'email_to': email,
                    'email_from': request.env['ir.mail_server'].sudo().search([],limit=1).smtp_user,
                }
                request.env['mail.mail'].sudo().create(mail_values).send()

                resp["status"] = 200
                resp["message"] = "Password Reset Request link sent successfully your email!"
                resp['data']={
                    "user_id":user.id,
                    "reset_url":reset_url,
                    "token":request.session.sid,
                    "otp": otp,
                    "expires_in_minutes": 5
                }
        except Exception as e:
            resp['status']=500
            resp['message']=str(e)
            print(str(e))
        return resp

    @http.route('/reset_password', type='json', auth='none', csrf=False, cors="*", website=True)
    def reset_password(self, **kwargs):
        resp={}
        try:
            data = json.loads(request.httprequest.data.decode()) if request.httprequest.data else {}
            if data:
                # email = data.get("email")
                user_id = data.get("user_id")
                # token = data.get("token")
                new_password = data.get("new_password")
                confirm_password = data.get("confirm_password")
                # if not (email and token and new_password and confirm_password):
                if not (new_password and confirm_password):
                    resp['status']=400
                    resp['message']="These fields are required!"
                    return resp
                if new_password != confirm_password:
                    resp['status'] = 400
                    resp['message'] = "Passwords do not match!"
                    return resp
                user = request.env['res.users'].sudo().search([('id', '=', user_id)], limit=1)
                if not user:
                    resp["status"]= 404
                    resp["message"]="Invalid User!"
                    return resp

                # config = request.env['ir.config_parameter'].sudo()
                # stored_token = config.get_param(f'password_reset_token_{user.id}')
                # stored_time = config.get_param(f'password_reset_token_time_{user.id}')
                # if not stored_token or stored_token != token:
                #     resp["status"]=401
                #     resp["message"]="Invalid or used token!"
                #     return resp
                # token_time = datetime.datetime.fromisoformat(stored_time)
                # if datetime.datetime.utcnow() - token_time > timedelta(minutes=15):
                #     resp["status"]= 410
                #     resp["message"]= "Link expired!"
                #     return resp
                # If valid → reset password ###############Write valid user password in db ########################
                try:

                    crypt_context = CryptContext(['pbkdf2_sha512', 'plaintext'])
                    hashed_password = crypt_context.hash(new_password)
                    request.env.cr.execute(
                        "UPDATE res_users SET password = %s WHERE id = %s",
                        (hashed_password, user.id)
                    )
                    request.env.cr.commit()
                    # config.set_param(f'password_reset_token_{user.id}', False)
                    # config.set_param(f'password_reset_token_time_{user.id}', False)
                    resp["status"] = 200
                    resp["message"] = "Password reset successful!"
                    resp['data']={
                        'user_id':user.id,
                    }
                except Exception as e:
                    # Rollback if password write failed ######## Importent point
                    request.env.cr.rollback()
                    resp["status"] = 500
                    resp["message"] = f"Error updating password: {str(e)}"
        except Exception as e:
            resp['status']=500
            resp['message']=str(e)
        return resp

    @http.route('/forget/otp-verification', type='json', auth='none', csrf=False, cors="*", website=True)
    def forget_otp_verification(self, **kwargs):
        resp = {}
        try:
            data = json.loads(request.httprequest.data.decode()) if request.httprequest.data else {}
            if data:
                otp = data.get('otp') or  kwargs.get("otp")
                if not otp:
                    resp["status"] = 400
                    resp["message"] = "OTP are required!"
                    return resp
                user_otp = request.env["res.user.otp"].sudo().search([("otp", "=", otp)], limit=1)
                if user_otp.otp != otp:
                    resp["status"] = 400
                    resp["message"] = "Invalid OTP!"
                    return resp
                if user_otp.otp_expiry < datetime.datetime.now():
                    resp["status"] = 400
                    resp["message"] = "OTP expired!"
                    return resp
                # OTP is valid — clear it
                user_otp.sudo().write({"otp": False, "otp_expiry": False})
                resp["status"] = 200
                resp["message"] = "OTP verified successfully!"
                resp["data"]={
                  'user_id':user_otp.user_id.id,
                }
        except Exception as e:
            resp["status"] = 500
            resp["message"] = str(e)
            print("Employee API error:", str(e))
        return resp

class RecruitmentAPI(http.Controller):

    @http.route('/hr-job-application', type='json', auth='public', csrf=False, cors="*", website=True)
    def get_hr_job(self,**kwargs):
        resp={}
        hr_job_list_data=[]
        try:
            job_ids = request.env['hr.job'].sudo().search([])
            for val in job_ids:
                plain_text = html2plaintext(val.description)

                hr_job_list_data.append({
                    "id":val.id,
                    "name":val.name,
                    "isPublished":val.website_published,
                    "description":plain_text,
                    "department_id":val.department_id.id,
                    "address_id":val.address_id.id,
                    "contract_type_id":val.contract_type_id.id,
                    "expected_employees": val.expected_employees,
                    "no_of_recruitment":val.no_of_recruitment,
                    "user_id":val.user_id.id,
                    "interviewer_ids":[{"id":val1.id,"name":val1.name} for val1 in val.interviewer_ids],
                })
            resp['status'] = 200
            resp['message'] = "success"
            resp['number_of_records'] = len(job_ids),
            resp['data'] = hr_job_list_data
            print(hr_job_list_data,"++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
        except Exception as e:
            print(str(e))
            resp['status']=500
            resp['message']="Error During Fetch All Records"
            resp['error']=str(e)
        return resp

    @http.route('/create-hr-job', type='json', auth='public', csrf=False, cors="*", website=True)
    def create_hr_job(self,**kwargs):
        resp={}
        try:
            data = json.loads(request.httprequest.data.decode()) if request.httprequest.data else {}
            if data:
                job = request.env['hr.job'].sudo()
                creatable_fields = {}
                if data.get("name"):
                    creatable_fields["name"] = data["name"]
                if data.get("department_id"):
                    creatable_fields["department_id"] = data["department_id"]
                if data.get("description"):
                    # If you want to store HTML → plain text, use this:
                    # updatable_fields["description"] = html2plaintext(data["description"]).strip()
                    # If you want to store raw HTML:
                    creatable_fields["description"] = data["description"]
                if data.get("no_of_recruitment"):
                    creatable_fields["no_of_recruitment"] = data["no_of_recruitment"]
                if data.get("expected_employees"):
                    creatable_fields["expected_employees"] = data["expected_employees"]
                if data.get("no_of_hired_employee"):
                    creatable_fields["no_of_hired_employee"] = data["no_of_hired_employee"]
                if data.get('address_id'):
                    creatable_fields['address_id'] = data['address_id']
                if data.get('user_id'):
                    creatable_fields['user_id'] = data['user_id']
                if data.get('company_id'):
                    creatable_fields['company_id'] = data['company_id']
                if data.get('interviewer_ids'):
                    creatable_fields['interviewer_ids'] = data['interviewer_ids']
                if data.get('contract_type_id'):
                    creatable_fields['contract_type_id'] = data['contract_type_id']
                if data.get('isPublished') or not data.get('isPublished'):
                    creatable_fields['website_published']=data['isPublished']
                if data.get('alias_domain') or data.get('alias_email'):
                    alias_id = request.env['mail.alias.domain'].sudo().search([('name','=',data.get('alias_domain'))],limit=1)
                    creatable_fields['alias_name']=data['alias_email']
                    creatable_fields['alias_domain_id']=alias_id.id
                    request.env.company.sudo().write({
                        'alias_domain_id': alias_id.id
                    })

                # Create the record
                if creatable_fields:
                    job.create(creatable_fields)
                else:
                    resp["status"] = 400
                    resp["message"] = "No valid fields provided for Create"
                    return resp
                resp["status"] = 201
                resp["message"] = "Job Create successfully"
                resp["data"] = creatable_fields
                return resp
            else:
                resp["status"] = 404
                resp["message"] = "No valid fields provided for Create"
                return resp
        except Exception as e:
            print(str(e))
            resp['status']=500
            resp['message']="Error During Job Creation"
            resp['error']=str(e)
        return resp

    @http.route('/hr-job-fetch/<int:job_id>', type='json', auth='public', csrf=False, cors="*", website=True)
    def fetch_one_record_hr_job(self, job_id, **kwargs):
        resp = {}
        try:
            job = request.env['hr.job'].sudo().browse(job_id)
            if not job.exists():
                resp['status'] = 404
                resp['message'] = f"Job with ID {job_id} not found"
                return resp
            plain_text = html2plaintext(job.description)
            data = {
                "id": job.id,
                "name": job.name,
                "alias_email": job.alias_email,
                "alias_name": job.alias_name,
                # "selected_department_id": job.department_id.id,
                "department_id": job.department_id.id,
                # "department_ids": [{"id":dp.id,"name":dp.name} for dp in request.env['hr.department'].sudo().search([])],
                "description": plain_text or "",
                "expected_employees": job.expected_employees,
                "no_of_hired_employee": job.no_of_hired_employee,
                "no_of_recruitment": job.no_of_recruitment,
                # {x: x ** 2 for x in [1, 2, 3, 4, 5]}
                # "selected_alias_domain_id":[{"id":job.alias_domain_id.id}],
                "alias_domain":job.alias_domain_id.id,
                # "alias_domain_ids":[{"id":alias.id ,"name":alias.name} for alias in request.env['mail.alias.domain'].sudo().search([])],
                # "selected_contract_type_id":[{"id":job.contract_type_id.id}],
                "contract_type_id":job.contract_type_id.id,
                # "contract_type_id": [{"id":contype.id, "name":contype.name } for contype in request.env['hr.contract.type'].sudo().search([])],
                # "address_ids": [{"id":request.env.user.company_id.id,"name":request.env.user.company_id.name}],
                "address_id": request.env.user.company_id.id,
                "company_id": request.env.user.company_id.id,
                # "company_ids": [{"id":company_id.id,"name":company_id.name} for company_id in request.env['res.company'].sudo().search([])],
                # "selected_recruiter_id": [{"id": job.user_id.id}],
                "user_id": job.user_id.id,
                # "recruiter_ids": [{"id": user.id, "name": user.name} for user in request.env['res.users'].sudo().search(
                #     [('groups_id', 'in', request.env.ref('base.group_user').id)])],
                # "selected_interviewer_ids":[{"id":job.interviewer_ids.ids}],
                "interviewer_ids":job.interviewer_ids.ids,
            #     "interviewer_ids":[{"id":user.id,"name":user.name} for user in request.env['res.users'].sudo().search([('groups_id', 'in', request.env.ref('base.group_user').id)])],
                "isPublished":job.website_published,
            }
            resp['status'] = 200
            resp['message'] = "Job fetched successfully"
            resp['data'] = data
            return resp
        except Exception as e:
            resp['status'] = 500
            resp['message'] = "Error while fetching job"
            resp['error'] = str(e)
            return resp

    @http.route('/hr-job-update/<int:job_id>', type='json', auth='public', csrf=False, cors="*", website=True)
    def update_job(self, job_id, **kwargs):
        resp = {}
        try:
            data = json.loads(request.httprequest.data.decode()) if request.httprequest.data else {}
            job = request.env['hr.job'].sudo().browse(job_id)
            if not job.exists():
                resp["status"] = 404
                resp["message"] = f"Job with ID {job_id} not found"
                return resp
            updatable_fields = {}
            if data.get("name"):
                updatable_fields["name"] = data["name"]
            if data.get("department_id"):
                updatable_fields["department_id"] = data["department_id"]
            if data.get("description"):
                # If you want to store HTML → plain text, use this:
                # updatable_fields["description"] = html2plaintext(data["description"]).strip()
                # If you want to store raw HTML:
                updatable_fields["description"] = data["description"]
            if data.get("no_of_recruitment"):
                updatable_fields["no_of_recruitment"] = data["no_of_recruitment"]
            if data.get("expected_employees"):
                updatable_fields["expected_employees"] = data["expected_employees"]
            if data.get("no_of_hired_employee"):
                updatable_fields["no_of_hired_employee"] = data["no_of_hired_employee"]
            if data.get('address_id'):
                updatable_fields['address_id']=data['address_id']
            if data.get('user_id'):
                updatable_fields['user_id']=data['user_id']
            if data.get('company_id'):
                updatable_fields['company_id']=data['company_id']
            if data.get('interviewer_ids'):
                updatable_fields['interviewer_ids']=data['interviewer_ids']
            if data.get('contract_type_id'):
                updatable_fields['contract_type_id']=data['contract_type_id']
            if data.get('isPublished') or not data.get('isPublished'):
                updatable_fields['website_published'] = data['isPublished']
            if data.get('alias_domain') or data.get('alias_email'):
                alias_id = request.env['mail.alias.domain'].sudo().search([('name', '=', data.get('alias_domain'))],limit=1)
                updatable_fields["alias_name"] = data["alias_email"]
                updatable_fields["alias_domain_id"] = alias_id.id
            # Update the record
            if updatable_fields:
                job.write(updatable_fields)
            else:
                resp["status"] = 400
                resp["message"] = "No valid fields provided for update"
                return resp
            resp["status"] = 200
            resp["message"] = "Job updated successfully"
            resp["data"] = updatable_fields
            return resp

        except Exception as e:
            resp["status"] = 500
            resp["message"] = "Error updating job"
            resp["error"] = str(e)
        return resp

    @http.route('/hr-job-delete/<int:job_id>', type='json', auth='public', csrf=False, cors="*", website=True)
    def delete_job(self, job_id, **kwargs):
        resp={}
        try:
            job = request.env['hr.job'].sudo().browse(int(job_id))
            if job.exists():
                job.unlink()
                resp['status']=200
                resp['message']=f"Job Application Id {job_id} Delete Successfully"
                return resp
            else:
                resp['status']=404
                resp['message']=f"Job ID {job_id} not found!"
                return resp
        except Exception as e:
            print(str(e))
            resp['status']=500
            resp['message']="Error During Deletion!"
            resp['error']=str(e)
        return resp

class RecruitmentHrApplicant(http.Controller):

    @http.route("/hr-applicant",type="json",auth="public",csrf=False,cors="*",website=True)
    def get_hr_applicant(self,**kwargs):
        resp={}
        hr_applicant_list_data=[]
        application_map={
            "hired":"Hired",
            "archived":"Archived",
            "ongoing":"Ongoing",
            "refused":"Refused",
        }
        priority_map ={
            "0":"Normal",
            "1":"Good",
            "2":"Very Good",
            "3":"Excellent"
        }
        try:
            applicant_ids = request.env['hr.applicant'].sudo().search([])
            if applicant_ids:
                for val in applicant_ids:
                    hr_applicant_list_data.append({
                        "id":val.id,
                        "name": val.name,
                        "partner_name":val.partner_name,
                        "create_date":val.create_date,
                        "job_id":[{"id":val.job_id.id,"name":val.job_id.name}],
                        "name":val.name,
                        "stage_id":[{"id":val.stage_id.id,"name":val.stage_id.name}],
                        "application_status":application_map.get(val.application_status),
                        "priority":priority_map.get(val.priority),
                        "partner_mobile":val.partner_mobile,
                        "cate_ids":[{"id":cate_id.id,"name":cate_id.name} for cate_id in val.categ_ids],
                        "user_id":[{"id":val.user_id.id,"name":val.job_id.name}],

                    })
                resp['status']=200
                resp['message']="success"
                resp['number_of_records']=len(applicant_ids),
                resp['data']=hr_applicant_list_data
            else:
                resp['status'] = 404
                resp['message'] = "Records Not Found"
                resp['data'] = hr_applicant_list_data
        except Exception as e:
            print(str(e))
            resp['status']=500
            resp['message']="Error During Fetch All Records"
            resp['error']=str(e)
        return resp

    @http.route("/fetch-hr-applicant/<int:applicant_id>",type="json",auth="public",csrf=False,cors="*",website=True)
    def fetch_one_record_hr_applicant(self,applicant_id,**kwargs):
        resp={}
        priority_map = {
            "0": "Normal",
            "1": "Good",
            "2": "Very Good",
            "3": "Excellent"
        }
        try:
            applicant = request.env['hr.applicant'].sudo().browse(int(applicant_id))
            if not applicant.exists():
                resp['status']=404
                resp['message']=f"Record {applicant} Not Found"
                return resp
            plain_text = html2plaintext(applicant.description)
            data = {
                "id":applicant.id,
                "name":applicant.name,
                "partner_name":applicant.partner_name,
                "email_from":applicant.email_from,
                "email_cc":applicant.email_cc,
                "partner_phone":applicant.partner_phone,
                "partner_mobile":applicant.partner_mobile,
                "linkedin_profile":applicant.linkedin_profile,
                "type_id":applicant.type_id.id,
                "type_ids":[{"id":val.id,"name":val.name} for val in request.env['hr.recruitment.degree'].sudo().search([])],
                "note":applicant.note,
                "description":plain_text,
                "resume_attechment":applicant.resume_attachment,
                "candidate_address":applicant.candidate_address,
                "selected_interviewer_id":[{"id":applicant.interviewer_ids.ids}],
                "interviewer_ids": [{"id": user.id, "name": user.name} for user in request.env['res.users'].sudo().search(
                [('groups_id', 'in', request.env.ref('base.group_user').id)])],
                "selected_recruiter_id":[{"id":applicant.user_id.id}],
                "recruiter_ids": [{"id": user.id, "name": user.name} for user in request.env['res.users'].sudo().search(
                [('groups_id', 'in', request.env.ref('base.group_user').id)])],
                "priority":priority_map.get(applicant.priority),
                "selected_source_id":[{"id":applicant.source_id.id}],
                "source_ids":[{"id":val.id,"name":val.name} for val in request.env['utm.source'].sudo().search([])],
                "selected_medium_id": [{"id":applicant.medium_id.id}],
                "medium_ids":[{"id":val.id,"name":val.name} for val in request.env['utm.medium'].sudo().search([])],
                "availability": applicant.availability,
                "selected_cate_id":[{"id":cate_id.id,"name":cate_id.name} for cate_id in applicant.categ_ids],
                "cate_ids":[{"id":cate_id.id,"name":cate_id.name} for cate_id in request.env['hr.applicant.category'].sudo().search([])],
                "selected_key_skills_required_id": [{"id":skill_id.id,"name":skill_id.name} for skill_id in applicant.key_skills_require],
                "key_skills_required_ids": [{"id":skill_id.id,"name":skill_id.name} for skill_id in request.env['hr.skill'].sudo().search([])],
                "selected_education_required_id": [{"id":edu.id,"name":edu.name} for edu in applicant.education_required],
                "education_required_ids": [{"id":edu.id,"name":edu.name} for edu in request.env['hr.education'].sudo().search([])],
                "selected_experience_required_id": [{"id":exp.id,"name":exp.name} for exp in applicant.experience_required],
                "experience_required_ids": [{"id":exp.id,"name":exp.name} for exp in request.env['hr.experience'].sudo().search([])],
                "education_rating":applicant.education_rating,
                "experience_rating":applicant.experience_rating,
                "skill_rating":applicant.skill_rating,
                "hr_name":applicant.hr_name,
                "offer_date":applicant.offer_date,
                "salary_package":applicant.salary_package,
                "office_address":applicant.office_address,
                "joining_date":applicant.joining_date,
                "job_description":applicant.job_description,
                "interview_date":applicant.interview_date,
                "interview_time":applicant.interview_time,
                "interview_location":applicant.interview_location,
                "interview_result":applicant.interview_result,
                "education_details":applicant.education_details,
                "experience_details":applicant.experience_details,
                "experience_in_years":applicant.experience_in_years,
                "skill_details":applicant.skills_details,
                "certification_details":applicant.certification_details,
                "selected_job_id": [{"id": job_id.id, "name": job_id.name} for job_id in applicant.job_id],
                "job_ids": [{"id": job_id.id, "name": job_id.name} for job_id in request.env['hr.job'].sudo().search([])],
                "selected_department_id": [{"id": dp.id, "name": dp.name} for dp in applicant.department_id],
                "department_ids": [{"id": dp.id, "name": dp.name} for dp in request.env['hr.department'].sudo().search([])],
                "salary_expected":applicant.salary_expected,
                "salary_proposed":applicant.salary_proposed,
            }
            resp['status']=200
            resp['message'] = "Application fetched successfully"
            resp['data'] = data
            return resp
        except Exception as e:
            resp['status']=500
            resp['message']="Error During Fetch Record"
            resp['error']=str(e)
        return resp

    @http.route("/hr-applicant-delete/<int:applicant_id>",type="json",auth="public",csrf=False,cors="*",website=True)
    def delete_hr_applicant(self, applicant_id, **kwargs):
        resp = {}
        try:
            applicant = request.env['hr.applicant'].sudo().browse(int(applicant_id))
            if applicant.exists():
                applicant.unlink()
                resp['status'] = 200
                resp['message'] = f"Application Id {applicant_id} Delete Successfully"
                return resp
            else:
                resp['status'] = 404
                resp['message'] = f"Application ID {applicant_id} not found!"
                return resp
        except Exception as e:
            print(str(e))
            resp['status'] = 500
            resp['message'] = "Error During Deletion!"
            resp['error'] = str(e)
        return resp

    @http.route("/hr-applicant-update/<int:applicant_id>",type="json",auth="public",csrf=False,cors="*",website=True)
    def update_hr_applicant(self,applicant_id,**kwargs):
        resp={}
        try:
            data = json.loads(request.httprequest.data.decode()) if request.httprequest.data else {}
            applicant = request.env['hr.applicant'].sudo().browse(int(applicant_id))
            updatable_fields = {}
            if data.get('stage_id'):
                action_method = {
                    "stage_id":data.get('stage_id')
                }
                updatable_fields['stage_id']=action_method.get('stage_id')
            if not applicant.exists():
                resp["status"] = 404
                resp["message"] = f"Application with ID {applicant_id} not found"
                return resp
            if data.get('name'):
                updatable_fields['name']=data['name']
            if data.get('partner_name'):
                updatable_fields['partner_name']=data['partner_name']
            if data.get('email_from'):
                updatable_fields['email_from']=data['email_from']
            if data.get('email_cc'):
                updatable_fields['email_cc']=data['email_cc']
            if data.get('partner_phone'):
                updatable_fields['partner_phone']=data['partner_phone']
            if data.get('partner_mobile'):
                updatable_fields['partner_mobile']=data['partner_mobile']
            if data.get('linkedin_profile'):
                updatable_fields['linkedin_profile']=data['linkedin_profile']
            if data.get('type_id'):
                updatable_fields['type_id']=data['type_id']
            if data.get('note'):
                updatable_fields['note']=data['note']
            if data.get('description'):
                plain_text = html2plaintext(data['description'])
                updatable_fields['description']= plain_text
            if data.get('note'):
                updatable_fields['note']=data['note']
            if data.get('resume_attachment'):
                updatable_fields['resume_attachment']=data['resume_attachment']
            if data.get('candidate_address'):
                updatable_fields['candidate_address']=data['candidate_address']
            if data.get('interviewer_ids'):
                updatable_fields['interviewer_ids']=data['interviewer_ids']
            if data.get('user_id'):
                updatable_fields['user_id']=data['user_id']
            if data.get('priority'):
                updatable_fields['priority']=data['priority']
            if data.get('source_id'):
                updatable_fields['source_id']=data['source_id']
            if data.get('medium_id'):
                updatable_fields['medium_id']=data['medium_id']
            if data.get('availability'):
                updatable_fields['availability']=data['availability']
            if data.get('categ_ids'):
                updatable_fields['categ_ids']=data['categ_ids']
            if data.get('key_skills_required_id'):
                updatable_fields['key_skills_require']=data['key_skills_required_id']
            if data.get('education_required_id'):
                updatable_fields['education_required']=data['education_required_id']
            if data.get('experience_required_id'):
                updatable_fields['experience_required']=data['experience_required_id']
            if data.get('education_rating'):
                updatable_fields['education_rating']=data['education_rating']
            if data.get('experience_rating'):
                updatable_fields['experience_rating']=data['experience_rating']
            if data.get('skill_rating'):
                updatable_fields['skill_rating']=data['skill_rating']
            if data.get('hr_name'):
                updatable_fields['hr_name']=data['hr_name']
            if data.get('offer_date'):
                updatable_fields['offer_date']=data['offer_date']
            if data.get('salary_package'):
                updatable_fields['salary_package']=data['salary_package']
            if data.get('office_address'):
                updatable_fields['office_address']=data['office_address']
            if data.get('joining_date'):
                updatable_fields['joining_date']=data['joining_date']
            if data.get('job_description'):
                updatable_fields['job_description']=data['job_description']
            if data.get('interview_date'):
                updatable_fields['interview_date']=data['interview_date']
            if data.get('interview_time'):
                updatable_fields['interview_time']=data['interview_time']
            if data.get('interview_location'):
                updatable_fields['interview_location']=data['interview_location']
            if data.get('interview_result'):
                updatable_fields['interview_result']=data['interview_result']
            if data.get('education_details'):
                updatable_fields['education_details']=data['education_details']
            if data.get('experience_details'):
                updatable_fields['experience_details']=data['experience_details']
            if data.get('experience_in_years'):
                updatable_fields['experience_in_years']=data['experience_in_years']
            if data.get('skills_details'):
                updatable_fields['skills_details']=data['skills_details']
            if data.get('certification_details'):
                updatable_fields['certification_details']=data['certification_details']
            if data.get('job_id'):
                updatable_fields['job_id']=data['job_id']
            if data.get('department_id'):
                updatable_fields['department_id']=data['department_id']
            if data.get('salary_expected'):
                updatable_fields['salary_expected']=data['salary_expected']
            if data.get('salary_proposed'):
                updatable_fields['salary_proposed']=data['salary_proposed']
            if updatable_fields:
                applicant.write(updatable_fields)
            else:
                resp["status"] = 400
                resp["message"] = "No valid fields provided for update"
                return resp
            resp['status']=200
            resp["message"] = "Applicant updated successfully"
            resp["data"] = updatable_fields
            return resp
        except Exception as e:
            resp['status']=500
            resp['message']="Error During Record Updation"
            resp['error']=str(e)
        return resp

    @http.route("/hr-applicant-create", type="json", auth="public", csrf=False, cors="*",website=True)
    def create_hr_applicant(self, **kwargs):
        resp = {}
        try:
            data = json.loads(request.httprequest.data.decode()) if request.httprequest.data else {}
            applicant = request.env['hr.applicant'].sudo()
            creatable_fields = {}
            if not data.get('name'):
                resp["status"] = 404
                resp["message"] = "Name field is required"
                return resp
            if data.get('name'):
                creatable_fields['name']=data['name']
            if data.get('partner_name'):
                creatable_fields['partner_name'] = data['partner_name']
            if data.get('email_from'):
                creatable_fields['email_from'] = data['email_from']
            if data.get('email_cc'):
                creatable_fields['email_cc'] = data['email_cc']
            if data.get('partner_phone'):
                creatable_fields['partner_phone'] = data['partner_phone']
            if data.get('partner_mobile'):
                creatable_fields['partner_mobile'] = data['partner_mobile']
            if data.get('linkedin_profile'):
                creatable_fields['linkedin_profile'] = data['linkedin_profile']
            if data.get('type_id'):
                creatable_fields['type_id'] = data['type_id']
            if data.get('note'):
                creatable_fields['note'] = data['note']
            if data.get('description'):
                plain_text = html2plaintext(data['description'])
                creatable_fields['description'] = plain_text
            if data.get('note'):
                creatable_fields['note'] = data['note']
            if data.get('resume_attachment'):
                creatable_fields['resume_attachment'] = data['resume_attachment']
            if data.get('candidate_address'):
                creatable_fields['candidate_address'] = data['candidate_address']
            if data.get('interviewer_ids'):
                creatable_fields['interviewer_ids'] = data['interviewer_ids']
            if data.get('user_id'):
                creatable_fields['user_id'] = data['user_id']
            if data.get('priority'):
                creatable_fields['priority'] = data['priority']
            if data.get('source_id'):
                creatable_fields['source_id'] = data['source_id']
            if data.get('medium_id'):
                creatable_fields['medium_id'] = data['medium_id']
            if data.get('availability'):
                creatable_fields['availability'] = data['availability']
            if data.get('categ_ids'):
                creatable_fields['categ_ids'] = data['categ_ids']
            if data.get('key_skills_required_id'):
                creatable_fields['key_skills_require'] = data['key_skills_required_id']
            if data.get('education_required_id'):
                creatable_fields['education_required'] = data['education_required_id']
            if data.get('experience_required_id'):
                creatable_fields['experience_required'] = data['experience_required_id']
            if data.get('education_rating'):
                creatable_fields['education_rating'] = data['education_rating']
            if data.get('experience_rating'):
                creatable_fields['experience_rating'] = data['experience_rating']
            if data.get('skill_rating'):
                creatable_fields['skill_rating'] = data['skill_rating']
            if data.get('hr_name'):
                creatable_fields['hr_name'] = data['hr_name']
            if data.get('offer_date'):
                creatable_fields['offer_date'] = data['offer_date']
            if data.get('salary_package'):
                creatable_fields['salary_package'] = data['salary_package']
            if data.get('office_address'):
                creatable_fields['office_address'] = data['office_address']
            if data.get('joining_date'):
                creatable_fields['joining_date'] = data['joining_date']
            if data.get('job_description'):
                creatable_fields['job_description'] = data['job_description']
            if data.get('interview_date'):
                creatable_fields['interview_date'] = data['interview_date']
            if data.get('interview_time'):
                creatable_fields['interview_time'] = data['interview_time']
            if data.get('interview_location'):
                creatable_fields['interview_location'] = data['interview_location']
            if data.get('interview_result'):
                creatable_fields['interview_result'] = data['interview_result']
            if data.get('education_details'):
                creatable_fields['education_details'] = data['education_details']
            if data.get('experience_details'):
                creatable_fields['experience_details'] = data['experience_details']
            if data.get('experience_in_years'):
                creatable_fields['experience_in_years'] = data['experience_in_years']
            if data.get('skills_details'):
                creatable_fields['skills_details'] = data['skills_details']
            if data.get('certification_details'):
                creatable_fields['certification_details'] = data['certification_details']
            if data.get('job_id'):
                creatable_fields['job_id'] = data['job_id']
            if data.get('department_id'):
                creatable_fields['department_id'] = data['department_id']
            if data.get('salary_expected'):
                creatable_fields['salary_expected'] = data['salary_expected']
            if data.get('salary_proposed'):
                creatable_fields['salary_proposed'] = data['salary_proposed']
            if creatable_fields:
                applicant.create(creatable_fields)
            else:
                resp["status"] = 400
                resp["message"] = "No valid fields provided for create"
                return resp
            resp['status'] = 200
            resp["message"] = "Applicant create successfully"
            resp["data"] = creatable_fields
            return resp
        except Exception as e:
            resp['status'] = 500
            resp['message'] = "Error During Record create"
            resp['error'] = str(e)
        return resp

class PreOnBoarding(http.Controller):
    @http.route("/on-boarding-api", type='json', auth='public', csrf=False, cors="*", website=True)
    def get_hr_pre_onboarding(self,**kwargs):
        resp={}
        try:
            env = request.env
            preonboarding_ids = env['hr.pre.onboarding'].sudo().search_read([],[
                "id",
                "name",
                "email",
                "designation",
                "department",
                "salary",
                "location",
                "date_of_joining",
                "applicant_id",
                "state",
                "duly_sign_copy_of_emp",
                "resume_duly_sign_with_photo",
                "all_educational_certificate_with_10th_12th",
                "all_merits_certificate_diploma",
                "acceptance_of_resign_letter",
                "copy_of_relieving_letter",
                "last_three_months_salary_slip",
                "six_month_bank_statement",
                "previous_company_form16",
                "address_proof",
                "id_proof",
                "passport_size_photo",
                "acceptance_of_offer_letter",
                "fitness_certificate",
            ])
            if preonboarding_ids:
                for val in preonboarding_ids:
                    val['applicant_id'] = many2one_to_object(val.get('applicant_id'))
            if preonboarding_ids:
                resp['status']=200
                resp['message']="success"
                resp['data']=preonboarding_ids
            else:
                resp['status'] = 404
                resp['message'] = "Record Not Found"
                resp['data'] = preonboarding_ids
        except Exception as e:
            resp['status']=500
            resp['message']='Error During Fetch'
            resp['error']=str(e)
        return resp

    @http.route("/on-boarding-fetch-api/<int:onboarding_id>", type='json', auth='public', csrf=False, cors="*", website=True)
    def fetch_one_record_hr_pre_onboarding(self, onboarding_id,**kwargs):
        resp ={}
        try:
            env = request.env
            boarding_id = env['hr.pre.onboarding'].sudo().browse(onboarding_id)
            if not boarding_id.exists():
                resp['status']=404
                resp['message']='Record Not Found'
                return resp
            allowed_fields = {
                "id":boarding_id.id,
                "name":boarding_id.name,
                "email":boarding_id.email,
                "designation":boarding_id.designation,
                "department":boarding_id.department,
                "salary":boarding_id.salary,
                "location":boarding_id.location,
                "date_of_joining":boarding_id.date_of_joining,
                "state":boarding_id.state,
                "duly_sign_copy_of_emp":boarding_id.duly_sign_copy_of_emp,
                "resume_duly_sign_with_photo":boarding_id.resume_duly_sign_with_photo,
                "all_educational_certificate_with_10th_12th":boarding_id.all_educational_certificate_with_10th_12th,
                "all_merits_certificate_diploma":boarding_id.all_merits_certificate_diploma,
                "acceptance_of_resign_letter":boarding_id.acceptance_of_resign_letter,
                "copy_of_relieving_letter":boarding_id.copy_of_relieving_letter,
                "last_three_months_salary_slip":boarding_id.last_three_months_salary_slip,
                "six_month_bank_statement":boarding_id.six_month_bank_statement,
                "previous_company_form16":boarding_id.previous_company_form16,
                "address_proof":boarding_id.address_proof,
                "id_proof":boarding_id.id_proof,
                "passport_size_photo":boarding_id.passport_size_photo,
                "acceptance_of_offer_letter":boarding_id.acceptance_of_offer_letter,
                "fitness_certificate":boarding_id.fitness_certificate,
                "applicant_id":{"id":boarding_id.applicant_id.id,"name":boarding_id.applicant_id.name},
            }
            resp['status'] = 200
            resp['message'] = "Hr Pre Onboarding fetched successfully"
            resp['data'] = allowed_fields
            return resp
        except Exception as e:
            resp['status']=500
            resp['message']="Error During Fetch Record"
            resp['error']=str(e)
        return resp

    @http.route('/on-boarding-update-api/<int:onboarding_id>', type='json', auth='public', csrf=False, cors="*", website=True)
    def update_hr_pre_onboarding(self, onboarding_id, **kwargs):
        resp = {}
        try:
            env=request.env
            data = json.loads(request.httprequest.data.decode()) if request.httprequest.data else {}
            boarding_id = env['hr.pre.onboarding'].sudo().browse(onboarding_id)
            if not boarding_id.exists():
                resp["status"] = 404
                resp["message"] = f"Hr Pre Boarding with ID {onboarding_id} not found"
                return resp
            allowed_fields = [
                # "name",
                # "email",
                # "designation",
                "department",
                "salary",
                "location",
                "date_of_joining",
                "state",
                "duly_sign_copy_of_emp",
                "resume_duly_sign_with_photo",
                "all_educational_certificate_with_10th_12th",
                "all_merits_certificate_diploma",
                "acceptance_of_resign_letter",
                "copy_of_relieving_letter",
                "last_three_months_salary_slip",
                "six_month_bank_statement",
                "previous_company_form16",
                "address_proof",
                "id_proof",
                "passport_size_photo",
                "acceptance_of_offer_letter",
                "fitness_certificate",
                # "applicant_id",
            ]

            vals = {k: v for k, v in data.items() if k in allowed_fields}
            boarding_id.write(vals)
            resp['status'] = 200
            resp['message'] = 'Hr Pre Onboarding Updated Successfully'
            resp['id'] = boarding_id.id
            resp['data']=vals
        except Exception as e:
            resp['status'] = 500
            resp['message'] = "Error During Fetch Record"
            resp['error'] = str(e)
        return resp

    @http.route('/hr-pre-onboarding-delete-api/<int:onboarding_id>', type='json', auth='public', csrf=False, cors="*", website=True)
    def delete_hr_pre_onboarding(self, onboarding_id, **kwargs):
        resp = {}
        try:
            env=request.env
            boarding_id = env['hr.pre.onboarding'].sudo().browse(onboarding_id)
            if boarding_id.exists():
                boarding_id.unlink()
                resp['status'] = 200
                resp['message'] = f"Hr Pre Onboarding Application Id {onboarding_id} Delete Successfully"
                return resp
            else:
                resp['status'] = 404
                resp['message'] = f"Job ID {onboarding_id} not found!"
                return resp
        except Exception as e:
            print(str(e))
            resp['status'] = 500
            resp['message'] = "Error During Deletion!"
            resp['error'] = str(e)
        return resp

class MasterAPI(http.Controller):

    # @http.route('/master-api', type='json', auth='public', csrf=False, cors="*", website=True)
    # def master_create(self, **kwargs):
    #     resp = {}
    #     try:
    #         # Final lists
    #         dept_list = []
    #         res_partner_list = []
    #         res_partner_industry_list = []
    #         contract_type_batch_list = []
    #         hr_skill_batch_list = []
    #         res_user_batch_list = []
    #         interviewer_batch_list = []
    #         applicant_batch_list = []
    #         utm_source_batch_list = []
    #         utm_medium_batch_list = []
    #         hr_applicant_category_batch_list = []
    #         hr_experience_batch_list = []
    #         hr_education_batch_list = []
    #         hr_job_batch_list=[]
    #         limit = 1000
    #
    #         # ---- Separate offsets for each model ----
    #         offsets = {
    #             "dept": 0,
    #             "partner": 0,
    #             "industry": 0,
    #             "contract": 0,
    #             "skill": 0,
    #             "users": 0,
    #             "interviewer": 0,
    #             "applicant": 0,
    #             "source": 0,
    #             "medium": 0,
    #             "hr_applicant_category": 0,
    #             "education": 0,
    #             "experience": 0,
    #             "job": 0,
    #         }
    #
    #         while True:
    #             nothing_fetched = True
    #
    #             # -------------------- Departments --------------------
    #             dept_batch = request.env['hr.department'].sudo().search([], limit=limit, offset=offsets["dept"])
    #             if dept_batch:
    #                 nothing_fetched = False
    #                 for rec in dept_batch:
    #                     dept_list.append({"id": rec.id, "name": rec.name})
    #                 offsets["dept"] += limit
    #
    #             # -------------------- Partners --------------------
    #             partner_batch = request.env['res.partner'].sudo().search(
    #                 [('company_id', '=', request.env.user.company_id.id)],
    #                 limit=limit, offset=offsets["partner"]
    #             )
    #             if partner_batch:
    #                 nothing_fetched = False
    #                 for rec in partner_batch:
    #                     res_partner_list.append({"id": rec.id, "name": rec.name})
    #                 offsets["partner"] += limit
    #
    #             # -------------------- Industries --------------------
    #             industry_batch = request.env['res.partner.industry'].sudo().search([], limit=limit,
    #                                                                                offset=offsets["industry"])
    #             if industry_batch:
    #                 nothing_fetched = False
    #                 for rec in industry_batch:
    #                     res_partner_industry_list.append({"id": rec.id, "name": rec.name})
    #                 offsets["industry"] += limit
    #
    #             # -------------------- Contract Types --------------------
    #             contract_batch = request.env['hr.contract.type'].sudo().search([], limit=limit,
    #                                                                            offset=offsets["contract"])
    #             if contract_batch:
    #                 nothing_fetched = False
    #                 for rec in contract_batch:
    #                     contract_type_batch_list.append({"id": rec.id, "name": rec.name})
    #                 offsets["contract"] += limit
    #
    #             # -------------------- Skills --------------------
    #             skill_batch = request.env['hr.skill'].sudo().search([], limit=limit, offset=offsets["skill"])
    #             if skill_batch:
    #                 nothing_fetched = False
    #                 for rec in skill_batch:
    #                     hr_skill_batch_list.append({"id": rec.id, "name": rec.name})
    #                 offsets["skill"] += limit
    #
    #             # -------------------- Users --------------------
    #             user_batch = request.env['res.users'].sudo().search([], limit=limit, offset=offsets["users"])
    #             if user_batch:
    #                 nothing_fetched = False
    #                 for rec in user_batch:
    #                     res_user_batch_list.append({"id": rec.id, "name": rec.name})
    #                 offsets["users"] += limit
    #
    #             # -------------------- Interviewers (same as users?) --------------------
    #             interviewer_batch = request.env['res.users'].sudo().search([], limit=limit,
    #                                                                        offset=offsets["interviewer"])
    #             if interviewer_batch:
    #                 nothing_fetched = False
    #                 for rec in interviewer_batch:
    #                     interviewer_batch_list.append({"id": rec.id, "name": rec.name})
    #                 offsets["interviewer"] += limit
    #
    #             # -------------------- Hr Application --------------------
    #             applicant_batch = request.env['hr.applicant'].sudo().search([], limit=limit,
    #                                                                        offset=offsets["applicant"])
    #             if applicant_batch:
    #                 nothing_fetched = False
    #                 for rec in applicant_batch:
    #                     applicant_batch_list.append({"id": rec.id, "name": rec.name  ,"education_rating":rec.education_rating,
    #                                                  "experience_rating":rec.experience_rating,
    #                                                  "skill_rating":rec.skill_rating,})
    #                 offsets["applicant"] += limit
    #
    #             # -------------------- UTM Source --------------------
    #             utm_source_batch = request.env['utm.source'].sudo().search([], limit=limit,
    #                                                                         offset=offsets["source"])
    #             if utm_source_batch:
    #                 nothing_fetched = False
    #                 for rec in utm_source_batch:
    #                     utm_source_batch_list.append({"id": rec.id, "name": rec.name})
    #                 offsets["source"] += limit
    #
    #             # -------------------- UTM Medium --------------------
    #             utm_medium_batch = request.env['utm.medium'].sudo().search([], limit=limit,
    #                                                                        offset=offsets["medium"])
    #             if utm_medium_batch:
    #                 nothing_fetched = False
    #                 for rec in utm_medium_batch:
    #                     utm_medium_batch_list.append({"id": rec.id, "name": rec.name})
    #                 offsets["medium"] += limit
    #
    #             # -------------------- Hr Applicant Category --------------------
    #             hr_applicant_category_batch = request.env['hr.applicant.category'].sudo().search([], limit=limit,
    #                                                                        offset=offsets["hr_applicant_category"])
    #             if hr_applicant_category_batch:
    #                 nothing_fetched = False
    #                 for rec in hr_applicant_category_batch:
    #                     hr_applicant_category_batch_list.append({"id": rec.id, "name": rec.name})
    #                 offsets["hr_applicant_category"] += limit
    #
    #             # -------------------- Hr Education  --------------------
    #             hr_education_batch = request.env['hr.education'].sudo().search([], limit=limit,
    #                                                                        offset=offsets["education"])
    #             if hr_education_batch:
    #                 nothing_fetched = False
    #                 for rec in hr_education_batch:
    #                     hr_education_batch_list.append({"id": rec.id, "name": rec.name})
    #                 offsets["education"] += limit
    #
    #             # -------------------- Hr experience  --------------------
    #             hr_experience_batch = request.env['hr.experience'].sudo().search([], limit=limit,
    #                                                                            offset=offsets["experience"])
    #             if hr_experience_batch:
    #                 nothing_fetched = False
    #                 for rec in hr_experience_batch:
    #                     hr_experience_batch_list.append({"id": rec.id, "name": rec.name})
    #                 offsets["experience"] += limit
    #
    #             # -------------------- Hr experience  --------------------
    #             hr_job_batch = request.env['hr.job'].sudo().search([], limit=limit,
    #                                                                            offset=offsets["job"])
    #             if hr_job_batch:
    #                 nothing_fetched = False
    #                 for rec in hr_job_batch:
    #                     hr_job_batch_list.append({"id": rec.id, "name": rec.name})
    #                 offsets["job"] += limit
    #
    #             # ---- If ALL models returned empty in this iteration → stop ----
    #             if nothing_fetched:
    #                 break
    #
    #         resp['status'] = 200
    #         resp['message'] = "Master data fetch complete"
    #         resp['data'] = {
    #             "department_ids": dept_list,
    #             "partner_ids": res_partner_list,
    #             "industry_ids": res_partner_industry_list,
    #             "contract_type_ids": contract_type_batch_list,
    #             "skill_ids": hr_skill_batch_list,
    #             "recruiter_ids": res_user_batch_list,
    #             "interviewer_ids": interviewer_batch_list,
    #             "applicant_ids": applicant_batch_list,
    #             "applicant_category_ids": hr_applicant_category_batch_list,
    #             "utm_medium_ids": utm_medium_batch_list,
    #             "utm_source_ids": utm_source_batch_list,
    #             "hr_experience_ids": hr_experience_batch_list,
    #             "hr_education_ids": hr_education_batch_list,
    #             "hr_job_ids": hr_job_batch_list,
    #         }
    #
    #     except Exception as e:
    #         resp['status'] = 500
    #         resp['message'] = "Error During Fetch"
    #         resp['error'] = str(e)
    #
    #     return resp

    @http.route('/master-api', type='json', auth='public', csrf=False, cors="*", website=True)
    def master_create(self,**kwargs):
        try:
            env = request.env
            domain = env['hr.job'].sudo()._address_id_domain()
            partner_ids = env['res.partner'].sudo().search_read(domain,['id', 'name'])
            newjob = env['hr.job'].sudo()._default_address_id()
            email_alias_id = env['mail.alias.domain'].sudo().search_read([],['id','name'])

            resp = {
                "status": 200,
                "message": "Master data fetch complete",
                "data": {
                    "department_ids": env['hr.department'].sudo().search_read(
                        [], ['id', 'name']
                    ),
                    "address_id": partner_ids if partner_ids else newjob,
                    "industry_ids": env['res.partner.industry'].sudo().search_read(
                        [], ['id', 'name']
                    ),
                    "contract_type_ids": env['hr.contract.type'].sudo().search_read(
                        [], ['id', 'name']
                    ),
                    "skill_ids": env['hr.skill'].sudo().search_read(
                        [], ['id', 'name']
                    ),
                    "recruiter_ids": env['res.users'].sudo().search_read(
                        [], ['id', 'name']
                    ),
                    "interviewer_ids": env['res.users'].sudo().search_read(
                        [], ['id', 'name']
                    ),
                    "applicant_ids": env['hr.applicant'].sudo().search_read(
                        [], ['id', 'name']
                    ),
                    "applicant_category_ids": env['hr.applicant.category'].sudo().search_read(
                        [], ['id', 'name']
                    ),
                    "utm_source_ids": env['utm.source'].sudo().search_read(
                        [], ['id', 'name']
                    ),
                    "utm_medium_ids": env['utm.medium'].sudo().search_read(
                        [], ['id', 'name']
                    ),
                    "hr_experience_ids": env['hr.experience'].sudo().search_read(
                        [], ['id', 'name']
                    ),
                    "hr_education_ids": env['hr.education'].sudo().search_read(
                        [], ['id', 'name']
                    ),
                    "hr_job_ids": env['hr.job'].sudo().search_read(
                        [], ['id', 'name','alias_email','alias_name']
                    ),
                    "email_alias_ids":email_alias_id,
                }
            }

            return resp

        except Exception as e:
            return {
                "status": 500,
                "message": "Error During Fetch",
                "error": str(e)
            }

class RecruitmentSettingConfiguration(http.Controller):
    pass


class EmployeeAPI(http.Controller):

    @http.route('/api/get/employee/alldata', type='json', auth='public', csrf=False, cors="*", website=True)
    def get_all_employee_data(self, **kwargs):
        resp = {}
        try:
            # Always use sudo for public routes.................**************,,,......$$$$$$$$$############@@@@@@@@@@@@@@

            limit = 80
            offset = 0
            query = f"""
                SELECT
                    id, name, mobile_phone, work_email, job_title, active, birthday, gender,job_id,department_id,parent_id,coach_id,
                    '/web/image/hr.employee/' || id || '/image_1920' AS image_url
                FROM hr_employee
                ORDER BY id DESC
                LIMIT {limit} OFFSET {offset}
            """
            # query = """
            #     SELECT
            #         id,
            #         name,
            #         mobile_phone,
            #         work_email,
            #         job_title,
            #         active,
            #         birthday,
            #         gender,
            #         '/web/image/hr.employee/' || id || '/image_1920' AS image_url
            #     FROM hr_employee
            # """
            request.env.cr.execute(query)
            result = request.env.cr.dictfetchall()
            for val in result:
                if val.get('job_id'):
                    job_id =request.env['hr.job'].sudo().search([('id', '=', val.get('job_id'))])
                    if job_id:
                        data1 = [
                            {
                                'id': jb.id,
                                'name': jb.name,
                            }
                            for jb in job_id
                        ]
                        if data1:
                            val.update({'job_id':data1 })
                if val.get('department_id'):
                    department_id = request.env['hr.department'].sudo().search([('id','=',val.get('department_id'))])
                    if department_id:
                        data2 = [
                        {
                            'id': dp.id,
                            'name': dp.name,
                        }
                        for dp in department_id
                    ]
                        if data2:
                            val.update({'department_id':data2 })


                if val.get('parent_id'):
                    parent_id =request.env['hr.employee'].sudo().search([('id','=',val.get('parent_id'))])
                    if parent_id:
                        data3 = [
                        {
                            'id': pt.id,
                            'name': pt.name,
                        }
                        for pt in parent_id
                    ]
                        if data3:
                            val.update({'parent_id':data3})

                if val.get('coach_id'):
                    coach_id =request.env['hr.employee'].sudo().search([('id', '=', val.get('coach_id'))])
                    if coach_id:
                        data4 = [
                        {
                            'id': ci.id,
                            'name': ci.name,
                        }
                        for ci in coach_id
                    ]
                        if data4:
                            val.update({'coach_id':data4})
            if result:
                resp["status"] = 200
                resp["message"] = "Success"
                resp["data"] = result
        except Exception as e:
            resp["status"] = 500
            resp["errorMessage"] = str(e)
            print("Employee API error:", str(e))
        return resp

    @http.route('/api/employee/create', type='json', auth='public', csrf=False, cors='*', website=True)
    def employee_create_api(self, **kwargs):
        resp = {}
        try:
            # Parse JSON request body
            data = json.loads(request.httprequest.data.decode()) if request.httprequest.data else {}

            # Extract fields
            name = data.get("name")
            work_email = data.get("work_email")
            mobile_phone = data.get("mobile_phone")
            job_title = data.get("job_title")
            birthday = data.get("birthday")
            gender = data.get("gender")
            user_id = data.get("user_id")
            image_base64 = data.get("image")


            # Validate required field
            if not name:
                return {'status': 400, 'message': "Employee name is required."}

            user = None
            company_id = False
            if user_id:
                try:
                    user_id = int(user_id)
                    user = request.env['res.users'].sudo().browse(user_id)
                    if user.exists():
                        company_id = user.company_id.id
                except Exception:
                    user = None
                    company_id = False

            # Prepare values
            employee_vals = {
                'name': name,
                'work_email': work_email,
                'mobile_phone': mobile_phone,
                'job_title': job_title,
                'birthday': birthday,
                'gender': gender,
            }

            # Link to user if exists
            # if user and user.exists():
            #     employee_vals['user_id'] = user.id
            #     employee_vals['company_id'] = company_id

            # Create employee
                # If image provided, save it

            with open(image_base64, "rb") as f:
                encoded = base64.b64encode(f.read()).decode('utf-8')
                employee_vals['image_1920']=encoded
            employee = request.env['hr.employee'].sudo().create(employee_vals)
            resp['status'] = 200
            resp['message'] = "Employee created successfully."
            resp['data'] = {
                'employee_id': employee.id,
                'name': employee.name,
                'work_email': employee.work_email,
                'mobile_phone': employee.mobile_phone,
                'job_title': employee.job_title,
                "image_url": f"/web/image/hr.employee/{employee.id}/image_1920"
                # 'user_id': employee.user_id.id if employee.user_id else None,
                # 'company_id': employee.company_id.id if employee.company_id else None
            }

        except Exception as e:
            resp['status'] = 500
            resp['message'] = "Error while creating employee."
            resp['error'] = str(e)
            print("❌ Employee API Error:", e)

        return resp

    @http.route('/api/employee/update', type='json', auth='public', csrf=False, cors="*", website=True)
    def employee_update_api(self, **kwargs):
        resp = {}
        try:
            data = json.loads(request.httprequest.data.decode()) if request.httprequest.data else kwargs
            if not data:
                resp['status'] = 400
                resp['message'] = "No data provided!"
                return resp

            emp_id = data.get("id")
            if not emp_id:
                resp['status'] = 400
                resp['message'] = "Employee ID is required!"
                return resp

            employee = request.env['hr.employee'].sudo().browse(emp_id)
            if not employee.exists():
                resp['status'] = 404
                resp['message'] = f"Employee with ID {emp_id} not found!"
                return resp

            # Prepare update values
            vals = {}
            if "name" in data:
                vals["name"] = data["name"]
            if "work_email" in data:
                vals["work_email"] = data["work_email"]
            if "active" in data:
                vals["active"] = data["active"]
            if "mobile_phone" in data:
                vals["mobile_phone"] = data["mobile_phone"]
            if "birthday" in data:
                vals["birthday"] = data["birthday"]
            if "gender" in data:
                vals["gender"] = data["gender"]
            if "job_title" in data:
                vals["job_title"] = data["job_title"]
            if "image" in data:
                with open(data["image"], "rb") as f:
                    encoded = base64.b64encode(f.read()).decode('utf-8')
                    if "image" in data:
                        vals["image_1920"] = encoded
            # if "job_id" in data:
            #     vals["job_id"] = data["job_id"]
            # if "department_id" in data:
            #     vals["department_id"] = data["department_id"]
            # if "grade_id" in data:
            #     vals["grade_id"] = data["grade_id"]
            # if "level_id" in data:
            #     vals["level_id"] = data["level_id"]
            # if "parent_id" in data:
            #     vals["parent_id"] = data["parent_id"]
            # if "coach_id" in data:
            #     vals["coach_id"] = data["coach_id"]
            if vals:
                employee.write(vals)
            #     set_clause = ", ".join([f"{key} = %s" for key in vals.keys()])
            #     values = list(vals.values()) + [emp_id]
            #     query = f"UPDATE hr_employee SET {set_clause} WHERE id = %s"
            #     request.env.cr.execute(query, values)
            #     request.env.cr.commit()
            # query = "select id,name,work_email,mobile_phone,job_title ,active ,birthday ,gender from hr_employee WHERE id = %s"
            # request.env.cr.execute(query, (emp_id,))
            # employee = request.env.cr.fetchall()
            # val=False
            for employee in employee:
                vals={
                    "id": employee.id,
                    "name": employee.name,
                    "work_email": employee.work_email,
                    "mobile_phone": employee.mobile_phone,
                    "job_title": employee.job_title,
                    "active": employee.active,
                    "birthday": employee.birthday,
                    "gender": employee.gender,
                    'user_id':employee.user_id.id,
                    "image_url": f"/web/image/hr.employee/{employee.id}/image_1920"
                }
            resp["status"] = 200
            resp["message"] = "Employee updated successfully!"
            resp["data"] = vals
        except Exception as e:
            resp["status"] = 500
            resp["errorMessage"] = str(e)
            print("Employee API error:", str(e))
        return resp

    @http.route('/api/employee/delete', type='json', auth='public', csrf=False, cors="*", website=True)
    def employee_delete_api(self, **kwargs):
        resp = {}
        try:
            data = json.loads(request.httprequest.data.decode()) if request.httprequest.data else kwargs
            if not data:
                resp["status"] = 400
                resp["message"] = "No data provided!"
                return resp
            emp_ids = data.get("id")
            if not emp_ids:
                resp["status"] = 400
                resp["message"] = "Employee ID is required!"
                return resp
            emp_ids = request.env['hr.employee'].sudo().browse(emp_ids)
            if len(emp_ids)==1 and emp_ids.exists():
                emp_ids.unlink()
                resp["status"] = 200
                resp["message"] = f"Employee (ID: {emp_ids.id}) deleted successfully!"
            else:
                emp_ids.unlink()
                resp["status"] = 200
                resp["message"] = f"Employee (ID: {emp_ids.ids}) deleted successfully!"

            # if len(emp_id)==1:
            #     request.env.cr.execute("select id from hr_employee where id=%s",(emp_id,))
            #     employee = request.env.cr.fetchone()[0]
            # else:
            #     request.env.cr.execute("select id from hr_employee where id in %s", (tuple(emp_id),))
            #     employee = request.env.cr.dictfetchall()
            # if not employee:
            #     resp["status"] = 404
            #     resp["message"] = f"Employee with ID {emp_id} not found!"
            #     return resp
            # if len(employee)==1:
            #     request.env.cr.execute("DELETE FROM hr_employee WHERE id=%s", (emp_id,))
            #     request.env.cr.commit()
            #     resp["status"] = 200
            #     resp["message"] = f"Employee (ID: {emp_id}) deleted successfully!"
            # else:
            #     request.env.cr.execute("DELETE FROM hr_employee WHERE id in %s", (tuple(emp_id),))
            #     request.env.cr.commit()
            #     resp["status"] = 200
            #     resp["message"] = f"Employee (ID: {emp_id}) deleted successfully!"
        except Exception as e:
            resp["status"] = 500
            resp["errorMessage"] = "Employee Delete API error" + " " + str(e)
            print("Employee Delete API error:", str(e))
        return resp

