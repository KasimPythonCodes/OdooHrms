{
    "name": "Recruitment Extension Api",
    "version": "1.0",
    "summary": "",
    "category": "",
    "author": "",
    "depends": ['base',"web","mail",'hr'],
    "data": [
    ],
    "controllers": True,
    "application": False,
    "installable": True,
    'license': 'OEEL-1',
}
