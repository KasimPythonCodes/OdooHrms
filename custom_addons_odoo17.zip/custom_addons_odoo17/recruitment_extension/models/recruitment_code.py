
from odoo.tools.config import config
from odoo import api,models, http, SUPERUSER_ID, _

global config
set_config = config.get('config')
import pytz
from odoo.tools import html2plaintext
global alias_names,alias_domains
class Alias(models.Model):
    _inherit = 'mail.alias'

    # def _check_unique(self, alias_names, alias_domains):
    #     if self.env.context.get('skip_alias_unique'):
    #         alias_names =alias_names
    #         alias_domains=alias_domains
    #         return
    #     return super()._check_unique(alias_names, alias_domains)

    # @api.model_create_multi
    # def create(self, vals_list):
    #     for vals in vals_list:
    #         alias_name = vals.get('alias_name')
    #         alias_domain_id = vals.get('alias_domain_id')
    #         if alias_name and alias_domain_id:
    #             existing = self.sudo().search([
    #                 ('alias_name', '=', alias_name),
    #                 ('alias_domain_id', '=', alias_domain_id)
    #             ], limit=1)
    #             if existing and self.env.context.get('skip_alias_unique'):
    #                 domain_id = request.env['mail.alias.domain'].sudo().search(['id','=',alias_domain_id],limit=1)
    #                 #REUSE instead of creating
    #                 vals_list[0].update({'alias_domain_id':domain_id.id})
    #     return super().create(vals_list)


# class HrJob(models.Model):
#     _inherit = 'hr.job'
#     @api.model_create_multi
#     def create(self, vals_list):
#         ctx = dict(self.env.context, skip_alias_unique=True)
#         return super(HrJob, self.with_context(ctx)).create(vals_list)
