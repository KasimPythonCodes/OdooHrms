from odoo import models, fields, api

class HrShiftSwap(models.Model):
    _name = 'hr.shift.swap'
    _description = 'Shift Swap Request'

    requester_id = fields.Many2one('hr.employee', string="Requested By", required=True, default=lambda self: self.env.user.employee_id)
    shift_id = fields.Many2one('hr.shift', string="My Shift", required=True)
    target_employee_id = fields.Many2one('hr.employee', string="Swap With", required=True)
    target_shift_id = fields.Many2one('hr.shift', string="Their Shift", required=True)
    reason = fields.Text("Reason")
    state = fields.Selection([
        ('draft', 'Draft'),
        ('submitted', 'Submitted'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ], default='draft')

    def action_submit(self):
        self.write({'state': 'submitted'})

    def action_approve(self):
        # Swap shifts
        self.shift_id.employee_id, self.target_shift_id.employee_id = self.target_shift_id.employee_id, self.shift_id.employee_id
        self.write({'state': 'approved'})

    def action_reject(self):
        self.write({'state': 'rejected'})
