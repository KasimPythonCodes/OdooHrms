from odoo import models, fields, api
from odoo.exceptions import UserError
from datetime import datetime, date, timedelta


class EmployeeTaskReport(models.Model):
    _name = 'employee.task.report'
    _description = 'Employee Task Report'
    _rec_name = 'employee_id'

    employee_id = fields.Many2one('hr.employee', string="Employee", required=True)

    task_count = fields.Integer("Total Tasks")
    total_hours = fields.Float("Total Planned Hours")
    project_ids = fields.Many2many('project.project', string="Projects")
    task_analytics = fields.Char(string="Task Analytics")
    attendance_analytics = fields.Float(string="Attendance Analytics")
    task_completion_rate = fields.Float(string="Task Completion Rate (%)")

    def action_calculate_analytics(self):
        for record in self:
            if not record.employee_id or not record.employee_id.user_id:
                raise UserError("Selected employee doesn't have a linked user.")

            user_id = record.employee_id.user_id.id

            tasks = self.env['project.task'].search([
                ('user_ids', 'in', [user_id])
            ])

            task_count = len(tasks)
            project_ids = list(set(tasks.mapped('project_id.id')))

            completed_on_time = 0
            completed_tasks = 0

            for task in tasks:
                if task.task_complete_date and task.date_deadline:
                    completed_tasks += 1

                    # Convert datetime to date if needed
                    complete_date = task.task_complete_date.date() if isinstance(task.task_complete_date, datetime) else task.task_complete_date
                    deadline_date = task.date_deadline.date() if isinstance(task.date_deadline, datetime) else task.date_deadline

                    if complete_date <= deadline_date:
                        completed_on_time += 1

            # Calculate completion rate
            task_completion_rate = (completed_on_time / completed_tasks) * 100 if completed_tasks else 0.0

            #  Attendance This Month
            today = date.today()
            first_day = today.replace(day=1)
            last_day = (first_day.replace(month=first_day.month % 12 + 1, day=1) - timedelta(
                days=1)) if first_day.month != 12 else date(today.year, 12, 31)

            attendances = self.env['hr.attendance'].search([
                ('employee_id', '=', record.employee_id.id),
                ('check_in', '>=', datetime.combine(first_day, datetime.min.time())),
                ('check_in', '<=', datetime.combine(last_day, datetime.max.time())),
            ])
            attendance_count = len(attendances)

            # Write values
            record.write({
                'task_count': task_count,
                'project_ids': [(6, 0, project_ids)],
                'task_completion_rate': task_completion_rate,
                'attendance_analytics': attendance_count,
            })

    def write(self, vals):
        result = super().write(vals)
        if 'employee_id' in vals:
            for rec in self:
                rec.action_calculate_analytics()
        return result


class ProjectTask(models.Model):
    _inherit = 'project.task'

    task_complete_date = fields.Date(string="Task Complete Date", readonly=True)

    def write(self, vals):
        res = super().write(vals)

        for task in self:
            if vals.get('state') == '1_done' and not task.task_complete_date:
                task.task_complete_date = date.today()

        return res

    @api.model
    def create(self, vals):
        task = super().create(vals)
        if task.stage_id.state == '1_done':
            task.task_complete_date = date.today()
        return task



class DepartmentReport(models.Model):
    _name = 'hr.department.report'
    _description = 'Department Report'

    department_id = fields.Many2one('hr.department', string="Department", required=True)
    workload_distribution = fields.Text(string="Workload Distribution")
    shift_attendance_rate = fields.Float(string="Shift Attendance Rate (%)")
    overtime_analysis = fields.Float(string="Overtime Analysis (Hrs)")

    def action_generate_report(self):
        for rec in self:
            workload_data = []
            if rec.department_id:
                employees = self.env['hr.employee'].search([
                    ('department_id', '=', rec.department_id.id)
                ])
            #     for emp in employees:
            #         if emp.user_id:
            #
            #
            #             task_count = self.env['project.task'].search_count([
            #                 ('user_ids', 'in', [emp.user_id.id])
            #             ])
            #             workload_data.append(f"{emp.name}: {task_count} tasks")
            #         else:
            #             workload_data.append(f"{emp.name}: No user assigned")
            # # make sure each `rec` gets its own result
            # rec.workload_distribution = "\n".join(workload_data)

                all_tasks = self.env['project.task'].search([])

                for emp in employees:
                    if emp.user_id:
                        # 🔍 filter only tasks assigned to this user
                        emp_tasks = all_tasks.filtered(lambda t: emp.user_id in t.user_ids)
                        task_count = len(emp_tasks)
                        workload_data.append(f"{emp.name}: {task_count} tasks")
                    else:
                        workload_data.append(f"{emp.name}: No user assigned")

                rec.workload_distribution = "\n".join(workload_data)

            # 2️⃣ Shift Attendance Rate
            leave_count = 0
            shift_count = 0
            today = fields.Date.today()
            for emp in employees:
                shift = self.env['hr.shift'].search([
                    ('employee_id', '=', emp.id),
                    ('date', '=', today)
                ])
                if shift:
                    shift_count += 1
                    leave = self.env['hr.leave'].search([
                        ('employee_id', '=', emp.id),
                        ('request_date_from', '<=', today),
                        ('request_date_to', '>=', today),
                        ('state', '=', 'validate')
                    ], limit=1)
                    if leave:
                        leave_count += 1
            rec.shift_attendance_rate = 0.0
            if shift_count:
                attendance_rate = 100 * (shift_count - leave_count) / shift_count
                rec.shift_attendance_rate = round(attendance_rate, 2)

            # 3️⃣ Overtime Analysis (last 30 days)
            overtime_total = 0.0
            one_month_ago = fields.Date.today() - timedelta(days=30)
            for emp in employees:
                attendances = self.env['hr.attendance'].search([
                    ('employee_id', '=', emp.id),
                    ('check_in', '>=', one_month_ago)
                ])
                for att in attendances:
                    if att.overtime_hours:
                        overtime_total += att.overtime_hours
            rec.overtime_analysis = round(overtime_total, 2)