from odoo import models, fields, api


class HrShiftProductivity(models.Model):
    _name = 'hr.shift.productivity'
    _description = 'Shift Productivity Report'

    shift_id = fields.Many2one('hr.shift', string="Shift", required=True)
    employee_id = fields.Many2one('hr.employee', related='shift_id.employee_id', store=True)
    completed_tasks = fields.Integer("Completed Tasks")
    hours_worked = fields.Float("Hours Worked")
    efficiency_percent = fields.Float("Efficiency (%)", compute="_compute_efficiency")

    @api.depends('completed_tasks', 'hours_worked')
    def _compute_efficiency(self):
        for rec in self:
            rec.efficiency_percent = (rec.completed_tasks / rec.hours_worked * 10) if rec.hours_worked else 0
