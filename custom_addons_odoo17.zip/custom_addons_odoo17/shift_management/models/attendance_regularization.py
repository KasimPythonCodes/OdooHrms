from odoo import models, fields, api
from odoo.exceptions import UserError
from datetime import timedelta


class AttendanceRegularization(models.Model):
    _name = 'attendance.regularization'
    _description = 'Attendance Regularization'

    employee_id = fields.Many2one(
        'hr.employee',
        string="Employee",
        required=True,
        default=lambda self: self.env['hr.employee'].search([('user_id', '=', self.env.uid)], limit=1)
    )
    date = fields.Date(string="Date", required=True)
    check_in = fields.Datetime(string="Check In", required=True)
    check_out = fields.Datetime(string="Check Out", required=True)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('submitted', 'Submitted'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected')
    ], string="Status", default='draft', tracking=True)

    def action_submit(self):
        for rec in self:
            rec.state = 'submitted'

            # Get manager from employee record
            employee = rec.employee_id
            manager = employee.parent_id
            if not manager or not manager.user_id or not manager.work_email:
                raise UserError("Manager or their email is not set for this employee.")

            # Email content
            subject = "Attendance Regularization Request"
            body = f"""
                <p>Dear {manager.name},</p>
                <p>Please approve my attendance regularization request.</p>
                <p><strong>Date:</strong> {rec.date.strftime('%A, %d %B %Y')}<br/>
                <strong>Check In:</strong> {rec.check_in.strftime('%H:%M')}<br/>
                <strong>Check Out:</strong> {rec.check_out.strftime('%H:%M')}</p>
                <p>Regards,<br/>{employee.name}</p>
            """

            # Send email
            self.env['mail.mail'].create({
                'subject': subject,
                'body_html': body,
                'email_to': manager.work_email,
                'author_id': self.env.user.partner_id.id,
            }).send()

    def action_approve(self):
        for rec in self:
            rec.state = 'approved'

            # Search for existing attendance record for that date and employee
            attendance = self.env['hr.attendance'].search([
                ('employee_id', '=', rec.employee_id.id),
                ('check_in', '>=', rec.date),
                ('check_in', '<', rec.date + timedelta(days=1))  # assumes check_in is a datetime
            ], limit=1)

            if attendance:
                # Update existing record
                attendance.write({
                    'check_in': rec.check_in,
                    'check_out': rec.check_out
                })
            else:
                # If no record found, create one
                self.env['hr.attendance'].create({
                    'employee_id': rec.employee_id.id,
                    'check_in': rec.check_in,
                    'check_out': rec.check_out
                })

    # def action_approve(self):
    #     for rec in self:
    #         rec.state = 'approved'
    #         self.env['hr.attendance'].create({
    #             'employee_id': rec.employee_id.id,
    #             'check_in': rec.check_in,
    #             'check_out': rec.check_out
    #         })

    def action_reject(self):
        for rec in self:
            rec.state = 'rejected'
