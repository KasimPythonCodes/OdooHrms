from odoo import models, fields, api

class HrShiftSwap(models.Model):
    _name = 'hr.shift.swap'
    _description = 'Shift Swap Request'

    shift_id = fields.Many2one('hr.shift', string="Current Shift", required=True)
    requested_by = fields.Many2one('hr.employee', string="Requested By", required=True)
    swap_with = fields.Many2one('hr.employee', string="Swap With", required=True)
    reason = fields.Text()
    state = fields.Selection([
        ('requested', 'Requested'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected')
    ], default='requested')

    def approve_swap(self):
        for rec in self:
            rec.shift_id.employee_id = rec.swap_with
            rec.state = 'approved'
