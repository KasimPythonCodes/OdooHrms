from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
from datetime import datetime, time



class HrShift(models.Model):
    _name = 'hr.shift'
    _description = 'HR Shift'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(required=True)
    employee_id = fields.Many2one('hr.employee', string="Assigned Employee", required=True)

    start_time = fields.Datetime("l")
    end_time = fields.Datetime("j")

    # Input Fields
    date = fields.Date(string="Shift Date", required=True)
    date_2 = fields.Date(string="Shift End Date", required=True)
    stat_time = fields.Float(string="Start Time", required=True, help="Enter time in HH.MM format (e.g., 9.5 for 9:30)")
    en_time = fields.Float(string="End Time", required=True, help="Enter time in HH.MM format (e.g., 5.0 for 5:00)")
    start_meridiem = fields.Selection([('AM', 'AM'), ('PM', 'PM')], string="Start AM/PM", required=True)
    end_meridiem = fields.Selection([('AM', 'AM'), ('PM', 'PM')], string="End AM/PM", required=True)

    # Computed 24-hour format
    start_time_24 = fields.Float(string="Start (24H)", compute="_compute_start_24", store=True)
    end_time_24 = fields.Float(string="End (24H)", compute="_compute_end_24", store=True)
    estimated_hours = fields.Float(string="Estimated Hours")
    task_completed = fields.Boolean(default=False)
    actual_hours = fields.Float(string="Actual Hours", compute="_compute_actual_hours", store=True)
    status = fields.Selection([('assigned', 'Assigned'), ('completed', 'Completed')], default='assigned')
    task_description = fields.Text("Task Description")
    task_progress = fields.Selection([
        ('not_started', 'Not Started'),
        ('in_progress', 'In Progress'),
        ('done', 'Done')
    ], default='not_started')


    @api.depends('start_time_24', 'end_time_24')
    def _compute_actual_hours(self):
        for rec in self:
            rec.actual_hours = rec.end_time_24 - rec.start_time_24

    state = fields.Selection([
        ('draft', 'Draft'),
        ('confirmed', 'Confirmed'),
        ('conflict', 'Conflict')
    ], default='draft', string="Status")

    @api.model
    def create(self, vals):
        employee_id = vals.get('employee_id')
        shift_start_date = vals.get('date')
        shift_end_date = vals.get('date_2')

        if employee_id and shift_start_date and shift_end_date:
            shift_start_date = fields.Date.to_date(shift_start_date)
            shift_end_date = fields.Date.to_date(shift_end_date)

            # Check if employee is on leave during any part of the shift
            leave_domain = [
                ('employee_id', '=', employee_id),
                ('state', '=', 'validate'),  # Only approved leaves
                ('request_date_from', '<=', shift_end_date),
                ('request_date_to', '>=', shift_start_date),
            ]
            overlapping_leaves = self.env['hr.leave'].search(leave_domain)

            if overlapping_leaves:
                leave_periods = ', '.join(
                    f"{l.request_date_from} to {l.request_date_to}" for l in overlapping_leaves
                )
                raise ValidationError(
                    f"Cannot assign shift on {shift_start_date} to {shift_end_date}.\n"
                    f"The employee is on leave during: {leave_periods}."
                )

        # Create shift
        res = super().create(vals)

        # Notify employee
        if res.employee_id and res.employee_id.user_id:
            res.activity_schedule(
                'mail.mail_activity_data_todo',
                user_id=res.employee_id.user_id.id,
                summary="New Shift Assigned",
                note=f"You have a new shift from {res.date} to {res.date_2}."
            )
            if res.employee_id.user_id.partner_id:
                res.employee_id.user_id.partner_id.sudo().message_post(
                    subject="New Shift Assigned",
                    body=f"Your shift from {res.date} to {res.date_2} has been scheduled.",
                    subtype_xmlid='mail.mt_comment'
                )

        # Notify manager
        if res.employee_id.parent_id and res.employee_id.parent_id.user_id:
            res.activity_schedule(
                'mail.mail_activity_data_todo',
                user_id=res.employee_id.parent_id.user_id.id,
                summary="Review Shift",
                note=f"Please review the shift assigned to your team member {res.employee_id.name}."
            )

        return res

    # Compute 24-hour start time
    @api.depends('stat_time', 'start_meridiem')
    def _compute_start_24(self):
        for rec in self:
            time = rec.stat_time
            if rec.start_meridiem == 'PM' and time < 12:
                time += 12
            elif rec.start_meridiem == 'AM' and time == 12:
                time = 0
            rec.start_time_24 = time

    # Compute 24-hour end time
    @api.depends('en_time', 'end_meridiem')
    def _compute_end_24(self):
        for rec in self:
            time = rec.en_time
            if rec.end_meridiem == 'PM' and time < 12:
                time += 12
            elif rec.end_meridiem == 'AM' and time == 12:
                time = 0
            rec.end_time_24 = time

    @api.constrains('employee_id', 'start_time_24', 'end_time_24', 'date')
    def _check_shift_conflict(self):
        for rec in self:
            if not rec.start_time_24 or not rec.end_time_24:
                continue

            if rec.start_time_24 >= rec.end_time_24:
                raise ValidationError("Start time must be earlier than end time.")

            # Use rec.date (Date field) for leave validation
            if rec.date:
                leave_domain = [
                    ('employee_id', '=', rec.employee_id.id),
                    ('state', '=', 'validate'),
                    ('request_date_from', '<=', rec.date),
                    ('request_date_to', '>=', rec.date),
                ]
                overlapping_leaves = self.env['hr.leave'].search(leave_domain)
                if overlapping_leaves:
                    leave_strs = ', '.join(
                        f"{l.request_date_from} to {l.request_date_to}" for l in overlapping_leaves
                    )
                    raise ValidationError(_(
                        "Cannot assign shift on %s.\n"
                        "Employee %s is on approved leave during: %s"
                    ) % (rec.date, rec.employee_id.name, leave_strs))

            # Conflict with other shifts
            conflicts = self.search([
                ('id', '!=', rec.id),
                ('employee_id', '=', rec.employee_id.id),
                ('date', '=', rec.date),  # Ensure same day
                ('start_time_24', '<', rec.end_time_24),
                ('end_time_24', '>', rec.start_time_24),
            ])

            if conflicts:
                rec.state = 'conflict'

                # Suggest replacement employees
                available_employees = self.env['hr.employee'].search([
                    ('id', '!=', rec.employee_id.id),
                    ('department_id', '=', rec.employee_id.department_id.id),
                    ('job_id', '=', rec.employee_id.job_id.id),
                    ('id', 'not in', self.env['hr.shift'].search([
                        ('date', '=', rec.date),
                        ('start_time_24', '<', rec.end_time_24),
                        ('end_time_24', '>', rec.start_time_24),
                    ]).mapped('employee_id.id')),
                ])

                if available_employees:
                    suggested_names = ", ".join(available_employees.mapped('name'))
                    raise ValidationError(_(
                        "Employee %s already has a conflicting shift!\n\n"
                        "Suggested replacements with same Job & Department: %s"
                    ) % (rec.employee_id.name, suggested_names))
                else:
                    raise ValidationError(_(
                        "Employee %s already has a conflicting shift!\n\n"
                        "No other employee available with the same Job & Department."
                    ) % rec.employee_id.name)

    # Suggest employees without time conflicts
    @api.model
    def suggest_alternatives(self, required_skills=None):
        employees = self.env['hr.employee'].search([])
        return employees.filtered(lambda e: not self._has_conflict(e))

    def _has_conflict(self, employee):
        return self.search_count([
            ('employee_id', '=', employee.id),
            ('start_time_24', '<', self.end_time_24),
            ('end_time_24', '>', self.start_time_24),
            ('id', '!=', self.id)
        ]) > 0

    @api.constrains('employee_id', 'date')
    def _check_leave(self):
        for rec in self:
            start_date = rec.date
            end_date = rec.date_2 or rec.date

            leave = self.env['hr.leave'].search([
                ('employee_id', '=', rec.employee_id.id),
                ('state', 'in', ['confirm', 'validate']),  # 'validate' is approved, 'confirm' is waiting
                ('request_date_from', '<=', end_date),
                ('request_date_to', '>=', start_date),
            ], limit=1)

            if leave:
                raise ValidationError(_(
                    "Cannot assign shift. %s is on leave between %s and %s."
                ) % (rec.employee_id.name, leave.request_date_from, leave.request_date_to))

    def action_confirm_shift(self):
        for rec in self:
            rec.state = 'confirmed'

    def action_mark_conflict(self):
        for rec in self:
            rec.state = 'conflict'