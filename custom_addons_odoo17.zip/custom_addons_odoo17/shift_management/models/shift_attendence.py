from odoo import models, fields, api
from odoo.exceptions import ValidationError
from datetime import date, datetime, time

class ShiftAttendanceReport(models.Model):
    _name = 'shift.attendance.report'
    _description = 'Shift Attendance Report'
    # _rec_name = 'name'

    # name = fields.Char(string="Name", default=lambda self: f"Attendance Report - {date.today()}", readonly=True)
    employee_id = fields.Many2one('hr.employee', string='Employee')
    start_date = fields.Date(string="Start Date", required=True)
    end_date = fields.Date(string="End Date", required=True)
    present_days_count = fields.Integer(string="Present Days", compute='_compute_present_days', store=False)

    # present_employee_ids = fields.Many2many('hr.employee','shift_attendance_present_rel', string="Present Employees", readonly=True)
    # absent_employee_ids = fields.Many2many('hr.employee','shift_attendance_absent_rel', string="Absent Employees", readonly=True)

    @api.depends('employee_id', 'start_date', 'end_date')
    def _compute_present_days(self):
        for rec in self:
            if rec.employee_id and rec.start_date and rec.end_date:
                attendance_records = self.env['hr.attendance'].search([
                    ('employee_id', '=', rec.employee_id.id),
                    ('check_in', '>=', rec.start_date),
                    ('check_in', '<=', rec.end_date)
                ])
                unique_dates = set(att.check_in.date() for att in attendance_records if att.check_in)
                rec.present_days_count = len(unique_dates)
            else:
                rec.present_days_count = 0

    # def action_compute_attendance_summary(self):
    #     for rec in self:
    #         today = fields.Date.today()
    #         start_datetime = datetime.combine(today, time.min)
    #         end_datetime = datetime.combine(today, time.max)
    #
    #         employees = self.env['hr.employee'].search([])
    #         present = []
    #         absent = []
    #
    #         for emp in employees:
    #             attendance_exists = self.env['hr.attendance'].search_count([
    #                 ('employee_id', '=', emp.id),
    #                 ('check_in', '>=', start_datetime),
    #                 ('check_in', '<=', end_datetime),
    #             ])
    #             if attendance_exists:
    #                 present.append(emp.id)
    #             else:
    #                 absent.append(emp.id)
    #
    #         rec.present_employee_ids = [(6, 0, present)]
    #         rec.absent_employee_ids = [(6, 0, absent)]

    @api.model
    def check_missing_attendance_and_notify(self):
        today = fields.Date.today()
        employees = self.env['hr.employee'].search([
            ('active', '=', True),
            ('company_id', '=', self.env.company.id)
        ])

        for emp in employees:
            attendance = self.env['hr.attendance'].search([
                ('employee_id', '=', emp.id),
                ('check_in', '>=', datetime.combine(today, time.min)),
                ('check_in', '<=', datetime.combine(today, time.max)),
            ], limit=1)

            if not attendance:
                manager = emp.parent_id
                if manager and manager.work_email:
                    template = self.env.ref('shift_management.mail_template_attendance_alert')
                    template.sudo().send_mail(emp.id, force_send=True)


class ShiftAttendanceDailySummary(models.Model):
    _name = 'shift.attendance.daily.summary'
    _description = 'Daily Attendance Summary'
    _rec_name = 'name'

    name = fields.Char(string="Report Name", default=lambda self: f"Daily Summary - {fields.Date.today()}", readonly=True)
    present_employee_ids = fields.Many2many('hr.employee', 'shift_attendance_daily_present_rel', string="Present Employees", readonly=True)
    absent_employee_ids = fields.Many2many('hr.employee', 'shift_attendance_daily_absent_rel', string="Absent Employees", readonly=True)

    def action_compute_today_summary(self):
        today = fields.Date.today()
        start_datetime = datetime.combine(today, time.min)
        end_datetime = datetime.combine(today, time.max)

        employees = self.env['hr.employee'].search([])
        present = []
        absent = []

        for emp in employees:
            attendance_exists = self.env['hr.attendance'].search_count([
                ('employee_id', '=', emp.id),
                ('check_in', '>=', start_datetime),
                ('check_in', '<=', end_datetime),
            ])
            if attendance_exists:
                present.append(emp.id)
            else:
                absent.append(emp.id)

        self.present_employee_ids = [(6, 0, present)]
        self.absent_employee_ids = [(6, 0, absent)]
