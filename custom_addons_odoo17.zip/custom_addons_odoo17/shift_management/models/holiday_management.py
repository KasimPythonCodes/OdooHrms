from odoo import models, fields, _
from odoo.exceptions import UserError


class ShiftHolidayManagement(models.Model):
    _name = 'shift.holiday.management'
    _description = 'Shift Holiday Management'

    name = fields.Char(string="Holiday Message")
    holiday_date = fields.Date(string="Holiday Date")
    leave_type = fields.Selection([
        ('casual', 'Casual Leave'),
        ('sick', 'Sick Leave'),
        ('earned', 'Earned Leave'),
    ], string="Leave Type", required=True)
    is_auto_applied = fields.Boolean(string="Auto Applied (from Calendar)", default=False)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('apply', 'Apply'),
        ('approved', 'Approved'),
        ('cancelled', 'Cancelled'),
    ], string="Status", default='draft', tracking=True)

    approved = fields.Boolean(string="Approved", default=False)
    manager_id = fields.Many2one('hr.employee', string='Manager')

    def action_apply(self):
        for rec in self:
            rec.state = 'apply'
            rec.approved = False

    def action_approve(self):
        for rec in self:
            if rec.state == 'approved':
                continue  # Skip already approved records

            # Find employee linked to the user who is approving
            employee = self.env['hr.employee'].search([('user_id', '=', self.env.user.id)], limit=1)
            if not employee:
                raise UserError("No employee record linked to the current user.")

            # Deduct 1 leave based on leave type
            if rec.leave_type == 'casual':
                if employee.casual_leaves <= 0:
                    raise UserError("You don't have enough casual leaves.")
                employee.casual_leaves -= 1

            elif rec.leave_type == 'sick':
                if employee.sick_leaves <= 0:
                    raise UserError("You don't have enough sick leaves.")
                employee.sick_leaves -= 1

            elif rec.leave_type == 'earned':
                if employee.earned_leaves <= 0:
                    raise UserError("You don't have enough earned leaves.")
                employee.earned_leaves -= 1

            # Mark approved
            rec.state = 'approved'
            rec.approved = True

    def action_cancel(self):
        for rec in self:
            rec.state = 'cancelled'
            rec.approved = False

    def action_send_holiday_email(self):
        for rec in self:
            # Get the current employee (linked to logged-in user)
            employee = self.env['hr.employee'].search([('user_id', '=', self.env.user.id)], limit=1)
            if not employee:
                raise UserError("No employee record linked to the current user.")

            # Use parent_id as the manager, and get their user-linked email
            manager = employee.parent_id
            if not manager or not manager.user_id or not manager.user_id.partner_id or not manager.user_id.partner_id.email:
                raise UserError("Your manager or their email is not defined.")

            recipient_email = manager.user_id.partner_id.email

            subject = f"Holiday Notification - {rec.holiday_date.strftime('%Y-%m-%d')}"
            body = f"""
                <p>Dear {manager.name},</p>
                <p>This is to inform you about a holiday on <strong>{rec.holiday_date.strftime('%A, %d %B %Y')}</strong>.</p>
                <p><strong>Leave Type:</strong> {dict(rec._fields['leave_type'].selection).get(rec.leave_type)}</p>
                <p><strong>Message:</strong> {rec.name}</p>
                <p>Regards,<br/>{self.env.user.name}</p>
            """

            mail_values = {
                'subject': subject,
                'body_html': body,
                'email_to': recipient_email,
                'author_id': self.env.user.partner_id.id,
            }
            self.env['mail.mail'].create(mail_values).send()


class HrEmployee(models.Model):
    _inherit = 'hr.employee'

    casual_leaves = fields.Integer(string="Casual Leaves")
    sick_leaves = fields.Integer(string="Sick Leaves")
    earned_leaves = fields.Integer(string="Earned Leaves")