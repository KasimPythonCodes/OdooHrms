from datetime import datetime, time
from odoo import models, fields, api
from odoo.exceptions import UserError


class BulkAttendanceMark(models.TransientModel):
    _name = 'bulk.attendance.mark'
    _description = 'Bulk Attendance Marking Wizard'

    date_ids = fields.Many2many('bulk.attendance.date', string="Dates to Mark")

    def action_mark_attendance(self):
        employees = self.env['hr.employee'].search([])
        attendance_obj = self.env['hr.attendance']

        for date_obj in self.date_ids:
            check_in = datetime.combine(date_obj.name, time(10, 0))  # 10:00 AM
            check_out = datetime.combine(date_obj.name, time(19, 0))  # 07:00 PM

            for emp in employees:
                already_marked = attendance_obj.search([
                    ('employee_id', '=', emp.id),
                    ('check_in', '>=', check_in),
                    ('check_out', '<=', check_out)
                ])
                if not already_marked:
                    attendance_obj.create({
                        'employee_id': emp.id,
                        'check_in': check_in,
                        'check_out': check_out,
                    })

    # def action_mark_attendance(self):
    #     employees = self.env['hr.employee'].search([])
    #     attendance_obj = self.env['hr.attendance']
    #
    #     for date_obj in self.date_ids:
    #         check_in = datetime.combine(date_obj.name, time.min)
    #         check_out = datetime.combine(date_obj.name, time.max)
    #
    #         for emp in employees:
    #             already_marked = attendance_obj.search([
    #                 ('employee_id', '=', emp.id),
    #                 ('check_in', '>=', check_in),
    #                 ('check_out', '<=', check_out)
    #             ])
    #             if not already_marked:
    #                 attendance_obj.create({
    #                     'employee_id': emp.id,
    #                     'check_in': check_in,
    #                     'check_out': check_in.replace(hour=17, minute=0),  # Example: 5 PM checkout
    #                 })



class BulkAttendanceDate(models.Model):
    _name = 'bulk.attendance.date'
    _description = 'Dates for Bulk Attendance'

    name = fields.Date(string="Date", required=True, unique=True)
