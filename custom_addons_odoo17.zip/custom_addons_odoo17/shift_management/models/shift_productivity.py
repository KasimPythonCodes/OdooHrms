from odoo import models, fields, api

class ShiftProductivity(models.Model):
    _name = 'shift.productivity'
    _description = 'Employee Productivity Metrics'
    _auto = False

    employee_id = fields.Many2one('hr.employee', string="Employee")

    @api.model
    def _search_employee_data(self):
        employee = self.env.user.employee_id
        return self.search([('employee_id', '=', employee.id)])
