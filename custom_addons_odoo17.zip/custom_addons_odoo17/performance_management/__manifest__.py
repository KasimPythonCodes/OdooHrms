{
    'name': "Performance Management",
    'version': '1.0',
    'summary': "Employee Goal Setting & KPI Monitoring",
    'description': "Manage and track employee goals and performance expectations.",
    'author': "Tech Rajendra",
    'category': 'Human Resources',
    'depends': ['hr'],   # depends on hr module for employees
    'data': [
        'security/ir.model.access.csv',
        'views/kpi_goal_views.xml',
        'views/od_appraisal_feedback_views.xml',
        'views/pip_views.xml',
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}
