from odoo import models, fields, api
from odoo.exceptions import UserError


class KpiGoal(models.Model):
    _name = "kpi.goal"
    _description = "KPI Goal"
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string="Goal Name", required=True, tracking=True)
    description = fields.Text(string="Description")

    employee_id = fields.Many2one(
        "hr.employee",
        string="Employee",
        required=True,
        tracking=True
    )
    department_id = fields.Many2one(
        "hr.department",
        string="Department",
        related="employee_id.department_id",
        store=True
    )
    manager_id = fields.Many2one(
        "hr.employee",
        string="Manager",
        related="employee_id.parent_id",
        store=True
    )

    start_date = fields.Date(string="Start Date", required=True)
    end_date = fields.Date(string="End Date", required=True)
    performance_percentage = fields.Float(
        string="Performance %",
        help="Employee performance percentage",
        digits=(5, 2)  # up to 100.00%
    )
    pip_reason = fields.Text(
        string="PIP Reason",
        help="Reason for placing the employee under Performance Improvement Plan"
    )
    pip_id = fields.Many2one(
        'performance.pip',
        string="Performance Improvement Plan",
        readonly=True,
    )

    state = fields.Selection([
        ('draft', 'Draft'),
        ('in_progress', 'In Progress'),
        ('achieved', 'Achieved'),
        ('cancelled', 'Cancelled')
    ], string="Status", default="draft", readonly=False)

    company_id = fields.Many2one(
        'res.company',
        string="Company",
        default=lambda self: self.env.company,
        required=True
    )

    def write(self, vals):
        if 'state' in vals:
            for record in self:
                old_state = record.state
                new_state = vals['state']

                allowed_transitions = {
                    'draft': ['in_progress', 'cancelled'],
                    'in_progress': ['achieved', 'cancelled'],
                    'achieved': ['cancelled'],   # can only move to cancelled
                    'cancelled': ['draft'],      # can be reset to draft
                }

                if new_state not in allowed_transitions.get(old_state, []):
                    raise UserError(
                        f"You cannot move directly from '{old_state}' to '{new_state}'."
                    )

        return super().write(vals)

    # --- State Change` Actions ---
    def action_reset_draft(self):
        self.write({'state': 'draft'})
    #
    def action_set_in_progress(self):
        self.write({'state': 'in_progress'})
    #
    def action_set_achieved(self):
        self.write({'state': 'achieved'})
    #
    def action_set_cancelled(self):
        self.write({'state': 'cancelled'})

    def action_create_pip(self):
        for record in self:
            if not record.pip_reason:
                raise UserError("Please provide a PIP Reason before creating a PIP.")

            pip = self.env['performance.pip'].create({
                'employee_id': record.employee_id.id,
                'pip_reason': record.pip_reason,
                'start_date': record.start_date,
                'end_date': record.end_date,
            })
            record.pip_id = pip.id

            return {
                'type': 'ir.actions.act_window',
                'res_model': 'performance.pip',
                'view_mode': 'form',
                'res_id': pip.id,
                'target': 'current',
            }

    def action_send_pip_mail(self):
        for record in self:
            if not record.employee_id.work_email:
                raise UserError("Employee does not have a work email set.")
            if not record.pip_reason:
                raise UserError("Please add a PIP Reason before sending the mail.")

            subject = f"PIP Notice for {record.employee_id.name}"
            body = f"""
Dear {record.employee_id.name},

You have been placed under a Performance Improvement Plan (PIP).

Reason:
{record.pip_reason}

Regards,  
HR Department
"""

            # Create mail
            mail_values = {
                'subject': subject,
                'body_html': f"<pre>{body}</pre>",
                'email_to': record.employee_id.work_email,
                'email_from': self.env.user.email_formatted,
            }
            mail = self.env['mail.mail'].create(mail_values)
            mail.send()

        return True

    def action_calculate_performance(self):
        pass
