from odoo import models, fields

class PerformancePIP(models.Model):
    _name = 'performance.pip'
    _description = 'Performance Improvement Plan'

    employee_id = fields.Many2one(
        'hr.employee',
        string="Employee",
        required=True
    )
    pip_reason = fields.Text(
        string="PIP Reason",
        required=True
    )
    start_date = fields.Date(
        string="Start Date",
        required=True
    )
    end_date = fields.Date(
        string="End Date",
        required=True
    )
