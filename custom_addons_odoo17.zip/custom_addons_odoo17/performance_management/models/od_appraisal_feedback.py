from odoo import models, fields, api
from odoo.exceptions import UserError


class AppraisalFeedback(models.Model):
    _name = 'od.appraisal.feedback'
    _description = 'Appraisal Feedback'

    employee_id = fields.Many2one('hr.employee', string="Feedback From")
    manager_id = fields.Many2one('hr.employee', string="Feedback To")
    feedback_text = fields.Char(string="Feedback", required=True)
    rating = fields.Selection(
        [('1', '⭐'), ('2', '⭐⭐'), ('3', '⭐⭐⭐'), ('4', '⭐⭐⭐⭐'), ('5', '⭐⭐⭐⭐⭐')],
        string="Rating"
    )
    company_id = fields.Many2one(
        'res.company',
        string="Company",
        default=lambda self: self.env.company,
        required=True
    )

    def action_send_feedback_reminder(self):
        employees = self.env['hr.employee'].search([
            ('company_id', '=', self.env.company.id),
            ('work_email', '!=', False)
        ])

        if not employees:
            raise UserError("No employees with email found in current company.")

        for emp in employees:
            mail_values = {
                'subject': "Reminder: Please Provide Feedback",
                'body_html': f"""
                    <p>Hello {emp.name},</p>
                    <p>This is a kind reminder to provide your feedback for the appraisal process.</p>
                    <p>Thank you,<br/>{self.env.user.name}</p>
                """,
                'email_from': self.env.user.email or 'noreply@example.com',
                'email_to': emp.work_email,
            }
            mail = self.env['mail.mail'].create(mail_values)
            mail.send()

        return True










