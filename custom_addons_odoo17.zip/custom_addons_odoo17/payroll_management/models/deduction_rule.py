from odoo import models, fields, api
from odoo.exceptions import UserError


class DeductionRule(models.Model):
    _name = 'deduction.rule'
    _description = 'Deduction Rule Configuration'

    name = fields.Char(string="Reference", default="New", readonly=True)
    employee_id = fields.Many2one('hr.employee', string="Employee", required=True)
    loan_amount = fields.Float(string="Loan Amount", required=True)
    penalty_amount = fields.Float(string="Penalty Amount", required=True)
    total_deduction = fields.Float(string="Total Deduction", compute="_compute_total_deduction", store=True)
    company_id = fields.Many2one(
        'res.company',
        string="Company",
        required=True,
        default=lambda self: self.env.company.id
    )

    @api.depends('loan_amount', 'penalty_amount')
    def _compute_total_deduction(self):
        for rec in self:
            rec.total_deduction = rec.loan_amount + rec.penalty_amount

    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            vals['name'] = self.env['ir.sequence'].next_by_code('deduction.rule') or 'New'
        return super().create(vals)

    def action_transfer_deduction(self):
        for rec in self:
            salary_structure = self.env['hr.salary.calculation.custom'].search([
                ('employee_id', '=', rec.employee_id.id)
            ], limit=1)
            if salary_structure:
                salary_structure.loan_penalty = rec.total_deduction
