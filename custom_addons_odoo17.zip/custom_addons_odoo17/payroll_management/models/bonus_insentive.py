from odoo import models, fields, api

class BonusInsentive(models.Model):
    _name = 'bonus.insentive'
    _description = 'Bonus and Insentive'

    name = fields.Char(string="Name", required=True)
    grade_id = fields.Many2one('grade.master', string="Grade", required=True)
    bonus_percentage = fields.Float(string="Bonus %", help="Percentage of salary to be given as bonus")
    bonus_amount = fields.Float(string="Bonus Amount", readonly=True)
    company_id = fields.Many2one(
        'res.company',
        string="Company",
        required=True,
        default=lambda self: self.env.company.id
    )

    def _calculate_bonus_amount_from_vals(self, vals):
        bonus_amount = 0.0
        grade_id = vals.get('grade_id') or (self.grade_id.id if self else False)
        bonus_percentage = vals.get('bonus_percentage') or (self.bonus_percentage if self else 0.0)

        if grade_id and bonus_percentage:
            structure = self.env['hr.salary.structure.custom'].search([
                ('grade_id', '=', grade_id)
            ], limit=1)
            if structure and structure.total_salary:
                bonus_amount = (bonus_percentage / 100.0) * structure.total_salary
        return bonus_amount

    @api.model
    def create(self, vals):
        vals['bonus_amount'] = self._calculate_bonus_amount_from_vals(vals)
        return super().create(vals)

    def write(self, vals):
        vals['bonus_amount'] = self._calculate_bonus_amount_from_vals(vals)
        return super().write(vals)

    @api.onchange('bonus_percentage', 'grade_id')
    def _compute_bonus_amount(self):
        for record in self:
            record.bonus_amount = self._calculate_bonus_amount_from_vals({})

    def apply_bonus_to_salary(self):
        salary_model = self.env['hr.salary.calculation.custom']
        employees = self.env['hr.employee'].search([('grade_id', '=', self.grade_id.id)])
        salary_records = salary_model.search([('employee_id', 'in', employees.ids)])
        for record in salary_records:
            record.bonus_salary = self.bonus_amount
