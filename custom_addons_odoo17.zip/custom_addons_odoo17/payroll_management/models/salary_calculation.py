from odoo import models, fields, api
from datetime import datetime, timedelta
import calendar


class SalaryCalculation(models.Model):
    _name = 'hr.salary.calculation.custom'
    _description = 'Salary Calculation'

    name = fields.Char(string="Reference", default=lambda self: 'New')

    employee_id = fields.Many2one('hr.employee', string="Employee", required=True)

    salary_structure_id = fields.Many2one(
        'hr.salary.structure.custom',
        string="Salary Structure",
    )

    company_id = fields.Many2one(
        'res.company',
        string="Company",
        required=True,
        default=lambda self: self.env.company.id
    )

    # Month is stored as "1".."12"; label is "January".."December"
    month = fields.Selection(
        [(str(m), datetime(2000, m, 1).strftime('%B')) for m in range(1, 13)],
        string="Month",
        required=True,
        default=lambda self: str(datetime.today().month)
    )

    year = fields.Integer(
        string="Year",
        required=True,
        default=lambda self: datetime.today().year
    )

    allowances_salary = fields.Float(string="Additional Allowances")
    deductions_salary = fields.Float(string="Additional Deductions")
    bonus_salary = fields.Float(string="Bonus")
    loan_penalty = fields.Float(string="Loan & Penalty")

    present_days = fields.Integer(
        string="Present Days",
        compute='_compute_present_days',
        store=True
    )
    # attandance_count = fields.Integer(string="Present Days",store=True)
    # overtime_count = fields.Integer(string="Overtime Days",store=True)
    overtime_hours = fields.Float(
        string="Overtime Hours",
        compute='_compute_overtime',
        store=True,
    )
    calculated_salary = fields.Float(string="Calculated Salary")


    @api.model
    def create(self, vals):
        """Server-side defaults for API/back-end creates."""
        emp_id = vals.get('employee_id')
        month = vals.get('month')
        year = vals.get('year')

        # Compute attendance before record exists
        if emp_id and month and year:
            vals['present_days'] = self._get_present_days(emp_id, month, year)
            # vals['attandance_count'] = vals['present_days']
            vals['overtime_hours'] = self._get_overtime_hours(emp_id, month, year)
            # vals['overtime_count'] = vals['overtime_hours']

        vals = self._compute_and_update_vals(vals)
        return super().create(vals)

    def write(self, vals):
        """Update allowances/deductions if employee changes."""
        if self.employee_id:
            emp_id = self.employee_id.id
            month = vals.get('month') or self.month
            year = vals.get('year') or self.year

            # Compute attendance before record exists
            if emp_id and month and year:
                vals['present_days'] = self._get_present_days(emp_id, month, year)
                # vals['attandance_count'] = vals['present_days']
                vals['overtime_hours'] = self._get_overtime_hours(emp_id, month, year)
                # vals['overtime_count'] = vals['overtime_hours']

        vals = self._compute_and_update_vals(vals)
        return super().write(vals)

    @api.onchange('employee_id','month', 'year')
    def _compute_present_days(self):
        for record in self:
            record._get_present_days(
                record.employee_id.id,
                record.month,
                record.year)

    @api.onchange('employee_id', 'month', 'year')
    def _compute_overtime(self):
        for record in self:
            record.present_days = record._get_overtime_hours(
                record.employee_id.id,
                record.month,
                record.year
            )

    def _get_present_days(self, emp_id, month, year):
        try:
            month_int = int(month)
        except Exception:
            return 0
        month_start = datetime(int(year), month_int, 1)
        next_month = datetime(int(year) + 1, 1, 1) if month_int == 12 else datetime(int(year), month_int + 1, 1)
        month_end = next_month - timedelta(days=1)

        attendances = self.env['hr.attendance'].search([
            ('employee_id', '=', emp_id),
            ('check_in', '>=', month_start),
            ('check_in', '<=', month_end)
        ])
        return len({att.check_in.date() for att in attendances if att.check_in})

    def _get_overtime_hours(self, emp_id, month, year):
        try:
            month_int = int(month)
        except Exception:
            return 0.0
        month_start = datetime(int(year), month_int, 1)
        next_month = datetime(int(year) + 1, 1, 1) if month_int == 12 else datetime(int(year), month_int + 1, 1)
        month_end = next_month - timedelta(days=1)

        attendances = self.env['hr.attendance'].search([
            ('employee_id', '=', emp_id),
            ('check_in', '>=', month_start),
            ('check_in', '<=', month_end)
        ])
        total_ot_hours = 0.0
        for att in attendances:
            if att.check_in and att.check_out:
                worked_hours = (att.check_out - att.check_in).total_seconds() / 3600.0
                if worked_hours > 9.0:
                    total_ot_hours += worked_hours - 9.0
        return total_ot_hours

    def _compute_and_update_vals(self, vals):
        """
        Final salary:
            If month/year selected:
                base = per_day * present_days + per_hour * overtime
            else:
                base = structure.total_salary
            calculated = base + allowances + bonus - deductions - loan_penalty
        """
        # Determine employee and structure
        employee = None
        structure = None

        if 'employee_id' in vals:
            employee = self.env['hr.employee'].browse(vals['employee_id'])
        elif self.employee_id:
            employee = self.employee_id

        # If salary_structure_id is changing or exists
        if 'salary_structure_id' in vals:
            structure = self.env['hr.salary.structure.custom'].browse(vals['salary_structure_id'])
        elif self.salary_structure_id:
            structure = self.salary_structure_id

        fixed_salary = structure.total_salary if structure else 0.0
        base_salary = fixed_salary

        # Month/year logic
        month = vals.get('month', self.month)
        year = vals.get('year', self.year)

        if month and year and fixed_salary:
            try:
                month_int = int(month)
            except Exception:
                month_int = 0

            if month_int:
                days_in_month = calendar.monthrange(int(year), month_int)[1]
                per_day_salary = (fixed_salary / days_in_month) if days_in_month > 0 else 0.0
                per_hour_salary = per_day_salary / 9.0

                present = vals.get('present_days', self.present_days or 0.0)
                ot_hours = vals.get('overtime_hours', self.overtime_hours or 0.0)
                base_salary = (per_day_salary * present) + (per_hour_salary * ot_hours)

        # Final calculation
        vals['calculated_salary'] = (
                (base_salary or 0.0)
                + (vals.get('allowances_salary', self.allowances_salary) or 0.0)
                + (vals.get('bonus_salary', self.bonus_salary) or 0.0)
                - (vals.get('deductions_salary', self.deductions_salary) or 0.0)
                - (vals.get('loan_penalty', self.loan_penalty) or 0.0)
        )

        return vals

    def compute_all_salary_data(self):
        """
        Batch recompute for last month:
        - Uses month stored as '1'..'12' (not month names).
        - Recomputes stored calculated_salary via standard compute chain.
        """
        today = datetime.today()
        last_month_int = today.month - 1 or 12
        year = today.year if today.month != 1 else today.year - 1

        # Our 'month' field stores '1'..'12'
        records = self.search([
            ('month', '=', str(last_month_int)),
            ('year', '=', year),
        ])

        # Accessing calculated_salary will trigger compute (and write stored value)
        for rec in records:
            vals = {}
            vals['employee_id'] = rec.employee_id.id
            vals['month'] = rec.month
            vals['year'] = rec.year
            rec.write(vals)


    def print_salary_slip_pdf(self):
        return self.env.ref('payroll_management.action_report_salary_slip').report_action(self)


class Employee(models.Model):
    _inherit = 'hr.employee'

    hra_allowance = fields.Float(string="HRA Allowance", default=0.0)
    transport_allowance = fields.Float(string="Transport Allowance", default=0.0)
    medical_allowance = fields.Float(string="Medical Allowance", default=0.0)
    meal_allowance = fields.Float(string="Meal Allowance", default=0.0)
    special_allowance = fields.Float(string="Special Allowance", default=0.0)

    professional_tax = fields.Float(string="Professional Tax", default=0.0)
    provident_fund = fields.Float(string="Provident Fund", default=0.0)
    income_tax = fields.Float(string="Income Tax (TDS)", default=0.0)
    loan_recovery = fields.Float(string="Loan Recovery", default=0.0)
    late_penalty = fields.Float(string="Late Penalty / Absence Deduction", default=0.0)

    total_allowances = fields.Float(string="Total Allowances", compute="_compute_total_allowances", store=True)
    total_deductions = fields.Float(string="Total Deductions", compute="_compute_total_deductions", store=True)

    @api.depends('hra_allowance', 'transport_allowance', 'medical_allowance', 'meal_allowance', 'special_allowance')
    def _compute_total_allowances(self):
        """Calculate total allowances."""
        for rec in self:
            rec.total_allowances = (
                    rec.hra_allowance +
                    rec.transport_allowance +
                    rec.medical_allowance +
                    rec.meal_allowance +
                    rec.special_allowance
            )

    @api.depends('professional_tax', 'provident_fund', 'income_tax', 'loan_recovery', 'late_penalty')
    def _compute_total_deductions(self):
        """Calculate total deductions."""
        for rec in self:
            rec.total_deductions = (
                    rec.professional_tax +
                    rec.provident_fund +
                    rec.income_tax +
                    rec.loan_recovery +
                    rec.late_penalty
            )

    def create(self, vals):
        # Create the employee first
        employee = super(Employee, self).create(vals)

        # Automatically create Salary Calculation entry
        if employee:
            # Find Salary Structure for the employee's grade
            structure_id = False
            if employee.grade_id:
                structure = self.env['hr.salary.structure.custom'].search(
                    [('grade_id', '=', employee.grade_id.id)],
                    limit=1
                )
                if structure:
                    structure_id = structure.id

            self.env['hr.salary.calculation.custom'].create({
                'employee_id': employee.id,
                'salary_structure_id': structure_id,
                'month': str(datetime.today().month),
                'year': datetime.today().year,
                'allowances_salary': employee.total_allowances or 0.0,
                'deductions_salary': employee.total_deductions or 0.0,
            })

        return employee