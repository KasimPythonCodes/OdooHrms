from odoo import models, fields, api


class SalaryStructure(models.Model):
    _name = 'hr.salary.structure.custom'
    _description = 'Salary Structure'

    name = fields.Char(string="Structure Name")
    grade_id = fields.Many2one('grade.master', string="Structure Name")
    employee_category = fields.Selection([
        ('manager', 'Manager'),
        ('engineer', 'Engineer'),
        ('staff', 'Staff'),
        ('other', 'Other'),
    ], string="Employee Category", required=True)

    basic = fields.Float(string="Basic Salary", required=True)
    hra = fields.Float(string="House Rent Allowance (HRA)", required=True)
    # allowances = fields.Float(string="Allowances", required=True)
    # deductions = fields.Float(string="Deductions", required=True)
    total_salary = fields.Float(string="Total Salary", compute="_compute_total", store=True)
    company_id = fields.Many2one(
        'res.company',
        string="Company",
        required=True,
        default=lambda self: self.env.company.id
    )

    @api.model
    def create(self, vals):
        if 'grade_id' in vals:
            grade = self.env['grade.master'].browse(vals['grade_id'])
            vals['name'] = grade.grade_name
        return super().create(vals)

    @api.depends('basic', 'hra')
    def _compute_total(self):
        for record in self:
            record.total_salary = (record.basic or 0.0) + (record.hra or 0.0)

