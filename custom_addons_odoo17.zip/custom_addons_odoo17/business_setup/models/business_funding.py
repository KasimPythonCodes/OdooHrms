from odoo import models, fields

class BusinessFunding(models.Model):
    _name = 'business.funding'
    _description = 'Business Funding'

    source = fields.Selection([
        ('vc', 'Venture Capital'),
        ('grant', 'Grant'),
        ('bootstrapped', 'Bootstrapped'),
        ('angel', 'Angel Investor'),
    ], string="Source")
    amount = fields.Float(string="Amount")
    received_date = fields.Date(string="Date Received")
    setup_id = fields.Many2one('business.setup', string="Business Setup")
