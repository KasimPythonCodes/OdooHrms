from odoo import models, fields

class FinancialSystem(models.Model):
    _name = 'business.financial.system'
    _description = 'Financial System'

    name = fields.Selection(
        selection=[
            ('quickbooks', 'QuickBooks'),
            ('tally', 'Tally'),
            ('zoho', 'Zoho'),
        ],
        string="Financial System",
        required=True
    )
    setup_id = fields.Many2one('business.setup', string="Business Setup")

