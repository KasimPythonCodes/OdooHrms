from odoo import models, fields, api
from odoo.exceptions import ValidationError


class BusinessSetup(models.Model):
    _name = 'business.setup'
    _description = 'Business Setup Information'

    company_id = fields.Many2one('res.company',string="Company Name", required=True)
    business_idea = fields.Text(string="Business Idea", required=True)

    business_plan = fields.Html(string="Business Plan")
    business_plan_file = fields.Binary(string="Business Plan File")
    business_plan_filename = fields.Char(string="Filename")

    business_structure = fields.Selection([
        ('sole', 'Sole Proprietorship'),
        ('llp', 'LLP'),
        ('pvt_ltd', 'Private Limited'),
        ('public_ltd', 'Public Limited'),
        ('other', 'Other')
    ], string="Business Structure", required=True)

    business_registration_ids = fields.One2many('business.registration', 'setup_id', string="Business Registration")
    funding_ids = fields.One2many('business.funding', 'setup_id', string="Funding Information")

    financial_system_ids = fields.One2many(
        'business.financial.system',
        'setup_id',
        string="Financial Systems"
    )
    hiring_employees = fields.Boolean(string="Hiring Employees?", required=True)
    hiring_date = fields.Date(string="Expected Hiring Date")
    hiring_notes = fields.Text(string="Hiring Notes")

    operations_setup_ids = fields.One2many('business.operation.setup', 'setup_id', string="Operations Setup")
    marketing_branding_ids = fields.One2many('business.marketing.branding', 'setup_id', string="Marketing & Branding")
    milestone_ids = fields.One2many('growth.milestone', 'setup_id', string="Milestone Growth")

    launch_timeline = fields.Date(string="Launch Timeline")

    launch_owner = fields.Many2one('res.users', string="Launch Owner")
    gtm_channels = fields.Text(string="GTM Channels")
    budget = fields.Float(string="Total Budget")


    @api.constrains('business_plan_file')
    def _check_file_size(self):
        for rec in self:
            if rec.business_plan_file and len(rec.business_plan_file) > 10 * 1024 * 1024:
                raise ValidationError("Business Plan file must not exceed 10MB.")

class GrothMilestone(models.Model):
    _name = 'growth.milestone'
    _description = 'Growth Milestone'

    growth_milestones = fields.Text(string="Milestones Name")
    growth_timeline_from = fields.Date(string="Milestone Start")
    growth_timeline_to = fields.Date(string="Milestone End")
    descriptions = fields.Text(string="Milestone Description")
    setup_id = fields.Many2one('business.setup', string="Business Setup")


class BusinessRegistration(models.Model):
    _name = 'business.registration'
    _description = 'Business Registration'

    reg_no = fields.Char(string="Registration Number")
    reg_date = fields.Date(string="Registration Date")
    issuing_authority = fields.Char(string="Issuing Authority")
    setup_id = fields.Many2one('business.setup', string="Business Setup")

class OperationSetup(models.Model):
    _name = 'business.operation.setup'
    _description = 'Operations Setup'

    setup_id = fields.Many2one('business.setup', string="Business Setup")

    software_ids = fields.Many2one('business.software', string="Softwares")
    hardware_ids = fields.Many2one('business.hardware', string="Hardwares")
    work_model = fields.Selection([
        ('full_time', 'Full Time On-site'),
        ('hybrid', 'Hybrid'),
        ('remote', 'Remote')
    ], string="Work Model", required=True)
    operation_readiness = fields.Float(string="Operation Readiness (%)", digits=(5, 2))
    operation_owner = fields.Many2one('res.users', string="Operation Owner")



class MarketingBranding(models.Model):
    _name = 'business.marketing.branding'
    _description = 'Marketing & Branding'

    activity = fields.Char(string="Activity")
    channel = fields.Char(string="Channel")
    budget = fields.Float(string="Estimated Budget")
    setup_id = fields.Many2one('business.setup', string="Business Setup")

    source = fields.Char(string="Source")
    timeline_from = fields.Date(string="Timeline From")
    timeline_to = fields.Date(string="Timeline To")
    partners = fields.Many2one('res.users', string="Partners")
    documents = fields.Binary(string="Documents")
    documents_filename = fields.Char(string="Document Filename")
    marketing_owner = fields.Many2one('res.users', string="Marketing Owner")


class BusinessSoftware(models.Model):
    _name = 'business.software'
    _description = 'Software Used in Business'

    name = fields.Char(string="Software Name", required=True)
    expiration_date = fields.Date(string="Expiration Date", required=True)



class BusinessHardware(models.Model):
    _name = 'business.hardware'
    _description = 'Hardware Used in Business'

    name = fields.Char(string="Hardware Name", required=True)
    hardware_type = fields.Char(string="Hardware Type")