{
    'name': 'Business Setup',
    'version': '1.0',
    'summary': 'Business Setup Master with Company Type, Industry Type, and Compliance Status',
    'category': 'Human Resources',
    'author': 'Your Company Name',
    'depends': ['base'],
    'data': [
        'security/ir.model.access.csv',
        'views/business_setup_views.xml',
        'views/software_hardware.xml',
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}
