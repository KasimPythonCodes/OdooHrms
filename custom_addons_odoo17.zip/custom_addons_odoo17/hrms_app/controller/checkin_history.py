from odoo import http

from odoo.http import request
import json
import pytz


class ActivityAPI(http.Controller):

    @http.route('/api/geofencing/activity', type='http', auth='public', methods=['GET'], csrf=False, cors='*')
    def get_activity_data(self, id):
        if not id:
            return request.make_response(
                json.dumps({'status': 'Failure', 'message': 'Employee ID required'}),
                headers={'Content-Type': 'application/json'}
            )

        # Use the timezone of user with ID 2 (adjust as needed)
        user_tz = pytz.timezone(request.env['res.users'].sudo().browse(2).tz)

        employee_records = request.env['employee.attendance'].sudo().search([
            ('employee_id', '=', int(id))
        ])

        data = []
        for record in employee_records:
            # Convert check_in from UTC to local time if present
            if record.check_in:
                utc_checkin = record.check_in
                # Localize if the datetime is naive (stored in UTC without tzinfo)
                if utc_checkin.tzinfo is None:
                    utc_checkin = pytz.utc.localize(utc_checkin)
                local_checkin = utc_checkin.astimezone(user_tz)
                checkin_str = local_checkin.strftime('%Y-%m-%d %H:%M:%S')
            else:
                checkin_str = ""

            # Convert check_out from UTC to local time if present
            if record.check_out:
                utc_checkout = record.check_out
                if utc_checkout.tzinfo is None:
                    utc_checkout = pytz.utc.localize(utc_checkout)
                local_checkout = utc_checkout.astimezone(user_tz)
                checkout_str = local_checkout.strftime('%Y-%m-%d %H:%M:%S')
            else:
                checkout_str = ""

            date_str = record.date.strftime('%Y-%m-%d') if record.date else ""

            data.append({
                'checkin': checkin_str,
                'checkout': checkout_str,
                'date': date_str
            })

        return request.make_response(
            json.dumps({'status': 'Success', 'data': data}),
            headers={'Content-Type': 'application/json'}
        )



