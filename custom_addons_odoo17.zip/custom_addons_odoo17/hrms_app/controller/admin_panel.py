import json
import base64
from odoo import http
from odoo.http import request, Response

class AdminPanelAPI(http.Controller):

    @http.route('/api/admin_panel/posts', type='http', auth='public', methods=['GET'], csrf=False, cors='*')
    def get_admin_posts(self, **kwargs):
        """Fetches all posts from the admin panel along with their associated images (Base64)."""
        posts = request.env['admin.panel'].sudo().search([])

        data = []
        for post in posts:
            # Fetch the attachment related to this record
            attachment = request.env['ir.attachment'].sudo().search([('description','=',post.id),('res_model','=','admin.panel')], limit=1)

            data.append({
                'id': post.id,
                'userName': post.user_name,
                'eventTitle': post.event_title,
                'eventDescription': post.event_description,
                'eventTime': post.event_time.strftime('%Y-%m-%d %H:%M:%S') if post.event_time else None,
                'profileImage':attachment.url # Returns Base64-encoded image
            })

        return Response(json.dumps({'status': 200, 'message': 'Success', 'data': data}),
                        content_type='application/json', status=200)

    @http.route('/api/v1/version/control', type='http', auth='public', methods=['GET'], csrf=False, cors='*')
    def get_version_control(self, **kwargs):
        """Fetches version-specific details."""
        value = request.env['ir.config_parameter'].sudo().get_param('version_control')


        # Mock data for demonstration
        data = {
            "version": value,
            "changes": [
                "Initial version of the API.",
                "Added feature to fetch version details."
            ]
        }

        return Response(json.dumps({'status': 200, 'message': 'Success', 'data': data}),
                        content_type='application/json', status=200)
