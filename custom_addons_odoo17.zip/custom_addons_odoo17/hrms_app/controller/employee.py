from odoo import http
from odoo.http import request
import json
from collections import defaultdict
from datetime import datetime


class EmployeeInfo(http.Controller):
    @http.route('/api/geofencing/employee', type='http', auth='none', methods=['GET'], csrf=False, cors='*')
    def get_employee_info(self, **kw):
        employee_id = kw.get('id', False)
        current = kw.get('month')
        current_month = current.strip() if current else None
        print(employee_id, current_month)
        current_date = datetime.now()
        date = current_date.strftime('%Y-%m-%d')
        id = int(employee_id)

        if not employee_id:
            return request.make_response(json.dumps({"status": "failure", "message": "Employee ID is needed"}),
                                         headers={'Content-Type': 'application/json'})

        # Fetch employee record
        existing_record = request.env["employee.master"].sudo().search([('id', '=', id)], limit=1)

        if not existing_record:
            return request.make_response(json.dumps({"status": "failure", "message": "No data found"}),
                                         headers={'Content-Type': 'application/json'})



        employee_attendance = request.env['attendance.record'].sudo().search([('employee_id', '=', id)])



        # Fetch attendance records for the employee, filter by month if provided
        domain = [('employee_id', '=', id)]
        if current_month:
            domain.append(('month', '=', current_month))


        employee_attendance = request.env['attendance.record'].sudo().search(domain)
        emp_attedance = request.env['employee.attendance'].sudo().search([('employee_id','=',id),('date','=',date)])

        # Prepare the dictionary to hold full and half day counts for each month
        attendance_by_month = defaultdict(lambda: {'full_day': 0, 'half_day': 0,'leave':0})

        for record in employee_attendance:
            month = record.month
            attendance_by_month[month]['full_day'] += record.full_day
            attendance_by_month[month]['half_day'] += record.half_day
            attendance_by_month[month]['leave'] += record.leave

        # Fetch employee's designation
        des = existing_record.designation
        designation = request.env['designation'].sudo().search([('id', '=', int(des))], limit=1)
        designation_name = designation.designation_name if designation else "NA"

        # Prepare employee info
        employee_info = {
            'employee_id': existing_record.id,
            'employee_name': existing_record.name if existing_record.name else "NA",
            'phone_number': existing_record.contact if existing_record.contact else "NA",
            'dob': existing_record.birth_date.strftime('%Y-%m-%d') if existing_record.birth_date else "NA",
            'gender': existing_record.sex if existing_record.sex else "NA",
            'designation': designation_name,
            'is_logged_in':emp_attedance.is_logged_in,
            'attendance_by_month': []
        }

        # Add full and half day counts for each month to employee_info
        for month, counts in attendance_by_month.items():
            employee_info['attendance_by_month'].append({
                'month': month,
                'full_day': counts['full_day'],
                'half_day': counts['half_day'],
                'leave': counts['leave']
            })

        return request.make_response(json.dumps({"status": "success", "data": employee_info}),
                                     headers={'Content-Type': 'application/json'})
