from odoo import http, fields
from odoo.http import request
import pytz
import json
from datetime import timedelta, datetime

from collections import defaultdict



class EmployeeAPI(http.Controller):
    @http.route('/api/geofencing/punch_in', type='http', auth='none', methods=['POST'], csrf=False, cors='*')
    def checkin(self, **kwargs):
        try:
            byte_string = request.httprequest.data
            data = json.loads(byte_string.decode('utf-8'))

            employee_id = data.get('employee_id')
            lat = data.get('lat')
            lon = data.get('lon')
            checkin_time = data.get('punch_in')
            checkout_time = data.get('punch_out')
            date = data.get('date')

            try:
                if checkin_time:
                    checkin_time = datetime.strptime(checkin_time, '%Y-%m-%d %H:%M:%S')
                if checkout_time:
                    checkout_time = datetime.strptime(checkout_time, '%Y-%m-%d %H:%M:%S')
            except ValueError:
                return request.make_response(
                    json.dumps(
                        {"status": "failure", "message": "Invalid time format. Please use 'YYYY-MM-DD HH:MM:SS'."}),
                    headers={'Content-Type': 'application/json'}
                )

            user_timezone = pytz.timezone(request.env['res.users'].sudo().browse(2).tz)

            if checkin_time:
                local_in_time = user_timezone.localize(checkin_time)
                utc_in_time = local_in_time.astimezone(pytz.utc).replace(tzinfo=None)
            else:
                utc_in_time = None

            if checkout_time:
                local_out_time = user_timezone.localize(checkout_time)
                utc_out_time = local_out_time.astimezone(pytz.utc).replace(tzinfo=None)
            else:
                utc_out_time = None


            if not employee_id or not date:
                return request.make_response(
                    json.dumps({"status": "failure", "message": "Employee ID and date are required."}),
                    headers={'Content-Type': 'application/json'}
                )

            # Convert employee_id to integer
            try:
                id = int(employee_id)
            except ValueError:
                return request.make_response(
                    json.dumps({"status": "failure", "message": "Invalid Employee ID."}),
                    headers={'Content-Type': 'application/json'}
                )

            # Check if attendance record exists for the employee on the given date
            Attendance = request.env["employee.attendance"]
            existing_record = Attendance.sudo().search([('date', '=', date), ('employee_id', '=', id)], limit=1)

            # Handle check-in
            if not existing_record:
                Attendance.sudo().create({
                    'employee_id': employee_id,
                    'in_latitude': lat,
                    'in_longitude': lon,
                    'check_in': utc_in_time,
                    'date': date,
                    'is_logged_in': True
                })
                return request.make_response(
                    json.dumps({"status": "success", "message": " PunchIn Successful"}),
                    headers={'Content-Type': 'application/json'}
                )

            # Handle check-out
            existing_record.sudo().write({
                'out_latitude': lat,
                'out_longitude': lon,
                'check_out': utc_out_time,
                'is_logged_in': False
            })

            try:

                punch_in = existing_record.check_in
                punch_out = existing_record.check_out

                # If punch_out is missing, check if 12 hours have passed
                if not punch_out:
                    now = datetime.utcnow()
                    hours_passed = (now - punch_in).total_seconds() / 3600

                    if hours_passed >= 12:
                        punch_out = punch_in + timedelta(hours=12)
                        existing_record.sudo().write({
                            'check_out': punch_out,
                            'out_latitude': existing_record.in_latitude,
                            'out_longitude': existing_record.in_longitude,
                            'is_logged_in': False
                        })
                    else:
                        return request.make_response(
                            json.dumps(
                                {"status": "failure", "message": "Punch-out missing and 12 hours haven't passed yet."}),
                            headers={'Content-Type': 'application/json'}
                        )

                interval_time = punch_out - punch_in

                # Retrieve or create attendance record for the employee
                employee_master = request.env['employee.master'].sudo().search([('id', '=', id)], limit=1)
                if not employee_master:
                    return request.make_response(
                        json.dumps({"status": "failure", "message": "Employee not found."}),
                        headers={'Content-Type': 'application/json'}
                    )



                current_time = datetime.strptime(date, "%Y-%m-%d")
                current_month = current_time.strftime('%Y-%m')

                attendance_record = request.env['attendance.record'].sudo().search(
                    [('employee_id', '=', id), ('month', '=', current_month)], limit=1)

                if not attendance_record:
                    attendance_record = request.env['attendance.record'].sudo().create({
                        'employee_id': id,
                        'month': current_month,
                        'date':current_time,
                        'full_day': 0,
                        'half_day': 0,
                    })

                # Update attendance based on interval time
                if interval_time >= timedelta(hours=8):
                    # Full-day attendance
                    employee_master.sudo().write({'attendance': employee_master.attendance + 1})
                    attendance_record.sudo().write({'full_day': attendance_record.full_day + 1})

                elif interval_time >= timedelta(hours=4):
                    # Half-day attendance
                    employee_master.sudo().write({'attendance': employee_master.attendance + 0.5})
                    attendance_record.sudo().write({'half_day': attendance_record.half_day + 1})



                return request.make_response(
                    json.dumps({"status": "success", "message": "Employee attendance successfully updated."}),
                    headers={'Content-Type': 'application/json'}
                )
            except Exception as e:

                return request.make_response(
                    json.dumps({"status": "failure", "message": f"An error occurred: {str(e)}"}),
                    headers={'Content-Type': 'application/json'}
                )


        except Exception as e:

            # Handle unexpected errors
            return request.make_response(
                json.dumps({"status": "failure", "message": f"An error occurred: {str(e)}"}),
                headers={'Content-Type': 'application/json'}
            )



class EmployeeCalender(http.Controller):

    @http.route('/api/geofencing/calender', type='http', auth='none', methods=['GET'], csrf=False, cors='*')
    def calender(self, employee_id):
        if not employee_id:
            return request.make_response(json.dumps({'status': 'Failure', 'message': 'employee id required'}))

        attendance_records = request.env['employee.attendance'].sudo().search([
            ('employee_id', '=', int(employee_id)),
            ('check_in', '!=', False),
            ('check_out', '!=', False)
        ])

        if not attendance_records:
            return request.make_response(json.dumps({'status': 'failure', 'message': 'no attendance records found'}))

        # Group by date
        grouped_data = defaultdict(float)

        for record in attendance_records:
            if record.check_in and record.check_out:
                check_in = record.check_in
                check_out = record.check_out
                duration = (check_out - check_in).total_seconds() / 3600.0
                date_str = record.date.strftime('%Y-%m-%d') if record.date else check_in.strftime('%Y-%m-%d')
                grouped_data[date_str] += duration

        response_data = []

        for date_str, total_hours in grouped_data.items():
            if total_hours < 4:
                leave_type = 'Leave'
            elif 4 <= total_hours <= 8:
                leave_type = 'Half Day'
            else:
                leave_type = 'Full Day'

            response_data.append({
                'date': date_str,
                'status': leave_type
            })

        return request.make_response(json.dumps({'status': 'success', 'data': response_data}))
