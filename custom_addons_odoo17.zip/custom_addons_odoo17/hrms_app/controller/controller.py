from odoo import http
from odoo.http import request
from odoo.exceptions import AccessDenied

class MobileApiController(http.Controller):
    @http.route('/api/authenticate', type='json', auth='none', methods=['POST'], csrf=False,cors='*')
    def authenticate(self, **kwargs):
        user_id = kwargs.get('userID')
        password = kwargs.get('Password')
        if not user_id or not password:
            return {
                "status": "error",
                "message": "userID and Password are required"
            }
        record = request.env['employee.master'].sudo().search([('id','=',int(user_id))])
        emp_pass = record.password

        if password==emp_pass:
            return {'status':'success','message':'successful login'}
        return {'status':'failure','message':'password is wrong '}



    @http.route('/api/session/logout', type='json', auth='user', methods=['POST'], csrf=False)
    def logout(self):
        request.session.logout()
        return {'status': 'success', 'message': 'Logged out successfully'}
