from odoo import api, fields, models, tools, SUPERUSER_ID
from datetime import datetime, date
from pytz import timezone, utc
import boto3
import base64
from botocore.exceptions import NoCredentialsError


class Attendance(models.Model):
    _name = 'employee.attendance'
    _description = 'Employee Attendance'

    employee_id = fields.Many2one('employee.master', string='Employee ID')
    # employee_name = fields.Char(related = 'employee_id.name',string='Employee Name',store=True,readonly=True)
    check_in = fields.Datetime(string='Check In')
    check_out = fields.Datetime(string='Check Out')
    date = fields.Date(string='Date')
    # employee_name = fields.Char(related='employee_id.name', string="Employee Name", store=True)
    in_latitude = fields.Float(string='In Latitude')
    in_longitude = fields.Float(string='In Longitude')
    out_latitude = fields.Float(string='Out Latitude')
    out_longitude = fields.Float(string='Out Longitude')
    is_logged_in = fields.Boolean(string='IS Logged In')

    @api.depends('check_in', 'check_out')
    def convert_to_ist(self):
        """ Convert all datetime fields from UTC to IST """
        self.convert_utc_to_ist(['check_in', 'check_out'])

    def get_active_employees(self):
            active_employees = self.env['employee.attendance'].sudo().search([('is_logged_in', '=', True)])

            exceed_time = int(self.env['ir.config_parameter'].sudo().get_param('time_limit', 0))  # Ensure conversion to int


            current_time = datetime.now()  # Define current time

            for employee in active_employees:

                checkin_time = employee.check_in
                current_month = datetime.now().strftime('%Y-%m')# Assuming checkin is a datetime field

                # Calculate time difference in minutes
                time_diff = (current_time - checkin_time).total_seconds() / 60


                if time_diff > exceed_time:
                    id = employee.employee_id

                    employee_record = self.env['attendance.record'].sudo().search([('employee_id','=',int(id))])
                    employee.write({
                        'is_logged_in': False,
                        'check_out': current_time,
                        'out_latitude': employee.in_latitude,  # Assuming `in_lat` exists
                        'out_longitude': employee.in_longitude  # Assuming `in_lon` exists
                    })
                    employee_record.sudo().create({
                        'full_day':1,
                        'employee_id':int(id),
                        'month':current_month,
                        'date':current_time
                    })


class AttendanceRecord(models.Model):
    _name ='attendance.record'
    _description ='Attendance Record'

    employee_id = fields.Many2one('employee.master',string='Employee ID')
    # employee_name = fields.Char(related='employee_id.name', string='Employee Name')
    full_day = fields.Integer(string='Full Day', default='0')
    half_day = fields.Integer(string='Half Day',default='0')
    leave = fields.Integer(string="Leave",default='0')
    month = fields.Char(string='month')
    date = fields.Date(string='Date')


class AdminPanel(models.Model):
    _name = 'admin.panel'
    _description ='Admin Panel'


    user_name = fields.Char(string='User Name')
    event_title = fields.Text(string= 'Event Title')
    event_description = fields.Text(string='Event Description')
    event_time = fields.Datetime(string='Event Time')
    profile_image = fields.Binary(string='Upload Image')
    binary_file_name = fields.Char("File name ")
    binary_field = fields.Many2many("ir.attachment",string="Multiple file upload")



    def upload_to_s3(self):
        # Fetch S3 credentials (you can store them in a config model)
        post_id = self.id
        s3_object = self.env['s3.configuration'].sudo().search([],limit=1)
        s3_config = {
            'access_key': s3_object.access_key,
            'secret_key': s3_object.secret_key,
            'bucket_name': s3_object.bucket_name,
            'region_name': s3_object.region_name,
        }


        # Initialize S3 client
        s3_client = boto3.client(
            's3',
            aws_access_key_id=s3_config['access_key'],
            aws_secret_access_key=s3_config['secret_key'],
            region_name=s3_config['region_name'],
        )

        # Iterate through the attachments
        for attachment in self.binary_field:
            print(attachment)
            try:
                # Decode the file content (stored as base64)
                file_content = base64.b64decode(attachment.datas)
                file_name = attachment.name



                # Upload to S3
                s3_client.put_object(
                    Bucket=s3_config['bucket_name'],
                    Key=file_name,
                    Body=file_content,
                    # ACL='public-read'  # Makes the file publicly accessible
                )

                # Construct the file's S3 URL
                file_url = f"https://{s3_config['bucket_name']}.s3.{s3_config['region_name']}.amazonaws.com/{file_name}"


                # Update attachment with the S3 URL
                attachment.write({'url': file_url})
                attachment.write({'description':post_id})
            except NoCredentialsError:
                raise ValueError("AWS credentials not found!")
            except Exception as e:
                raise ValueError(f"Error uploading file to S3: {str(e)}")

    def write(self, vals):
        res = super(AdminPanel, self).write(vals)

        # Check if binary_field has changed
        if 'binary_field' in vals:
            self.upload_to_s3()

        return res


class EmployeeMasterInherit(models.Model):
    _inherit = 'employee.master'
    _description ='Employee Master'


    password = fields.Char(string='Password')



