from odoo import models, fields, api

class S3Configuration(models.Model):
    _name = 's3.configuration'
    _description = 'S3 Configuration'

    access_key = fields.Char(string='Access Key', required=True)
    secret_key = fields.Char(string='Secret Key', required=True)
    bucket_name = fields.Char(string='Bucket Name', required=True)
    region_name = fields.Char(string='Region Name', required=True)
