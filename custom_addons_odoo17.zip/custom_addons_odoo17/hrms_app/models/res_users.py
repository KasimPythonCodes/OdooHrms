# from odoo import models, fields, api,_
#
#
# class ResUsers(models.Model):
#     _inherit = 'res.users'
#
#     dob = fields.Date('Date of Birth ')
