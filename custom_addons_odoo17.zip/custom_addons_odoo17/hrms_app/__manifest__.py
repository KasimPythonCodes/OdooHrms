{
    'name': 'HRMS App',
    'version': '1.0',
    'sequence': 10,
    'summary': 'Attendance app with geolocation',
    'author': 'Tech Rajendra',
    'maintainer': 'Tech Rajendra',
    'license': 'LGPL-3',
    'description': """
        Attendance HRMS app with geolocation.
    """,
    # 'depends': ["base", "hr", "payroll_process"],
    'depends': ["base", "hr", "payroll_process"],
    'data': [
        'security/ir.model.access.csv',
        # 'views/user_inherit_view.xml',
        'views/admin_panel.xml',
        'views/s3.xml',
        'views/attendance.xml',
        'views/record.xml',
        'data/ir_cron.xml'
    ],
    'installable': True,
    'application': True,
}
