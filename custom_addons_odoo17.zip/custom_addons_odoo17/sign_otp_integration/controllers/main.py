import datetime
from datetime import timedelta

from odoo import http
from odoo.http import request
import random
from twilio.rest import Client
import logging
from twilio.rest import Client
import random

_logger = logging.getLogger(__name__)

class SignOTPController(http.Controller):

    # ------------------------------------------
    # API: Send OTP to phone number via Twilio
    # ------------------------------------------
    @http.route('/sign/send_otp', type='json', auth='public', csrf=False)
    def send_otp(self, phone=None):
        """
        Send OTP via Twilio SMS.
        Expected payload: { "phone": "+919639276685" }
        """
        # Twilio credentials
        resp={}
        try:
            res = request.env['otp.send'].sudo().search([],limit=1)
            # account_sid = 'ACdd9a1d21068f0d6addca34128a9d468d'
            account_sid = res.account_sid
            # auth_token = '492b318801c9a08f5edf98f89a166dc1'
            auth_token = res.auth_token
            client = Client(account_sid, auth_token)
            # Generate a random 6-digit OTP
            otp = random.randint(100000, 999999)
            # Message body

            message_body = f"Your OTP code is {otp}. It will expire in 5 minutes."
            # Send to multiple recipients
            number = '+91' + str(phone)
            expiry_minutes = 5
            expiry_second = expiry_minutes * 60
            expiry_time = datetime.datetime.utcnow() + timedelta(seconds=expiry_second)
            request.session.timeout=expiry_second
            res.update({
                'otp_id':otp,
                'expiry_time':expiry_time,
            })
            if number:
                message = client.messages.create(
                      body=message_body,
                      from_=res.from_number,  # <-- Your verified Twilio number
                      to=number
                  )
                resp['status']=200
                resp['message']="Otp send successfully !"
        except Exception as e:
            resp['status']=500
            resp['errorMessage']=str(e)
            print(str(e))
        return resp



    # ------------------------------------------
    # 2 API: Verify OTP entered by user
    # ------------------------------------------
    @http.route('/sign/verify_otp', type='json', auth='public', csrf=False)
    def verify_otp(self, otp=None):
        """
        Verify the OTP entered by the user.
        Expected payload: { "otp": "1234" }
        """
        resp={}
        try:
            res = request.env['otp.send'].sudo().search([],limit=1)
            stored_otp = res.otp_id
            stored_phone = otp

            if not (stored_otp and stored_phone):
                resp["success"]=404,
                resp["message"]="No OTP found. Please request again."
                return resp
            if res.expiry_time<datetime.datetime.now():
                resp['success']=400
                resp['message']="OTP Expired. Please Try Again!"
                return resp
            if str(stored_phone) == str(stored_otp):
                _logger.info(f"OTP verified successfully for {stored_phone}")
                # Optionally clear session OTP
                res.update({
                    'otp_id':False,
                    'expiry_time':False,
                })
                rd = request.env['sign.request'].sudo().search([], limit=1, order='id desc')
                rd.update({'send_otp_flag1':True})
                resp["success"]=200
                resp["message"]="OTP verified successfully."
            else:
                _logger.warning(f"Invalid OTP attempt for {stored_phone}")
                resp["success"]=400
                resp["message"]="Invalid OTP. Please try again."

                return resp
        except Exception as e:
            resp['success']=500
            resp['errorMessage']=str(e)
            print(str(e))
        return resp


