from odoo import models,fields,api,_
import requests


class OtpSend(models.Model):
    _name = 'otp.send'
    _description = 'OTP Send'

    account_sid = fields.Char(string='Account SID', required=True)
    auth_token = fields.Char(string='Auth Token', required=True)
    from_number = fields.Char(string="From Number")
    message_body = fields.Html(string='Your Massage', translate=True)
    otp_id = fields.Char(string="Otp Code")
    expiry_time = fields.Datetime('Expiry Time')


class SignRequest(models.Model):
    _inherit = "sign.request"
    send_otp_flag1 = fields.Boolean("verify otp")

    def go_to_document(self):
        """ Override Odoo Sign Redirect Method """
        check_list=[]
        self.ensure_one()
        res = super(SignRequest, self).go_to_document()
        for val in self.request_item_ids:
            if val.state =='completed':
                self.write({'send_otp_flag1':True})
            else:
                self.write({'send_otp_flag1':False})
        return res

