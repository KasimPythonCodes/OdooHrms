/** @odoo-module **/
//kasim-->if used odoo18 uncomment 'import { rpc } from "@web/core/network/rpc"' if odoo17 used 'import { rpc } from "@web/core/network/rpc_service"'
//import { rpc } from "@web/core/network/rpc";
//import { rpc } from "@web/core/network/rpc_service";
import { jsonrpc } from "@web/core/network/rpc_service";

console.log("📦 sign_send_otp.js loaded...++++++++++++++++++++++++++++++++++++++++++++");

document.addEventListener("DOMContentLoaded", () => {
    console.log("✅ DOM ready in Sign page");

    const sendOtpBtn = document.querySelector(".o_send_otp_button");
    const verifyBox = document.querySelector(".o_otp_verify_box");
    const phoneInput = document.querySelector("#otp_phone");
    const otpInput = document.querySelector("#otp_number");
    const verifyBtn = document.querySelector(".o_verify_otp_button");
    const msgBox = document.querySelector("#otp_response");
    const validateBtn = document.querySelector(".o_validate_button");

    if (!sendOtpBtn || !verifyBox) {
        console.warn("⚠️ OTP elements not found on page.");
        return;
    }

    // 🔹 Hide validate button initially
    if (validateBtn) {
        validateBtn.style.display = "none";
    }

    // 🔹 Step 1: Send OTP
    sendOtpBtn.addEventListener("click", async () => {
        const phone = phoneInput.value.trim();
        if (!phone) {
            msgBox.textContent = "⚠️ Please enter your phone number first.";
            msgBox.style.color = "red";
            return;
        }

        msgBox.textContent = "📩 Sending OTP...";
        msgBox.style.color = "blue";

        try {
            const res = await jsonrpc("/sign/send_otp", { phone });
            msgBox.textContent = res.message || "✅ OTP sent successfully!";
            msgBox.style.color = "green";

            // Hide send button, show verify section
            sendOtpBtn.style.display = "none";
            phoneInput.setAttribute("readonly", true);
            verifyBox.style.display = "block";
            if (res.status === 200 || res.success === true) {
        // Add a small fade-out effect for better UX
        phoneInput.style.transition = "opacity 0.6s ease";
        phoneInput.style.opacity = "0";

        // Wait for animation to finish, then hide completely
        setTimeout(() => {
            phoneInput.style.display = "none";
            console.log("✅ Phone input hidden");
        }, 600);
    }
        } catch (err) {
            console.error(err);
            msgBox.textContent = "❌ Failed to send OTP. Try again.";
            msgBox.style.color = "red";
        }
    });

    // 🔹 Step 2: Verify OTP
    verifyBtn.addEventListener("click", async () => {
        const otp = otpInput.value.trim();
        console.log(otp,"KKKKKKKKKKKKKKKKKKKKKKKKKKK",otpInput.value,"OOOOOOOOOO",otpInput.value.trim())
        if (!otp) {
            msgBox.textContent = "⚠️ Please enter OTP.";
            msgBox.style.color = "red";
            return;
        }

        msgBox.textContent = "🔍 Verifying OTP...";
        msgBox.style.color = "blue";

        try {
            const res = await jsonrpc("/sign/verify_otp", { otp });
            console.log(res,"++++++++++++++++++++++++++++++++++++++++++++++++++")
            if (res.success==200) {
                console.log(res,"hhhhhhhhhhhhhhhhhhhhhhh")
                msgBox.textContent = "✅ OTP verified successfully!";
                msgBox.style.color = "green";

                // Hide OTP verify section
                verifyBtn.style.display = "none";
                otpInput.setAttribute("readonly", true);
                setTimeout(() => {
                    verifyBox.style.display = "none";
                }, 800);

                // 🔹 Now show the Validate & Send button
                if (validateBtn) {
                    validateBtn.style.display = "inline-block";
                }
            } else {
                msgBox.textContent = res.message || "❌ Invalid OTP. Try again.";
                msgBox.style.color = "red";
            }
        } catch (err) {
            console.error(err);
            msgBox.textContent = "❌ OTP verification failed.";
            msgBox.style.color = "red";
        }
    });
});
