{
    "name": "Sign OTP Integration",
    "version": "1.0",
    "summary": "Twilio OTP verification before signing documents",
    "category": "Sign",
    "author": "Salman Khan and Kasim",
    "depends": ["web","sign"],
    "data": [
        "security/ir.model.access.csv",
        "views/sign_doc_sign_inherit.xml",
        "views/otp_form_view.xml",
    ],
    "application": False,
    "installable": True,
    'license': 'OEEL-1',
    "assets": {
            'sign.assets_public_sign': [
                "sign_otp_integration/static/src/js/sign_otp_button.js",
            ],
        },

}
