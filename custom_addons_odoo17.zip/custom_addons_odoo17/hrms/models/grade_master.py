from odoo import models, fields, api
from datetime import datetime
from odoo.exceptions import ValidationError


class GradeMaster(models.Model):
    _name = 'grade.master'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Grade Master'
    _rec_name = 'grade_name'
    _order = 'grade_level'
    _sql_constraints = [
        ('unique_grade_code_per_family_company', 'unique(grade_code, job_function, company_id)', 'Grade Code must be unique per company.')
    ]

    company_id = fields.Many2one('res.company', string="Company", required=True, default=lambda self: self.env.company)
    grade_name = fields.Char("Grade Name", required=True) # e.g., G1, G2, L5
    grade_code = fields.Char("Grade Code")
    grade_ids = fields.One2many("level.master", "grade_id", string="Grade Levels")
    grade_description = fields.Char("Grade Description", required=True) # e.g., Entry, Senior, Lead
    # pay_band_id = fields.Many2one('hr.payroll.structure', string="Payroll Structure", tracking=True)
    min_salary = fields.Float("Salary Range (min)")
    max_salary = fields.Float("Salary Range (max)")
    job_function = fields.Many2one('hr.job', string="Designation")
    grade_level = fields.Char()
    # promotion_criteria = fields.Text("Promotion Criteria")
    status = fields.Selection(
        selection=[
            ('draft', 'Draft'),
            ('active', 'Active'),
            ('archived', 'Archived')
        ],
        string="Status",
        default='active',
        required=True
    )
    employee_count = fields.Integer(
        string="Employee Count",
        store=True
    )

    @api.model
    def create(self, vals):
        # 1. Generate grade_code if not set
        if not vals.get('grade_code') and vals.get('grade_name'):
            prefix = vals['grade_name'][:3].upper()
            existing_codes = self.search([('grade_code', '=like', f'{prefix}%')], order='grade_code desc', limit=1)
            next_number = 1
            if existing_codes:
                last_code = existing_codes.grade_code[-3:]
                if last_code.isdigit():
                    next_number = int(last_code) + 1
            vals['grade_code'] = f"{prefix}{str(next_number).zfill(3)}"

        # 2. Create the Grade record
        grade = super(GradeMaster, self).create(vals)

        # 3. Propagate company_id and job_function to linked level.master
        if grade:
            level_model = self.env['level.master'].sudo()
            levels = level_model.search([('grade_id', '=', grade.id)])
            for level in levels:
                level.write({
                    'company_id': grade.company_id.id,
                    'job_function': [(6, 0, [grade.job_function.id])] if grade.job_function else False
                })

        return grade

class Job(models.Model):
    _inherit = 'hr.job'

    grade_id = fields.Many2one('grade.master', string="Job Grade")

class HrEmployee(models.Model):
    _inherit = 'hr.employee'

    grade_id = fields.Many2one('grade.master', string="Grade")
    level_id = fields.Many2one('level.master', string="Level")
    city_id = fields.Many2one('res.country.city', string='City', domain="[('state_id', '=', private_state_id)]")

    @api.onchange('city_id')
    def set_city(self):
        self.private_city = self.city_id.name

    @api.onchange('level_id')
    def _onchange_level_id(self):
        if self.level_id:
            self.grade_id = self.level_id.grade_id

    @api.onchange('grade_id','level_id')
    def _onchange_grade_employee_count(self):
        # for grade in self:
        employees = self.env['hr.employee'].search([
            ('grade_id', '=', self.grade_id.id)
        ])
        self.grade_id.employee_count = len(employees)


class LevelMaster(models.Model):
    _name = 'level.master'
    _description = 'Level Master'
    _rec_name = 'level_name'
    _order = 'level_code'
    _sql_constraints = [
        ('unique_level_code_per_function_company',
         'unique(level_code, job_function, company_id)',
         'Each Level Code must be unique within the same Job function and Company.')
    ]

    company_id = fields.Many2one('res.company', string='Company', required=True, default=lambda self: self.env.company)
    level_code = fields.Text("Level Code", required=True)  # L1, L2, etc.
    level_name = fields.Text("Level Name", required=True)  # Entry, Mid, etc.
    description = fields.Text("Level Description")
    min_salary = fields.Float("Salary Range (min)")
    max_salary = fields.Float("Salary Range (max)")
    grade_id = fields.Many2one('grade.master', string="Grade", required=True)
    job_function = fields.Many2one('hr.job', string="Department")
    status = fields.Selection(
        selection=[
            ('draft', 'Draft'),
            ('active', 'Active'),
            ('archived', 'Archived')
        ],
        string="Status",
        default='active',
        required=True
    )


    @api.constrains('min_salary', 'max_salary', 'grade_id')
    def _check_salary_range(self):
        for rec in self:
            if rec.min_salary >= rec.max_salary:
                raise ValidationError("Min salary must be less than max salary.")

            if rec.min_salary < rec.grade_id.min_salary or rec.max_salary > rec.grade_id.max_salary:
                raise ValidationError("Level salary must be within the Grade's compensation band.")

class ResCountryCity(models.Model):
    _name = 'res.country.city'
    _description = 'City'


    name = fields.Char(string='City')
    state_id = fields.Many2one('res.country.state',string='State', required=True)
    country_id = fields.Many2one('res.country', string='Country', default='India', required=True)

    @api.model_create_multi
    def create(self, vals):
        res = super(ResCountryCity, self).create(vals)
        return res

    def write(self, vals):
        result = super(ResCountryCity, self).write(vals)
        return result


class ResCompany(models.Model):
    _inherit = 'res.company'

    city_id = fields.Many2one('res.country.city', string="City",domain="[('state_id', '=', state_id)]")
    sgst = fields.Char(String="SGST")
    cgst = fields.Char(String="CGST")

    @api.onchange('city_id')
    def set_city(self):
        self.city = self.city_id.name