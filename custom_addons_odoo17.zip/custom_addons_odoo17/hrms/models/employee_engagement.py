
from odoo import models, fields, api
from odoo.exceptions import ValidationError
from odoo.exceptions import UserError

class NominationCategory(models.Model):
    _name = "employee.nomination.category"
    _description = "Nomination Category"

    name = fields.Char("Category Name", required=True)
    description = fields.Text("Description")


class EmployeeSurveyQuestion(models.Model):
    _name = "employee.survey.question"
    _description = "Survey Question"

    survey_id = fields.Many2one(
        "employee.survey",
        string="Survey",
        required=True,
        ondelete="cascade"
    )
    question_text = fields.Char(required=True)
    question_type = fields.Selection([
        ('text', 'Text Input'),
        ('mcq', 'Multiple Choice'),
        ('rating', 'Rating Scale')
    ], default="text")
    answers = fields.Char("Answers")
    company_id = fields.Many2one(
        'res.company',
        string="Company",
        default=lambda self: self.env.company.id,
        required=True
    )

    option_ids = fields.One2many(
        "employee.survey.option",
        "question_id",
        string="Options"
    )

class EmployeeSurveyResponse(models.Model):
    _name = "employee.survey.response"
    _description = "Survey Response"

    survey_id = fields.Many2one(
        "employee.survey",
        string="Survey",
        required=True,
        ondelete="cascade"
    )
    employee_id = fields.Many2one("hr.employee", string="Employee")
    submitted = fields.Boolean(default=False)

    response_line_ids = fields.One2many(
        "employee.survey.response.line",
        "response_id",
        string="Answers"
    )

    response_text = fields.Text(string='Response Text')
    company_id = fields.Many2one(
        'res.company',
        string="Company",
        default=lambda self: self.env.company.id,
        required=True
    )


class EmployeeSurveyResponseLine(models.Model):
    _name = "employee.survey.response.line"
    _description = "Survey Response Line"

    response_id = fields.Many2one(
        "employee.survey.response", string="Response", required=True, ondelete="cascade"
    )
    question_ids = fields.One2many("employee.survey.question", "survey_id")
    option_id = fields.Many2one(
        "employee.survey.option", string="Option"
    )
    rating_value = fields.Integer()
    answer_text = fields.Text()


class EmployeeNomination(models.Model):
    _name = "employee.nomination"
    _description = "Employee Nomination"
    _inherit = ["mail.thread", "mail.activity.mixin"]

    name = fields.Char("Nomination Title", required=True, tracking=True)
    nominee_id = fields.Many2one("hr.employee", string="Nominee", required=True, tracking=True)
    nominator_id = fields.Many2one("hr.employee", string="Nominated By", required=True, tracking=True)
    category_id = fields.Many2one("employee.nomination.category", string="Category", required=True)
    reason = fields.Text("Reason for Nomination", tracking=True)
    deadline = fields.Date("Deadline")
    company_id = fields.Many2one("res.company", string="Company", default=lambda self: self.env.company.id)

    state = fields.Selection([
        ("draft", "Draft"),
        ("submitted", "Submitted"),
        ("approved", "Approved"),
        ("rejected", "Rejected"),
    ], default="draft", string="Status", tracking=True)

    @api.constrains("deadline")
    def _check_deadline(self):
        for rec in self:
            if rec.deadline and rec.deadline < fields.Date.today():
                raise ValidationError("Deadline cannot be in the past.")

    def action_submit(self):
        for rec in self:
            rec.state = "submitted"

    def action_approve(self):
        for rec in self:
            rec.state = "approved"

    def action_reject(self):
        for rec in self:
            rec.state = "rejected"

class EmployeeSurvey(models.Model):
    _name = "employee.survey"
    _description = "Employee Survey"

    name = fields.Char(string="Survey Title", required=True)
    description = fields.Text(string="Description")
    target_audience = fields.Char(string="Target Audience")
    target_persons = fields.Many2many("hr.employee", string="Target Persons")
    deadline = fields.Date(string="Deadline")
    state = fields.Selection([
        ('draft', 'Draft'),
        ('published', 'Published'),
        ('closed', 'Closed')
    ], default='draft')
    company_id = fields.Many2one(
        'res.company',
        string="Company",
        default=lambda self: self.env.company.id,
        required=True
    )

    question_ids = fields.One2many(
        "employee.survey.question",
        "survey_id",
        string="Questions"
    )

    response_ids = fields.One2many(
        "employee.survey.response",
        "survey_id",
        string="Responses"
    )

    total_responses = fields.Integer(
        compute="_compute_total_responses",
        store=True
    )

    survey_type = fields.Char(string="Survey type")

    @api.depends("response_ids")
    def _compute_total_responses(self):
        for survey in self:
            survey.total_responses = len(survey.response_ids)

    def action_publish(self):
        self.write({"state": "published"})

    def action_close(self):
        self.write({"state": "closed"})

    def action_send_survey_reminder(self):
        """Send survey invitation mail to selected employees"""
        for rec in self:
            if not rec.target_persons:
                raise UserError("Please select at least one employee to send the survey.")

            if not rec.deadline_date:
                raise UserError("Please set a deadline before sending the survey.")

            # Get all email addresses
            emails = rec.target_persons.mapped("work_email")
            emails = [e for e in emails if e]  # Remove empty ones

            if not emails:
                raise UserError("Selected employees don't have work emails configured.")

            # Mail subject & body
            subject = f"Survey Invitation: {rec.name}"
            body = f"""
                <p>Dear Employee,</p>
                <p>You are invited to participate in the survey: <b>{rec.name}</b>.</p>
                <p><b>Deadline:</b> {rec.deadline_date}</p>
                <p>Please make sure to complete the survey before the deadline.</p>
                <p>Thank you.</p>
            """

            # Send mail to each employee
            for employee in rec.target_persons:
                if employee.work_email:
                    rec.env['mail.mail'].create({
                        'subject': subject,
                        'body_html': body,
                        'email_to': employee.work_email,
                        'author_id': rec.env.user.partner_id.id,
                    }).send()

class EmployeeSurveyOption(models.Model):
    _name = "employee.survey.option"
    _description = "Survey Option"

    question_id = fields.Many2one(
        "employee.survey.question", string="Question", required=True, ondelete="cascade"
    )
    option_text = fields.Char(required=True)
    company_id = fields.Many2one(
        'res.company',
        string="Company",
        default=lambda self: self.env.company.id,
        required=True
    )


class CompanyAnnouncement(models.Model):
    _name = "company.announcement"
    _description = "Company Announcements"
    _order = "date_posted desc"

    title = fields.Char("Title", required=True)
    content = fields.Html(
        "Content",
        required=True,
        help="Supports text, images, videos, and links",
    )
    date_posted = fields.Datetime("Posted On", default=fields.Datetime.now)
    posted_by = fields.Many2one(
        "res.users", string="Posted By", default=lambda self: self.env.user
    )

    like_count = fields.Integer("Likes", compute="_compute_likes_comments", store=True)
    comment_count = fields.Integer(
        "Comments", compute="_compute_likes_comments", store=True
    )

    engagement_ids = fields.One2many(
        "announcement.engagement", "announcement_id", string="Engagements"
    )
    company_id = fields.Many2one("res.company", string="Company", default=lambda self: self.env.company.id)


    @api.depends("engagement_ids.engagement_type")
    def _compute_likes_comments(self):
        for rec in self:
            rec.like_count = len(
                rec.engagement_ids.filtered(lambda e: e.engagement_type == "like")
            )
            rec.comment_count = len(
                rec.engagement_ids.filtered(lambda e: e.engagement_type == "comment")
            )



class AnnouncementEngagement(models.Model):
    _name = "announcement.engagement"
    _description = "Announcement Engagements"

    announcement_id = fields.Many2one(
        "company.announcement", required=True, ondelete="cascade"
    )
    user_id = fields.Many2one(
        "res.users", string="User", default=lambda self: self.env.user
    )
    engagement_type = fields.Selection(
        [("like", "Like"), ("comment", "Comment")], required=True
    )
    comment_text = fields.Text("Comment")
    company_id = fields.Many2one("res.company", string="Company", default=lambda self: self.env.company.id)



class CollaborationForum(models.Model):
    _name = "collaboration.forum"
    _description = "Internal Collaboration Forum"

    name = fields.Char("Topic", required=True)
    description = fields.Text("Description")
    created_by = fields.Many2one(
        "res.users", string="Created By", default=lambda self: self.env.user
    )
    post_ids = fields.One2many("forum.post", "forum_id", string="Posts")
    company_id = fields.Many2one("res.company", string="Company", default=lambda self: self.env.company.id)



class ForumPost(models.Model):
    _name = "forum.post"
    _description = "Forum Posts"

    forum_id = fields.Many2one(
        "collaboration.forum", required=True, ondelete="cascade"
    )
    author_id = fields.Many2one(
        "res.users", string="Author", default=lambda self: self.env.user
    )
    content = fields.Html("Post Content", required=True)
    date_posted = fields.Datetime("Posted On", default=fields.Datetime.now)
    tagged_users = fields.Many2many("res.users", string="Tagged Users")
    company_id = fields.Many2one("res.company", string="Company", default=lambda self: self.env.company.id)



class EmployeeCommunication(models.Model):
    _name = "employee.communication"
    _description = "Employee Communication"

    name = fields.Char(string="Subject", required=True)
    message = fields.Text(string="Message", required=True)
    date = fields.Date(string="Date", default=fields.Date.today)
    company_id = fields.Many2one("res.company", string="Company")