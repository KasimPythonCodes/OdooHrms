from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
from odoo.exceptions import UserError
from datetime import datetime, date, timedelta,time


class AttendanceRegularization(models.Model):
    _name = 'attendance.regularization'
    _description = 'Attendance Regularization'

    employee_id = fields.Many2one(
        'hr.employee',
        string="Employee",
        required=True,
        default=lambda self: self.env['hr.employee'].search([('user_id', '=', self.env.uid)], limit=1)
    )
    date = fields.Date(string="Date", required=True)
    check_in = fields.Datetime(string="Check In", required=True)
    check_out = fields.Datetime(string="Check Out", required=True)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('submitted', 'Submitted'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected')
    ], string="Status", default='draft', tracking=True)

    def action_submit(self):
        for rec in self:
            rec.state = 'submitted'

            # Get manager from employee record
            employee = rec.employee_id
            manager = employee.parent_id
            if not manager or not manager.user_id or not manager.work_email:
                raise UserError("Manager or their email is not set for this employee.")

            # Email content
            subject = "Attendance Regularization Request"
            body = f"""
                <p>Dear {manager.name},</p>
                <p>Please approve my attendance regularization request.</p>
                <p><strong>Date:</strong> {rec.date.strftime('%A, %d %B %Y')}<br/>
                <strong>Check In:</strong> {rec.check_in.strftime('%H:%M')}<br/>
                <strong>Check Out:</strong> {rec.check_out.strftime('%H:%M')}</p>
                <p>Regards,<br/>{employee.name}</p>
            """

            # Send email
            self.env['mail.mail'].create({
                'subject': subject,
                'body_html': body,
                'email_to': manager.work_email,
                'author_id': self.env.user.partner_id.id,
            }).send()

    def action_approve(self):
        for rec in self:
            rec.state = 'approved'

            # Search for existing attendance record for that date and employee
            attendance = self.env['hr.attendance'].search([
                ('employee_id', '=', rec.employee_id.id),
                ('check_in', '>=', rec.date),
                ('check_in', '<', rec.date + timedelta(days=1))  # assumes check_in is a datetime
            ], limit=1)

            if attendance:
                # Update existing record
                attendance.write({
                    'check_in': rec.check_in,
                    'check_out': rec.check_out
                })
            else:
                # If no record found, create one
                self.env['hr.attendance'].create({
                    'employee_id': rec.employee_id.id,
                    'check_in': rec.check_in,
                    'check_out': rec.check_out
                })

    # def action_approve(self):
    #     for rec in self:
    #         rec.state = 'approved'
    #         self.env['hr.attendance'].create({
    #             'employee_id': rec.employee_id.id,
    #             'check_in': rec.check_in,
    #             'check_out': rec.check_out
    #         })

    def action_reject(self):
        for rec in self:
            rec.state = 'rejected'

class BulkAttendanceMark(models.TransientModel):
    _name = 'bulk.attendance.mark'
    _description = 'Bulk Attendance Marking Wizard'

    date_ids = fields.Many2many('bulk.attendance.date', string="Dates to Mark")

    def action_mark_attendance(self):
        employees = self.env['hr.employee'].search([])
        attendance_obj = self.env['hr.attendance']

        for date_obj in self.date_ids:
            check_in = datetime.combine(date_obj.name, time(10, 0))  # 10:00 AM
            check_out = datetime.combine(date_obj.name, time(19, 0))  # 07:00 PM

            for emp in employees:
                already_marked = attendance_obj.search([
                    ('employee_id', '=', emp.id),
                    ('check_in', '>=', check_in),
                    ('check_out', '<=', check_out)
                ])
                if not already_marked:
                    attendance_obj.create({
                        'employee_id': emp.id,
                        'check_in': check_in,
                        'check_out': check_out,
                    })

    # def action_mark_attendance(self):
    #     employees = self.env['hr.employee'].search([])
    #     attendance_obj = self.env['hr.attendance']
    #
    #     for date_obj in self.date_ids:
    #         check_in = datetime.combine(date_obj.name, time.min)
    #         check_out = datetime.combine(date_obj.name, time.max)
    #
    #         for emp in employees:
    #             already_marked = attendance_obj.search([
    #                 ('employee_id', '=', emp.id),
    #                 ('check_in', '>=', check_in),
    #                 ('check_out', '<=', check_out)
    #             ])
    #             if not already_marked:
    #                 attendance_obj.create({
    #                     'employee_id': emp.id,
    #                     'check_in': check_in,
    #                     'check_out': check_in.replace(hour=17, minute=0),  # Example: 5 PM checkout
    #                 })


class BulkAttendanceDate(models.Model):
    _name = 'bulk.attendance.date'
    _description = 'Dates for Bulk Attendance'

    name = fields.Date(string="Date", required=True, unique=True)

class EmployeeTaskReport(models.Model):
    _name = 'employee.task.report'
    _description = 'Employee Task Report'
    _rec_name = 'employee_id'

    employee_id = fields.Many2one('hr.employee', string="Employee", required=True)

    task_count = fields.Integer("Total Tasks")
    total_hours = fields.Float("Total Planned Hours")
    project_ids = fields.Many2many('project.project', string="Projects")
    task_analytics = fields.Char(string="Task Analytics")
    attendance_analytics = fields.Float(string="Attendance Analytics")
    task_completion_rate = fields.Float(string="Task Completion Rate (%)")

    def action_calculate_analytics(self):
        for record in self:
            if not record.employee_id or not record.employee_id.user_id:
                raise UserError("Selected employee doesn't have a linked user.")

            user_id = record.employee_id.user_id.id

            tasks = self.env['project.task'].search([
                ('user_ids', 'in', [user_id])
            ])

            task_count = len(tasks)
            project_ids = list(set(tasks.mapped('project_id.id')))

            completed_on_time = 0
            completed_tasks = 0

            for task in tasks:
                if task.task_complete_date and task.date_deadline:
                    completed_tasks += 1

                    # Convert datetime to date if needed
                    complete_date = task.task_complete_date.date() if isinstance(task.task_complete_date, datetime) else task.task_complete_date
                    deadline_date = task.date_deadline.date() if isinstance(task.date_deadline, datetime) else task.date_deadline

                    if complete_date <= deadline_date:
                        completed_on_time += 1

            # Calculate completion rate
            task_completion_rate = (completed_on_time / completed_tasks) * 100 if completed_tasks else 0.0

            #  Attendance This Month
            today = date.today()
            first_day = today.replace(day=1)
            last_day = (first_day.replace(month=first_day.month % 12 + 1, day=1) - timedelta(
                days=1)) if first_day.month != 12 else date(today.year, 12, 31)

            attendances = self.env['hr.attendance'].search([
                ('employee_id', '=', record.employee_id.id),
                ('check_in', '>=', datetime.combine(first_day, datetime.min.time())),
                ('check_in', '<=', datetime.combine(last_day, datetime.max.time())),
            ])
            attendance_count = len(attendances)

            # Write values
            record.write({
                'task_count': task_count,
                'project_ids': [(6, 0, project_ids)],
                'task_completion_rate': task_completion_rate,
                'attendance_analytics': attendance_count,
            })

    def write(self, vals):
        result = super().write(vals)
        if 'employee_id' in vals:
            for rec in self:
                rec.action_calculate_analytics()
        return result

class ProjectTask(models.Model):
    _inherit = 'project.task'

    task_complete_date = fields.Date(string="Task Complete Date", readonly=True)

    def write(self, vals):
        res = super().write(vals)

        for task in self:
            if vals.get('state') == '1_done' and not task.task_complete_date:
                task.task_complete_date = date.today()

        return res

    @api.model
    def create(self, vals):
        task = super().create(vals)
        if task.stage_id.state == '1_done':
            task.task_complete_date = date.today()
        return task

class DepartmentReport(models.Model):
    _name = 'hr.department.report'
    _description = 'Department Report'

    department_id = fields.Many2one('hr.department', string="Department", required=True)
    workload_distribution = fields.Text(string="Workload Distribution")
    shift_attendance_rate = fields.Float(string="Shift Attendance Rate (%)")
    overtime_analysis = fields.Float(string="Overtime Analysis (Hrs)")

    def action_generate_report(self):
        for rec in self:
            workload_data = []
            if rec.department_id:
                employees = self.env['hr.employee'].search([
                    ('department_id', '=', rec.department_id.id)
                ])
            #     for emp in employees:
            #         if emp.user_id:
            #
            #
            #             task_count = self.env['project.task'].search_count([
            #                 ('user_ids', 'in', [emp.user_id.id])
            #             ])
            #             workload_data.append(f"{emp.name}: {task_count} tasks")
            #         else:
            #             workload_data.append(f"{emp.name}: No user assigned")
            # # make sure each `rec` gets its own result
            # rec.workload_distribution = "\n".join(workload_data)

                all_tasks = self.env['project.task'].search([])

                for emp in employees:
                    if emp.user_id:
                        # 🔍 filter only tasks assigned to this user
                        emp_tasks = all_tasks.filtered(lambda t: emp.user_id in t.user_ids)
                        task_count = len(emp_tasks)
                        workload_data.append(f"{emp.name}: {task_count} tasks")
                    else:
                        workload_data.append(f"{emp.name}: No user assigned")

                rec.workload_distribution = "\n".join(workload_data)

            # 2️⃣ Shift Attendance Rate
            leave_count = 0
            shift_count = 0
            today = fields.Date.today()
            for emp in employees:
                shift = self.env['hr.shift'].search([
                    ('employee_id', '=', emp.id),
                    ('date', '=', today)
                ])
                if shift:
                    shift_count += 1
                    leave = self.env['hr.leave'].search([
                        ('employee_id', '=', emp.id),
                        ('request_date_from', '<=', today),
                        ('request_date_to', '>=', today),
                        ('state', '=', 'validate')
                    ], limit=1)
                    if leave:
                        leave_count += 1
            rec.shift_attendance_rate = 0.0
            if shift_count:
                attendance_rate = 100 * (shift_count - leave_count) / shift_count
                rec.shift_attendance_rate = round(attendance_rate, 2)

            # 3️⃣ Overtime Analysis (last 30 days)
            overtime_total = 0.0
            one_month_ago = fields.Date.today() - timedelta(days=30)
            for emp in employees:
                attendances = self.env['hr.attendance'].search([
                    ('employee_id', '=', emp.id),
                    ('check_in', '>=', one_month_ago)
                ])
                for att in attendances:
                    if att.overtime_hours:
                        overtime_total += att.overtime_hours
            rec.overtime_analysis = round(overtime_total, 2)



class ShiftHolidayManagement(models.Model):
    _name = 'shift.holiday.management'
    _description = 'Shift Holiday Management'

    name = fields.Char(string="Holiday Message")
    holiday_date = fields.Date(string="Holiday Date")
    leave_type = fields.Selection([
        ('casual', 'Casual Leave'),
        ('sick', 'Sick Leave'),
        ('earned', 'Earned Leave'),
    ], string="Leave Type", required=True)
    is_auto_applied = fields.Boolean(string="Auto Applied (from Calendar)", default=False)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('apply', 'Apply'),
        ('approved', 'Approved'),
        ('cancelled', 'Cancelled'),
    ], string="Status", default='draft', tracking=True)

    approved = fields.Boolean(string="Approved", default=False)
    manager_id = fields.Many2one('hr.employee', string='Manager')

    def action_apply(self):
        for rec in self:
            rec.state = 'apply'
            rec.approved = False

    def action_approve(self):
        for rec in self:
            if rec.state == 'approved':
                continue  # Skip already approved records

            # Find employee linked to the user who is approving
            employee = self.env['hr.employee'].search([('user_id', '=', self.env.user.id)], limit=1)
            if not employee:
                raise UserError("No employee record linked to the current user.")

            # Deduct 1 leave based on leave type
            if rec.leave_type == 'casual':
                if employee.casual_leaves <= 0:
                    raise UserError("You don't have enough casual leaves.")
                employee.casual_leaves -= 1

            elif rec.leave_type == 'sick':
                if employee.sick_leaves <= 0:
                    raise UserError("You don't have enough sick leaves.")
                employee.sick_leaves -= 1

            elif rec.leave_type == 'earned':
                if employee.earned_leaves <= 0:
                    raise UserError("You don't have enough earned leaves.")
                employee.earned_leaves -= 1

            # Mark approved
            rec.state = 'approved'
            rec.approved = True

    def action_cancel(self):
        for rec in self:
            rec.state = 'cancelled'
            rec.approved = False

    def action_send_holiday_email(self):
        for rec in self:
            # Get the current employee (linked to logged-in user)
            employee = self.env['hr.employee'].search([('user_id', '=', self.env.user.id)], limit=1)
            if not employee:
                raise UserError("No employee record linked to the current user.")

            # Use parent_id as the manager, and get their user-linked email
            manager = employee.parent_id
            if not manager or not manager.user_id or not manager.user_id.partner_id or not manager.user_id.partner_id.email:
                raise UserError("Your manager or their email is not defined.")

            recipient_email = manager.user_id.partner_id.email

            subject = f"Holiday Notification - {rec.holiday_date.strftime('%Y-%m-%d')}"
            body = f"""
                <p>Dear {manager.name},</p>
                <p>This is to inform you about a holiday on <strong>{rec.holiday_date.strftime('%A, %d %B %Y')}</strong>.</p>
                <p><strong>Leave Type:</strong> {dict(rec._fields['leave_type'].selection).get(rec.leave_type)}</p>
                <p><strong>Message:</strong> {rec.name}</p>
                <p>Regards,<br/>{self.env.user.name}</p>
            """

            mail_values = {
                'subject': subject,
                'body_html': body,
                'email_to': recipient_email,
                'author_id': self.env.user.partner_id.id,
            }
            self.env['mail.mail'].create(mail_values).send()


class HrEmployee(models.Model):
    _inherit = 'hr.employee'

    casual_leaves = fields.Integer(string="Casual Leaves")
    sick_leaves = fields.Integer(string="Sick Leaves")
    earned_leaves = fields.Integer(string="Earned Leaves")


class HrShiftProductivity(models.Model):
    _name = 'hr.shift.productivity'
    _description = 'Shift Productivity Report'

    shift_id = fields.Many2one('hr.shift', string="Shift", required=True)
    employee_id = fields.Many2one('hr.employee', related='shift_id.employee_id', store=True)
    completed_tasks = fields.Integer("Completed Tasks")
    hours_worked = fields.Float("Hours Worked")
    efficiency_percent = fields.Float("Efficiency (%)", compute="_compute_efficiency")

    @api.depends('completed_tasks', 'hours_worked')
    def _compute_efficiency(self):
        for rec in self:
            rec.efficiency_percent = (rec.completed_tasks / rec.hours_worked * 10) if rec.hours_worked else 0


class HrShift(models.Model):
    _name = 'hr.shift'
    _description = 'HR Shift'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(required=True)
    employee_id = fields.Many2one('hr.employee', string="Assigned Employee", required=True)

    start_time = fields.Datetime("l")
    end_time = fields.Datetime("j")

    # Input Fields
    date = fields.Date(string="Shift Date", required=True)
    date_2 = fields.Date(string="Shift End Date", required=True)
    stat_time = fields.Float(string="Start Time", required=True, help="Enter time in HH.MM format (e.g., 9.5 for 9:30)")
    en_time = fields.Float(string="End Time", required=True, help="Enter time in HH.MM format (e.g., 5.0 for 5:00)")
    start_meridiem = fields.Selection([('AM', 'AM'), ('PM', 'PM')], string="Start AM/PM", required=True)
    end_meridiem = fields.Selection([('AM', 'AM'), ('PM', 'PM')], string="End AM/PM", required=True)

    # Computed 24-hour format
    start_time_24 = fields.Float(string="Start (24H)", compute="_compute_start_24", store=True)
    end_time_24 = fields.Float(string="End (24H)", compute="_compute_end_24", store=True)
    estimated_hours = fields.Float(string="Estimated Hours")
    task_completed = fields.Boolean(default=False)
    actual_hours = fields.Float(string="Actual Hours", compute="_compute_actual_hours", store=True)
    status = fields.Selection([('assigned', 'Assigned'), ('completed', 'Completed')], default='assigned')
    task_description = fields.Text("Task Description")
    task_progress = fields.Selection([
        ('not_started', 'Not Started'),
        ('in_progress', 'In Progress'),
        ('done', 'Done')
    ], default='not_started')


    @api.depends('start_time_24', 'end_time_24')
    def _compute_actual_hours(self):
        for rec in self:
            rec.actual_hours = rec.end_time_24 - rec.start_time_24

    state = fields.Selection([
        ('draft', 'Draft'),
        ('confirmed', 'Confirmed'),
        ('conflict', 'Conflict')
    ], default='draft', string="Status")

    @api.model
    def create(self, vals):
        employee_id = vals.get('employee_id')
        shift_start_date = vals.get('date')
        shift_end_date = vals.get('date_2')

        if employee_id and shift_start_date and shift_end_date:
            shift_start_date = fields.Date.to_date(shift_start_date)
            shift_end_date = fields.Date.to_date(shift_end_date)

            # Check if employee is on leave during any part of the shift
            leave_domain = [
                ('employee_id', '=', employee_id),
                ('state', '=', 'validate'),  # Only approved leaves
                ('request_date_from', '<=', shift_end_date),
                ('request_date_to', '>=', shift_start_date),
            ]
            overlapping_leaves = self.env['hr.leave'].search(leave_domain)

            if overlapping_leaves:
                leave_periods = ', '.join(
                    f"{l.request_date_from} to {l.request_date_to}" for l in overlapping_leaves
                )
                raise ValidationError(
                    f"Cannot assign shift on {shift_start_date} to {shift_end_date}.\n"
                    f"The employee is on leave during: {leave_periods}."
                )

        # Create shift
        res = super().create(vals)

        # Notify employee
        if res.employee_id and res.employee_id.user_id:
            res.activity_schedule(
                'mail.mail_activity_data_todo',
                user_id=res.employee_id.user_id.id,
                summary="New Shift Assigned",
                note=f"You have a new shift from {res.date} to {res.date_2}."
            )
            if res.employee_id.user_id.partner_id:
                res.employee_id.user_id.partner_id.sudo().message_post(
                    subject="New Shift Assigned",
                    body=f"Your shift from {res.date} to {res.date_2} has been scheduled.",
                    subtype_xmlid='mail.mt_comment'
                )

        # Notify manager
        if res.employee_id.parent_id and res.employee_id.parent_id.user_id:
            res.activity_schedule(
                'mail.mail_activity_data_todo',
                user_id=res.employee_id.parent_id.user_id.id,
                summary="Review Shift",
                note=f"Please review the shift assigned to your team member {res.employee_id.name}."
            )

        return res

    # Compute 24-hour start time
    @api.depends('stat_time', 'start_meridiem')
    def _compute_start_24(self):
        for rec in self:
            time = rec.stat_time
            if rec.start_meridiem == 'PM' and time < 12:
                time += 12
            elif rec.start_meridiem == 'AM' and time == 12:
                time = 0
            rec.start_time_24 = time

    # Compute 24-hour end time
    @api.depends('en_time', 'end_meridiem')
    def _compute_end_24(self):
        for rec in self:
            time = rec.en_time
            if rec.end_meridiem == 'PM' and time < 12:
                time += 12
            elif rec.end_meridiem == 'AM' and time == 12:
                time = 0
            rec.end_time_24 = time

    @api.constrains('employee_id', 'start_time_24', 'end_time_24', 'date')
    def _check_shift_conflict(self):
        for rec in self:
            if not rec.start_time_24 or not rec.end_time_24:
                continue

            if rec.start_time_24 >= rec.end_time_24:
                raise ValidationError("Start time must be earlier than end time.")

            # Use rec.date (Date field) for leave validation
            if rec.date:
                leave_domain = [
                    ('employee_id', '=', rec.employee_id.id),
                    ('state', '=', 'validate'),
                    ('request_date_from', '<=', rec.date),
                    ('request_date_to', '>=', rec.date),
                ]
                overlapping_leaves = self.env['hr.leave'].search(leave_domain)
                if overlapping_leaves:
                    leave_strs = ', '.join(
                        f"{l.request_date_from} to {l.request_date_to}" for l in overlapping_leaves
                    )
                    raise ValidationError(_(
                        "Cannot assign shift on %s.\n"
                        "Employee %s is on approved leave during: %s"
                    ) % (rec.date, rec.employee_id.name, leave_strs))

            # Conflict with other shifts
            conflicts = self.search([
                ('id', '!=', rec.id),
                ('employee_id', '=', rec.employee_id.id),
                ('date', '=', rec.date),  # Ensure same day
                ('start_time_24', '<', rec.end_time_24),
                ('end_time_24', '>', rec.start_time_24),
            ])

            if conflicts:
                rec.state = 'conflict'

                # Suggest replacement employees
                available_employees = self.env['hr.employee'].search([
                    ('id', '!=', rec.employee_id.id),
                    ('department_id', '=', rec.employee_id.department_id.id),
                    ('job_id', '=', rec.employee_id.job_id.id),
                    ('id', 'not in', self.env['hr.shift'].search([
                        ('date', '=', rec.date),
                        ('start_time_24', '<', rec.end_time_24),
                        ('end_time_24', '>', rec.start_time_24),
                    ]).mapped('employee_id.id')),
                ])

                if available_employees:
                    suggested_names = ", ".join(available_employees.mapped('name'))
                    raise ValidationError(_(
                        "Employee %s already has a conflicting shift!\n\n"
                        "Suggested replacements with same Job & Department: %s"
                    ) % (rec.employee_id.name, suggested_names))
                else:
                    raise ValidationError(_(
                        "Employee %s already has a conflicting shift!\n\n"
                        "No other employee available with the same Job & Department."
                    ) % rec.employee_id.name)

    # Suggest employees without time conflicts
    @api.model
    def suggest_alternatives(self, required_skills=None):
        employees = self.env['hr.employee'].search([])
        return employees.filtered(lambda e: not self._has_conflict(e))

    def _has_conflict(self, employee):
        return self.search_count([
            ('employee_id', '=', employee.id),
            ('start_time_24', '<', self.end_time_24),
            ('end_time_24', '>', self.start_time_24),
            ('id', '!=', self.id)
        ]) > 0

    @api.constrains('employee_id', 'date')
    def _check_leave(self):
        for rec in self:
            start_date = rec.date
            end_date = rec.date_2 or rec.date

            leave = self.env['hr.leave'].search([
                ('employee_id', '=', rec.employee_id.id),
                ('state', 'in', ['confirm', 'validate']),  # 'validate' is approved, 'confirm' is waiting
                ('request_date_from', '<=', end_date),
                ('request_date_to', '>=', start_date),
            ], limit=1)

            if leave:
                raise ValidationError(_(
                    "Cannot assign shift. %s is on leave between %s and %s."
                ) % (rec.employee_id.name, leave.request_date_from, leave.request_date_to))

    def action_confirm_shift(self):
        for rec in self:
            rec.state = 'confirmed'

    def action_mark_conflict(self):
        for rec in self:
            rec.state = 'conflict'


class ShiftAttendanceReport(models.Model):
    _name = 'shift.attendance.report'
    _description = 'Shift Attendance Report'
    # _rec_name = 'name'

    # name = fields.Char(string="Name", default=lambda self: f"Attendance Report - {date.today()}", readonly=True)
    employee_id = fields.Many2one('hr.employee', string='Employee')
    start_date = fields.Date(string="Start Date", required=True)
    end_date = fields.Date(string="End Date", required=True)
    present_days_count = fields.Integer(string="Present Days", compute='_compute_present_days', store=False)

    # present_employee_ids = fields.Many2many('hr.employee','shift_attendance_present_rel', string="Present Employees", readonly=True)
    # absent_employee_ids = fields.Many2many('hr.employee','shift_attendance_absent_rel', string="Absent Employees", readonly=True)

    @api.depends('employee_id', 'start_date', 'end_date')
    def _compute_present_days(self):
        for rec in self:
            if rec.employee_id and rec.start_date and rec.end_date:
                attendance_records = self.env['hr.attendance'].search([
                    ('employee_id', '=', rec.employee_id.id),
                    ('check_in', '>=', rec.start_date),
                    ('check_in', '<=', rec.end_date)
                ])
                unique_dates = set(att.check_in.date() for att in attendance_records if att.check_in)
                rec.present_days_count = len(unique_dates)
            else:
                rec.present_days_count = 0

    # def action_compute_attendance_summary(self):
    #     for rec in self:
    #         today = fields.Date.today()
    #         start_datetime = datetime.combine(today, time.min)
    #         end_datetime = datetime.combine(today, time.max)
    #
    #         employees = self.env['hr.employee'].search([])
    #         present = []
    #         absent = []
    #
    #         for emp in employees:
    #             attendance_exists = self.env['hr.attendance'].search_count([
    #                 ('employee_id', '=', emp.id),
    #                 ('check_in', '>=', start_datetime),
    #                 ('check_in', '<=', end_datetime),
    #             ])
    #             if attendance_exists:
    #                 present.append(emp.id)
    #             else:
    #                 absent.append(emp.id)
    #
    #         rec.present_employee_ids = [(6, 0, present)]
    #         rec.absent_employee_ids = [(6, 0, absent)]

    @api.model
    def check_missing_attendance_and_notify(self):
        today = fields.Date.today()
        employees = self.env['hr.employee'].search([
            ('active', '=', True),
            ('company_id', '=', self.env.company.id)
        ])

        for emp in employees:
            attendance = self.env['hr.attendance'].search([
                ('employee_id', '=', emp.id),
                ('check_in', '>=', datetime.combine(today, time.min)),
                ('check_in', '<=', datetime.combine(today, time.max)),
            ], limit=1)

            if not attendance:
                manager = emp.parent_id
                if manager and manager.work_email:
                    template = self.env.ref('shift_management.mail_template_attendance_alert')
                    template.sudo().send_mail(emp.id, force_send=True)


class ShiftAttendanceDailySummary(models.Model):
    _name = 'shift.attendance.daily.summary'
    _description = 'Daily Attendance Summary'
    _rec_name = 'name'

    name = fields.Char(string="Report Name", default=lambda self: f"Daily Summary - {fields.Date.today()}", readonly=True)
    present_employee_ids = fields.Many2many('hr.employee', 'shift_attendance_daily_present_rel', string="Present Employees", readonly=True)
    absent_employee_ids = fields.Many2many('hr.employee', 'shift_attendance_daily_absent_rel', string="Absent Employees", readonly=True)

    def action_compute_today_summary(self):
        today = fields.Date.today()
        start_datetime = datetime.combine(today, time.min)
        end_datetime = datetime.combine(today, time.max)

        employees = self.env['hr.employee'].search([])
        present = []
        absent = []

        for emp in employees:
            attendance_exists = self.env['hr.attendance'].search_count([
                ('employee_id', '=', emp.id),
                ('check_in', '>=', start_datetime),
                ('check_in', '<=', end_datetime),
            ])
            if attendance_exists:
                present.append(emp.id)
            else:
                absent.append(emp.id)

        self.present_employee_ids = [(6, 0, present)]
        self.absent_employee_ids = [(6, 0, absent)]

class ShiftProductivity(models.Model):
    _name = 'shift.productivity'
    _description = 'Employee Productivity Metrics'
    _auto = False

    employee_id = fields.Many2one('hr.employee', string="Employee")

    @api.model
    def _search_employee_data(self):
        employee = self.env.user.employee_id
        return self.search([('employee_id', '=', employee.id)])


class HrShiftSwap(models.Model):
    _name = 'hr.shift.swap'
    _description = 'Shift Swap Request'

    shift_id = fields.Many2one('hr.shift', string="Current Shift", required=True)
    requested_by = fields.Many2one('hr.employee', string="Requested By", required=True)
    swap_with = fields.Many2one('hr.employee', string="Swap With", required=True)
    reason = fields.Text()
    state = fields.Selection([
        ('requested', 'Requested'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected')
    ], default='requested')

    def approve_swap(self):
        for rec in self:
            rec.shift_id.employee_id = rec.swap_with
            rec.state = 'approved'


