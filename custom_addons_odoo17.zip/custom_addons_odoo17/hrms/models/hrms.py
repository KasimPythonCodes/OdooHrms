
from odoo import models, fields, api, _
from odoo.exceptions import UserError

class Hrms(models.Model):
    _name = "hrms"
    _description = "Human Resource Management System"
    _order = 'id desc'

    name = fields.Char(string="Name", required=True)
    employee_code = fields.Char(string="Employee Code")
    department = fields.Char(string="Department")
    joining_date = fields.Date(string="Joining Date")


