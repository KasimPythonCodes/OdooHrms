
{
    'name': 'Hr Payroll System',
    'version': '1.0',
    'author': 'Tech Rajendra',
    'category': 'Human Resources',
    'summary': 'Manage salary structures for different employee categories',
    'description': 'HR can define salary templates with Basic, HRA, Allowances, and Deductions for different employee categories.',
    'depends': ['base','mail','hr_recruitment','hr','hr_payroll','hr_work_entry_contract_enterprise'
                ],
    'data': [
        'security/ir.models.access.csv',
        'views/hr_payroll_configure.xml',
   ],
    'installable': True,
    'application': True,
}
