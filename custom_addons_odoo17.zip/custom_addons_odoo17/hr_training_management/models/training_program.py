from odoo import models, fields

class TrainingProgram(models.Model):
    _name = 'hr.training.program'
    _description = 'Training Program'

    name = fields.Char(string="Training Name", required=True)
    description = fields.Text(string="Description")
    category = fields.Selection([
        ('technical', 'Technical'),
        ('soft_skills', 'Soft Skills'),
        ('compliance', 'Compliance'),
        ('leadership', 'Leadership'),
    ], string="Category", required=True)
    department_id = fields.Many2one('hr.department', string="Department")
    job_id = fields.Many2one('hr.job', string="Job Role")
    skill_level = fields.Selection([
        ('beginner', 'Beginner'),
        ('intermediate', 'Intermediate'),
        ('advanced', 'Advanced')
    ], string="Skill Level")   # ✅ NEW FIELD
    duration = fields.Integer(string="Duration (Hours)")
    mode = fields.Selection([
        ('online', 'Online'),
        ('offline', 'Offline')
    ], string="Mode", required=True)
