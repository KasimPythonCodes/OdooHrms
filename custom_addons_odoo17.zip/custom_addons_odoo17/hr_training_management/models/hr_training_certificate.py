from odoo import models, fields, api
from io import BytesIO
from reportlab.pdfgen import canvas
import base64
from datetime import date
from odoo.exceptions import UserError


class HrTrainingCertificate(models.Model):
    _name = "hr.training.certificate"
    _description = "Training Certificate"
    _rec_name = "certificate_name"

    certificate_name = fields.Char(string="Certificate Name", required=True)
    employee_id = fields.Many2one('hr.employee', string="Employee", required=True)
    training_id = fields.Many2one('hr.training', string="Training", required=True)
    enrollment_id = fields.Many2one('hr.training.enrollment', string="Enrollment")
    issue_date = fields.Date(default=fields.Date.today)
    certificate_file = fields.Binary(string="Digital Certificate", attachment=True)
    certificate_filename = fields.Char(string="File Name")
    simple_certificate_file = fields.Binary("Certificate PDF", readonly=True)

    def print_simple_certificate(self):
        """Generate a simple PDF certificate for the record(s) in self."""
        for rec in self:
            buffer = BytesIO()
            c = canvas.Canvas(buffer)
            c.setFont("Helvetica-Bold", 24)
            c.drawCentredString(300, 750, "Training Completion Certificate")
            c.setFont("Helvetica", 16)
            c.drawCentredString(300, 700, "This certifies that ____________________")
            c.drawCentredString(300, 670, "has successfully completed the training")
            c.drawCentredString(300, 640, "____________________")
            c.drawCentredString(300, 610, f"on {date.today().strftime('%B %d, %Y')}.")
            c.showPage()
            c.save()

            pdf = buffer.getvalue()
            buffer.close()

            # Optionally, return base64 PDF
            rec.simple_certificate_file = base64.b64encode(pdf)


    # def generate_certificate(self):
    #     for rec in self:
    #         if not rec.employee_id:
    #             raise UserError("Cannot generate certificate: Employee is missing!")
    #         if not rec.training_id:
    #             raise UserError("Cannot generate certificate: Training is missing!")
    #
    #         pdf_file, filename = self.create_certificate_pdf(
    #             employee=rec.employee_id,
    #             training=rec.training_id
    #         )
    #
    #         cert = self.env['hr.training.certificate'].create({
    #             'certificate_name': f"Certificate - {rec.training_id.name}",
    #             'employee_id': rec.employee_id.id,
    #             'training_id': rec.training_id.id,
    #             'enrollment_id': rec.id if hasattr(rec, 'id') else False,
    #             'certificate_file': pdf_file,
    #             'certificate_filename': filename,
    #         })
    #
    #         # Attach to employee record
    #         self.env['ir.attachment'].create({
    #             'name': filename,
    #             'res_model': 'hr.employee',
    #             'res_id': rec.employee_id.id,
    #             'datas': pdf_file,
    #             'type': 'binary',
    #             'mimetype': 'application/pdf',
    #         })