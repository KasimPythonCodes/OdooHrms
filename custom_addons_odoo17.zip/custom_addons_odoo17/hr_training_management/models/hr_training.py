from odoo import models, fields, api
from odoo.exceptions import UserError


class HrTrainingCategory(models.Model):
    _name = "hr.training.category"
    _description = "Training Category"

    name = fields.Char(string="Name", required=True)


class HrTraining(models.Model):
    _name = 'hr.training'
    _description = 'Training Program'

    name = fields.Char(required=True)
    description = fields.Text()
    trainer_id = fields.Many2one('hr.employee', string="Trainer")
    duration = fields.Integer(string="Duration (Hours)")
    start_date = fields.Datetime()
    end_date = fields.Datetime()
    capacity = fields.Integer(string="Seat Capacity", default=0)
    enrolled_count = fields.Integer(string="Enrolled", compute='_compute_enrolled_count', store=True)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('confirmed', 'Confirmed'),
        ('done', 'Done'),
    ], default='draft', string='Status')
    # For offline workshop tracking
    default_sessions = fields.Integer(string="Default Total Sessions", default=1)

    @api.depends('enrollment_ids')
    def _compute_enrolled_count(self):
        for rec in self:
            rec.enrolled_count = len(rec.enrollment_ids)

    enrollment_ids = fields.One2many('hr.training.enrollment', 'training_id', string="Enrollments")
    approved_enrollment_ids = fields.One2many(
        'hr.training.enrollment',
        'training_id',
        string="Approved Enrollments",
        compute='_compute_approved_enrollments'
    )

    @api.depends('enrollment_ids.status')
    def _compute_approved_enrollments(self):
        for program in self:
            program.approved_enrollment_ids = program.enrollment_ids.filtered(lambda e: e.status == 'approved')


    def confirm_training(self):
        for rec in self:
            rec.state = 'confirmed'
