from odoo import models, fields, api
from odoo.exceptions import UserError
from odoo.exceptions import ValidationError


class HrTrainingEnrollment(models.Model):
    _name = 'hr.training.enrollment'
    _description = 'Employee Training Enrollment'
    _rec_name = 'employee_id'

    employee_id = fields.Many2one('hr.employee', string='Employee', required=True,
                                  default=lambda self: self.env.user.employee_id.id)
    training_id = fields.Many2one('hr.training', string='Training', required=True)
    status = fields.Selection([
        ('requested', 'Requested'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ], default='requested', string='Status', tracking=True)
    enrollment_date = fields.Date(string='Enrollment Date', default=fields.Date.today)

    progress = fields.Float(
        string="Progress (%)", default=0.0,
        help="Completion percentage of the enrolled training."
    )
    duration_completed = fields.Integer(string="Duration Completed(Hours)")
    # duration_of_course = fields.Integer(string="Duration of Course(Hours)")
    duration_of_course = fields.Integer(
        string="Duration of Course (Hours)",
        related='training_id.duration',  # <-- automatically takes value from training
        readonly=True
    )



    # attendance_count = fields.Integer(
    #     string="Attendance Sessions",
    #     help="Number of offline sessions attended by the employee."
    # )
    # total_sessions = fields.Integer(
    #     string="Total Sessions",
    #     help="Total planned offline sessions for this training."
    # )
    # attendance_percentage = fields.Float(
    #     string="Attendance (%)", compute="_compute_attendance_percentage", store=True
    # )
    certificate_id = fields.Many2one('hr.training.certificate', string="Certificate", readonly=True)

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            training = self.env['hr.training'].browse(vals.get('training_id'))
            # Check if capacity is zero or no seats left
            if not training.capacity or len(
                    training.enrollment_ids.filtered(lambda e: e.status == 'approved')) >= training.capacity:
                raise UserError("Cannot enroll: No seats available for this training.")
        return super().create(vals_list)

    def write(self, vals):
        res = super().write(vals)

        for rec in self:
            # If training_id is being changed, check capacity
            training = rec.training_id
            if training and (not training.capacity or len(
                    training.enrollment_ids.filtered(lambda e: e.status == 'approved')) > training.capacity):
                raise UserError("Cannot enroll: No seats available for this training.")

        # Recompute progress as before
        for rec in self:
            completed = rec.duration_completed or 0
            total = rec.duration_of_course or 0
            rec.progress = round((completed / total) * 100, 2) if total > 0 else 0.0

        return res

    def action_approve(self):
        for rec in self:
            training = rec.training_id
            if training.capacity and len(training.enrollment_ids.filtered(lambda e: e.status == 'approved')) >= training.capacity:
                raise UserError("No seats available for this training.")
            rec.status = 'approved'

    def action_reject(self):
        for rec in self:
            rec.status = 'rejected'

    @api.depends('attendance_count', 'total_sessions')
    def _compute_attendance_percentage(self):
        for rec in self:
            if rec.total_sessions > 0:
                rec.attendance_percentage = (rec.attendance_count / rec.total_sessions) * 100
            else:
                rec.attendance_percentage = 0

    def action_mark_attendance(self):
        """Call this from a button to increment attendance"""
        for rec in self:
            if rec.attendance_count < rec.total_sessions:
                rec.attendance_count += 1

    def action_compute_attendance_percentage(self):
        for rec in self:
            rec._compute_attendance_percentage()

    def action_update_progress(self, percentage):
        """Manually update progress from code or button"""
        for rec in self:
            rec.progress = min(percentage, 100)
            if rec.progress == 100:
                rec.status = 'completed'
                rec._generate_certificate()

    def _generate_certificate(self):
        """Create a certificate and attach to employee profile."""
        for rec in self:
            # Generate PDF certificate
            pdf_file, filename = self.env['hr.training.certificate'].create_certificate_pdf(
                employee=rec.employee_id,
                training=rec.training_id
            )

            # Create certificate record
            cert = self.env['hr.training.certificate'].create({
                'certificate_name': f"Certificate - {rec.training_id.name}",
                'employee_id': rec.employee_id.id,
                'training_id': rec.training_id.id,
                'enrollment_id': rec.id,
                'certificate_file': pdf_file,
                'certificate_filename': filename,
            })

            # Link certificate to enrollment
            rec.certificate_id = cert.id

            # Optional: store in employee attachments for HR access
            self.env['ir.attachment'].create({
                'name': filename,
                'res_model': 'hr.employee',
                'res_id': rec.employee_id.id,
                'datas': pdf_file,
                'type': 'binary',
                'mimetype': 'application/pdf',
            })

    def write(self, vals):
        for rec in self:
            # Determine the *new* values (if not in vals, fallback to current)
            completed = vals.get('duration_completed', rec.duration_completed) or 0
            total = vals.get('duration_of_course', rec.duration_of_course) or 0

            if total > 0:
                vals['progress'] = round((completed / total) * 100, 2)
            else:
                vals['progress'] = 0.0
        return super().write(vals)

    @api.constrains('duration_completed', 'duration_of_course')
    def _check_duration_limit(self):
        for rec in self:
            if rec.duration_of_course and rec.duration_completed > rec.duration_of_course:
                raise ValidationError(
                    "Duration Completed cannot be greater than Duration of Course."
                )