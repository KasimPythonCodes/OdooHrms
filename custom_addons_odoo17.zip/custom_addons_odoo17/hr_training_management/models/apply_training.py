from odoo import models, fields, api
from odoo.exceptions import ValidationError


class ApplyTraining(models.Model):
    _name = 'apply.training'
    _description = 'Apply Training'

    employee_id = fields.Many2one('hr.employee', string='Employee', required=True)
    training_id = fields.Many2one('hr.training', string='Training', required=True)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('applied', 'Applied'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ], default='draft', string="Status")

    def action_approve(self):
        HrEnrollment = self.env['hr.training.enrollment']  # model reference

        for rec in self:
            if not rec.employee_id or not rec.training_id:
                raise ValidationError("Employee and Training must be selected before approval.")

            # Create enrollment record
            HrEnrollment.create({
                'employee_id': rec.employee_id.id,
                'training_id': rec.training_id.id,
                'status': 'approved',
                'enrollment_date': fields.Date.today(),
            })

            # Update state of the application
            rec.state = 'approved'

    def action_reject(self):
        for rec in self:
            rec.state = 'rejected'

    def action_apply_course(self):
        for rec in self:
            rec.state = 'applied'
