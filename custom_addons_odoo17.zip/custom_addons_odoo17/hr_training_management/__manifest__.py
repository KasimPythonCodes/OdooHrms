{
    'name': 'HR Training Management',
    'version': '1.0',
    'category': 'Human Resources',
    'summary': 'Training Catalog with Skill Category, Department & Job Role',
    'depends': ['base', 'hr'],
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'views/hr_training_views.xml',
        'views/training_program_views.xml',
        'views/hr_training_enrollment_views.xml',
        'views/hr_training_certificate_views.xml',
        'views/apply_training.xml',
    ],
    'application': True,
    'installable': True,
    'license': 'LGPL-3',
}
