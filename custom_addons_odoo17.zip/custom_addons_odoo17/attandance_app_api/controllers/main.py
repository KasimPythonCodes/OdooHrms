import logging
import os.path
import pprint
import traceback
from typing import Any
from collections import defaultdict
import werkzeug
import datetime
from datetime import timedelta

from docutils.nodes import attention

from odoo import http, _, fields
from odoo.addons.test_inherit.models import res_partner
from odoo.http import request
from odoo.exceptions import ValidationError
from odoo.osv import expression
from odoo.tools.config import config
import base64
import functools
import json
import random
import uuid
import re
import time
from itertools import chain
import timeit
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT as DF
from werkzeug.exceptions import BadRequest
from odoo import api, http, SUPERUSER_ID, _
from odoo import registry as registry_get
from passlib.context import CryptContext
import jwt

global config
set_config = config.get('config')
import pytz


def detect_image_type(base64_img):
    data = base64.b64decode(base64_img)
    if data.startswith(b'\x89PNG'):
        return "png"
    if data.startswith(b'\xFF\xD8'):
        return "jpeg"
    if data.startswith(b'GIF8'):
        return "gif"
    if data.startswith(b'RIFF') and b'WEBP' in data[8:16]:
        return "webp"
    return "unknown"


class UserAuth(http.Controller):

    @http.route('/login/api', type='json', auth='none', csrf=False, cors="*", website=True)
    def login(self, **kwargs):
        resp = {}
        try:
            data = json.loads(request.httprequest.data.decode()) if request.httprequest.data else {}
            if data:
                email = data.get("email") or kwargs.get("email")
                password = data.get("password") or kwargs.get("password")
                dbname = request.env.cr.dbname
                login_creds = {'login': email, 'password': password, 'type': 'password'}

                if not email or not password:
                    resp["status"] = 400
                    resp["message"] = "Email and password are required!"
                    return resp
                uid = request.session.authenticate(dbname, login_creds)
                user = request.env['res.users'].search([('id', '=', uid.get('uid'))], limit=1)
                if uid and user:
                    data = {
                        "emp_id": uid.get('uid') or user.id,
                        "name": user.name,
                        "email": user.email,
                        "token": request.session.sid,
                    }
                    resp["status"] = 200
                    resp["message"] = "Login successfull"
                    resp['data'] = data

                    return resp
                else:
                    invalid = {"status": 401, "message": "Invalid credentials"}
                    resp['invalid'] = invalid
                    return resp
        except Exception as e:
            r1 = {"status": 500, "errorMessage": "Email or Password Do Not Match", "error": str(e)}
            resp['invalid'] = r1
        return resp

    @http.route('/logout/api', type='json', auth='user', csrf=False, cors="*")
    def logout(self, **kwargs):
        try:
            request.session.logout()

            return {
                "success": True,
                "message": "Logged out successfully"
            }

        except Exception as e:
            return {
                "success": False,
                "message": "Logout failed",
                "error": str(e)
            }


class EmployeeAPI(http.Controller):
    @http.route('/employee/profile', type='json', auth='public', csrf=False, cors="*", website=True)
    def employee_profile(self, **kwargs):
        resp = {}
        try:
            data = json.loads(request.httprequest.data.decode()) if request.httprequest.data else {}
            user = request.env['res.users'].sudo().browse(data.get('id'))
            employee = user.employee_id
            if not employee:
                resp["status"] = 404
                resp["message"] = "Employee not found for this user"
                return resp
            # Detect image type
            image_type = "No Image"
            if employee.image_1920:
                img_b64 = employee.image_1920.decode() if isinstance(employee.image_1920,
                                                                     bytes) else employee.image_1920
                image_type = detect_image_type(img_b64)
            today = datetime.datetime.now().date()
            hratt = request.env['hr.attendance'].sudo().search([
                ('employee_id', '=', employee.id),
                ('check_out', '=', False),
                ('check_in', '>=', today),
                ('check_in', '<', today + timedelta(days=1))
            ], limit=1, order='id desc')
            is_login = hratt.is_login if hratt else False
            data = {
                "employee_id": employee.id,
                "name": employee.name,
                "job_position": employee.job_title or "",
                "mobile_phone": employee.mobile_phone or "",
                "email": employee.work_email or "",
                "department": employee.department_id.name if employee.department_id else "",
                "manager": employee.parent_id.name if employee.parent_id else "",
                "team_lead": employee.coach_id.name if employee.coach_id else "",
                "image": f"/web/image/hr.employee/{employee.id}/image_1920" if employee.image_1920 else "",
                "image_type": image_type,  # ▶ ADD THIS
                "is_login": is_login,
                "gender": employee.gender,
                "birthday": employee.birthday,
            }
            resp["status"] = 200
            resp["message"] = "Employee details fetched successfully"
            resp["data"] = data
            return resp
        except Exception as e:
            resp["status"] = 500
            resp["message"] = "Something went wrong"
            resp["error"] = str(e)
            return resp

    @http.route('/check_in', type='json', auth='public', csrf=False, cors="*", website=True)
    def check_in_api(self, **kwargs):
        resp = {}
        try:
            data = json.loads(request.httprequest.data.decode()) if request.httprequest.data else {}
            user = request.env['res.users'].sudo().browse(data.get('id'))
            employee = request.env['hr.employee'].sudo().search([('user_id', '=', int(user.id))], limit=1)
            lat = round(data.get('lat'), 2)
            long = round(data.get('lon'), 2)

            if not employee:
                resp["status"] = 404
                resp["message"] = "Employee not found"
                return resp

            # Check already checked-in only for TODAY
            today = datetime.datetime.now().date()
            current_attendance = request.env['hr.attendance'].sudo().search([
                ('employee_id', '=', employee.id),
                ('check_out', '=', False),
                ('check_in', '>=', today),
                ('check_in', '<', today + timedelta(days=1))
            ], limit=1)
            current_attendance1 = request.env['hr.attendance'].sudo().search(
                [('employee_id', '=', employee.id), ('attendance_date', '=', fields.Datetime.now())], limit=1)
            if current_attendance or current_attendance1:
                resp["status"] = 409
                resp["message"] = "Already Checked-In Today"
                resp["data"] = {
                    "attendance_id": current_attendance.id,
                    "check_in": str(current_attendance.check_in)
                }
                return resp

            # Create new Check-In
            new_att = request.env['hr.attendance'].sudo().create({
                'employee_id': employee.id,
                'is_login': data.get('is_login'),
                'check_in': fields.Datetime.now(),
                'in_latitude': lat,
                'in_longitude': long
            })

            resp["status"] = 200
            resp["message"] = "Checked-In Successfully"
            resp["data"] = {
                "attendance_id": new_att.id,
                "check_in": str(new_att.check_in)
            }
            return resp

        except Exception as e:
            resp["status"] = 500
            resp["message"] = str(e)
            return resp

    @http.route('/check_out', type='json', auth='public', csrf=False, cors="*", website=True)
    def check_out_api(self, **kwargs):
        resp = {}
        try:
            """
            {
           "id":2,
           "is_login":false,
            "work_mode":"wfh",
            "attendance_type":"full_day",
            "check_out":"2025-11-06 14:00:00"
            "lat":"lat",
            "lon":"lon"
            }
            """
            data = json.loads(request.httprequest.data.decode())
            if data:
                user = request.env['res.users'].sudo().browse(data.get('id'))
                employee_id = request.env['hr.employee'].sudo().search([('user_id', '=', int(user.id))], limit=1).id
                is_login = data.get('is_login')
                # work_mode = data.get('work_mode')
                # attendance_type = data.get('attendance_type')
                check_out = data.get('check_out')
                lat = round(data.get('lat'), 2)
                long = round(data.get('lon'), 2)

                local_zone = pytz.timezone("Asia/Kolkata")
                utc_now = datetime.datetime.utcnow().replace(tzinfo=pytz.utc)
                local_now = utc_now.astimezone(local_zone)
                local_start = local_now.replace(hour=0, minute=0, second=0, microsecond=0)
                local_end = local_start + timedelta(days=1)
                utc_start = local_start.astimezone(pytz.utc)
                utc_end = local_end.astimezone(pytz.utc)
                utc_start = utc_start.astimezone(pytz.utc).replace(tzinfo=None)
                utc_end = utc_end.astimezone(pytz.utc).replace(tzinfo=None)

                # Search the attendance record safely
                current_attendance = request.env['hr.attendance'].sudo().search([
                    ('employee_id', '=', employee_id),
                    ('check_out', '=', False),
                    ('check_in', '>=', utc_start),
                    ('check_in', '<', utc_end)
                ], limit=1)
                if not current_attendance:
                    resp['status'] = 404
                    resp['message'] = "Employee Attendance Not Mark."
                    return resp

                local_zone = pytz.timezone("Asia/Kolkata")
                check_in_utc = current_attendance.check_in
                utc_zone = pytz.utc
                if check_in_utc.tzinfo is None:
                    check_in_utc = utc_zone.localize(check_in_utc)
                check_in_local = check_in_utc.astimezone(local_zone)
                check_in_str = check_in_local.strftime("%Y-%m-%d %H:%M:%S")
                check_out_str = check_out

                check_in_obj = datetime.datetime.strptime(check_in_str, "%Y-%m-%d %H:%M:%S")
                check_out_obj = datetime.datetime.strptime(check_out_str, "%Y-%m-%d %H:%M:%S")
                check_in_local = local_zone.localize(check_in_obj)
                check_out_local = local_zone.localize(check_out_obj)
                duration = check_out_local - check_in_local
                total_hours = round(duration.total_seconds() / 3600.0, 1)

                # AM/PM
                check_in_period = check_in_local.strftime("%p")
                check_out_period = check_out_local.strftime("%p")
                print("Check-In:", check_in_local.strftime("%d/%m/%Y %I:%M:%S"), check_in_period)
                print("Check-Out:", check_out_local.strftime("%d/%m/%Y %I:%M:%S"), check_out_period)
                print("Total Hours:", total_hours)
                try:
                    if not current_attendance.check_out:
                        check_in_utc = check_in_local.astimezone(pytz.utc).replace(tzinfo=None)
                        now = datetime.datetime.utcnow()
                        hours_passed = round((now - check_in_utc).total_seconds() / 3600.0, 1)
                        if int(hours_passed) >= 12:
                            panch_pass_time = check_in_local + timedelta(hours=total_hours)
                            panch_pass_time = panch_pass_time.astimezone(pytz.utc).replace(tzinfo=None)
                            current_attendance.write({
                                "check_out": panch_pass_time,
                                "is_login": is_login,
                                # "work_mode": work_mode,
                                "attendance_type": "full_day",
                                'out_latitude': lat,
                                'out_longitude': long,
                                'mark_attendance_by_sch': "Marked By App"
                            })

                            resp['status'] = 200
                            resp['message'] = "Punch Out Success"
                            vals = {
                                "check_in": check_in_str,
                                "check_out": check_out_str,
                                "is_login": current_attendance.is_login,
                                "work_mode": current_attendance.work_mode,
                                "attendance_type": current_attendance.attendance_type,
                                'out_latitude': lat,
                                'out_longitude': long,
                                "Hours": current_attendance.worked_hours,
                            }
                            resp['data'] = vals
                            return resp

                except Exception as e:
                    resp['status'] = 500
                    resp['message'] = str(e)

                interval_time = check_out_local - check_in_local
                interval_hours = round(interval_time.total_seconds() / 3600.0, 1)
                if int(interval_hours) >= 8:
                    # Full-day attendance
                    check_out_local = check_out_local.astimezone(pytz.utc).replace(tzinfo=None)

                    current_attendance.write({
                        "check_out": check_out_local,
                        "is_login": is_login,
                        # "work_mode": work_mode,
                        "attendance_type": "full_day",
                        "out_latitude": lat,
                        "out_longitude": long,
                        'mark_attendance_by_sch': "Marked By App"

                    })
                    resp['status'] = 200
                    resp['message'] = "Punch Out Success"
                    vals = {
                        "check_in": check_in_str,
                        "check_out": check_out_str,
                        "is_login": current_attendance.is_login,
                        "work_mode": current_attendance.work_mode,
                        "attendance_type": current_attendance.attendance_type,
                        'out_latitude': lat,
                        'out_longitude': long,
                        "Hours": current_attendance.worked_hours,
                    }
                    resp['data'] = vals
                    return resp

                elif (int(interval_hours) >= 1 and int(interval_hours) < 4) or int(interval_hours) == 4:
                    # Half-day attendance
                    check_out_local = check_out_local.astimezone(pytz.utc).replace(tzinfo=None)

                    current_attendance.write({
                        "check_out": check_out_local,
                        "is_login": is_login,
                        # "work_mode": work_mode,
                        "attendance_type": "half_day",
                        'out_latitude': lat,
                        'out_longitude': long,
                        'mark_attendance_by_sch': "Marked By App"

                    })
                    resp['status'] = 200
                    resp['message'] = "Punch Out Success"
                    vals = {
                        "check_in": check_in_str,
                        "check_out": check_out_str,
                        "is_login": current_attendance.is_login,
                        "work_mode": current_attendance.work_mode,
                        "attendance_type": current_attendance.attendance_type,
                        'out_latitude': lat,
                        'out_longitude': long,
                        "Hours": round(current_attendance.worked_hours, 2),
                    }
                    resp['data'] = vals
                    return resp

                elif (int(interval_hours) > 4) or int(interval_hours) >= 5:
                    # Half-day attendance
                    check_out_local = check_out_local.astimezone(pytz.utc).replace(tzinfo=None)

                    current_attendance.write({
                        "check_out": check_out_local,
                        "is_login": is_login,
                        # "work_mode": work_mode,
                        "attendance_type": "full_day",
                        'out_latitude': lat,
                        'out_longitude': long,
                        'mark_attendance_by_sch': "Marked By App"

                    })
                    resp['status'] = 200
                    resp['message'] = "Punch Out Success"
                    vals = {
                        "check_in": check_in_str,
                        "check_out": check_out_str,
                        "is_login": current_attendance.is_login,
                        "work_mode": current_attendance.work_mode,
                        "attendance_type": current_attendance.attendance_type,
                        'out_latitude': lat,
                        'out_longitude': long,
                        "Hours": round(current_attendance.worked_hours, 2),
                    }
                    resp['data'] = vals
                    return resp
                else:
                    check_out_local = check_out_local.astimezone(pytz.utc).replace(tzinfo=None)
                    current_attendance.write({
                        "check_out": check_out_local,
                        "is_login": is_login,
                        # "work_mode": work_mode,
                        "attendance_type": "absent",
                        'out_latitude': lat,
                        'out_longitude': long,
                        'today_leave_or_not': True,
                        'mark_attendance_by_sch': "Marked By App"

                    })
                    resp['status'] = 200
                    resp['message'] = "Punch Out Success"
                    vals = {
                        "check_in": check_in_str,
                        "check_out": check_out_str,
                        "is_login": current_attendance.is_login,
                        "work_mode": current_attendance.work_mode,
                        "attendance_type": current_attendance.attendance_type,
                        'out_latitude': lat,
                        'out_longitude': long,
                        "Hours": round(current_attendance.worked_hours, 2),
                    }
                    resp['data'] = vals
                    return resp
            else:
                resp['status'] = 404
                resp['message'] = "Employee Not Found!"
                return resp
        except Exception as e:
            resp['status'] = 500
            resp['message'] = str(e)
            print("jkl")
        return resp

    @http.route('/employee/attendance/count', type='json', auth='public', csrf=False, cors="*", website=True)
    def employee_attendance_count(self, **kwargs):
        resp = {}
        try:
            data = json.loads(request.httprequest.data.decode())
            if data:
                user = request.env['res.users'].sudo().browse(data.get('id'))
                employee_id = request.env['hr.employee'].sudo().search([('user_id', '=', int(user.id))], limit=1).id
                id = int(employee_id)
                from datetime import datetime, date, timedelta
                today = date.today()
                first_day = today.replace(day=1)
                # To get the first day of next month, add one month safely:
                if today.month == 12:
                    next_month = date(today.year + 1, 1, 1)
                else:
                    next_month = date(today.year, today.month + 1, 1)
                attend_fullday = request.env['hr.attendance'].sudo().search_count([
                    ('employee_id', '=', id),
                    ('check_in', '>=', first_day),
                    ('check_in', '<', next_month),
                    ('attendance_type', '=', 'full_day')
                ])

                attend_halfday = request.env['hr.attendance'].sudo().search_count([
                    ('employee_id', '=', id),
                    ('check_in', '>=', first_day),
                    ('check_in', '<', next_month),
                    ('attendance_type', '=', 'half_day')

                ])

                leave_emp = request.env['hr.attendance'].sudo().search_count([
                    ('employee_id', '=', id),
                    ('check_in', '>=', first_day),
                    ('check_in', '<', next_month),
                    ('today_leave_or_not', '=', True),
                ])

                if (attend_fullday or attend_halfday or leave_emp):
                    val = {'employee_id': id, 'fullday_attendance': attend_fullday, 'half_attendance': attend_halfday,
                           "leave_of_emp": leave_emp}
                    resp['status'] = 200
                    resp['message'] = "success"
                    resp['data'] = val
                else:
                    resp['status'] = 404
                    resp['message'] = "Attendance Not Found"
                    return resp
            else:
                resp['status'] = 404
                resp['message'] = "Attendance Not Found"
                return resp
        except Exception as e:
            resp['status'] = 500
            resp['message'] = str(e)
        return resp

    @http.route('/admin/event/api', type='json', auth='public', csrf=False, cors="*", website=True)
    def admin_event_api(self, **kwargs):
        resp = {}
        """
            user_name
            event_title
            event_img
            event_time
            event_description
          """
        try:
            allevent = request.env['event.announcement'].sudo().search([], limit=20)
            event_list = []
            if allevent:
                for val in allevent:
                    event_list.append({
                        'id': val.id,
                        'name': val.user_name,
                        'user_img': f"/web/image/event.announcement/{val.id}/user_img" if val.user_img else '',
                        'event_title': val.event_title or '',
                        'event_img': f"/web/image/event.announcement/{val.id}/event_img" if val.event_img else '',
                        'event_time': val.event_time or '',
                        'event_description': val.event_description or '',
                    })
                resp['status'] = 200
                resp['message'] = 'Event list fetched successfully'
                resp['data'] = event_list
            else:
                resp['status'] = 404
                resp['message'] = 'Event Not Found'
                resp['data'] = event_list
        except Exception as e:
            resp['status'] = 500
            resp['message'] = str(e)
        return resp

    @http.route('/attendance/marked/api', type='json', auth='public', csrf=False, cors="*", website=True)
    def attendance_marked_details(self, **kwargs):

        resp = {}

        try:

            data = json.loads(request.httprequest.data.decode())

            from datetime import datetime, date, timedelta

            today = date.today()

            first_day = today.replace(day=1)

            # To get the first day of next month, add one month safely:

            if today.month == 12:

                next_month = date(today.year + 1, 1, 1)

            else:

                next_month = date(today.year, today.month + 1, 1)

            if data:

                id = int(data.get('id')) or int(kwargs.get('id'))
                print(id, "IDIDIDIDIDIDI.............")
                user = request.env['res.users'].sudo().browse(id)
                print(user, "NEW User ++++++++++++++++++++++++")

                if user:

                    emp = request.env['hr.employee'].sudo().search([('user_id', '=', user.id)], limit=1)
                    print(emp, "EMPLOYEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE")
                    if emp:

                        if emp.attendance_ids:
                            print(emp.attendance_ids, "ATTTTTTTTTTTTTTTTTTTTTTT")
                            data = []

                            user_tz = pytz.timezone(request.env['res.users'].sudo().browse(user.id).tz)

                            attendance_ids = request.env['hr.attendance'].sudo().search([

                                ('employee_id', '=', emp.id),

                                ('check_in', '>=', first_day),

                                ('check_in', '<', next_month),

                                ('attendance_type', 'in', ['full_day', 'half_day', "", None, False])

                            ])
                            print(attendance_ids,
                                  "attendance_idsattendance_idsattendance_idsattendance_idsattendance_ids")
                            if attendance_ids:
                                print("FOR LOOP+++++++++++++++++++++++++++++++++++++++++++++")
                                for record in attendance_ids:

                                    if record.check_in:

                                        utc_checkin = record.check_in

                                        # Localize if the datetime is naive (stored in UTC without tzinfo)

                                        if utc_checkin.tzinfo is None:
                                            utc_checkin = pytz.utc.localize(utc_checkin)

                                        local_checkin = utc_checkin.astimezone(user_tz)

                                        checkin_str = local_checkin.strftime('%Y-%m-%d %H:%M:%S')

                                    else:

                                        checkin_str = ""

                                    if record.check_out:

                                        utc_checkout = record.check_out

                                        if utc_checkout.tzinfo is None:
                                            utc_checkout = pytz.utc.localize(utc_checkout)

                                        local_checkout = utc_checkout.astimezone(user_tz)

                                        checkout_str = local_checkout.strftime('%Y-%m-%d %H:%M:%S')

                                    else:

                                        checkout_str = ""

                                    date_str = record.attendance_date.strftime(
                                        '%Y-%m-%d') if record.attendance_date else ""

                                    data.append({

                                        'checkin': checkin_str,

                                        'checkout': checkout_str,

                                        'date': date_str

                                    })

                                resp['data'] = data

                            else:
                                print("1111111111111111111111111111")

                                resp['status'] = 404

                                resp['message'] = "Attendance Not Found"

                                return resp

                        else:
                            print("2222222222222222222222222222222222222222")
                            resp['status'] = 404

                            resp['message'] = "Attendance Not Found"

                            return resp

                    else:
                        print("3333333333333333333333333333333333333333333333333333333")
                        resp['status'] = 404

                        resp['message'] = "Attendance Not Found"

                        return resp

                else:
                    print("4444444444444444444444444444444444444$")
                    resp['status'] = 404

                    resp['message'] = "Attendance Not Found"

                    return resp

            else:
                print("55555555555555555555555555555555555555%%%%")
                resp['status'] = 404

                resp['message'] = "Record Not Found"

                return resp

        except Exception as e:

            resp['status'] = 500

            resp['message'] = str(e)

        return resp

    @http.route('/geofencing/calender/api', type='json', auth='public', csrf=False, cors='*', website=True)
    def calender(self, **kwargs):
        resp = {}
        try:
            data = json.loads(request.httprequest.data.decode())
            if data:
                id = int(data.get('id'))
                user = request.env['res.users'].sudo().search([('id', '=', id)], limit=1)
                if user:
                    emp = request.env['hr.employee'].sudo().search([('user_id', '=', user.id)], limit=1)
                    if emp.attendance_ids:
                        grouped_data = defaultdict(float)
                        for record in emp.attendance_ids:
                            if record.check_in and record.check_out:
                                check_in = record.check_in
                                check_out = record.check_out
                                duration = (check_out - check_in).total_seconds() / 3600.0
                                date_str = record.attendance_date.strftime(
                                    '%Y-%m-%d') if record.attendance_date else check_in.strftime('%Y-%m-%d')
                                grouped_data[date_str] += duration
                            if record.check_in and not record.check_out and record.attendance_date < datetime.datetime.now().date():
                                grouped_checkout_missign_date = record.attendance_date.strftime(
                                    '%Y-%m-%d') if record.attendance_date else check_in.strftime('%Y-%m-%d')
                                grouped_data[grouped_checkout_missign_date] = 0.0001234
                        response_data = []
                        for date_str, total_hours in grouped_data.items():
                            if total_hours >= 8:
                                leave_type = 'Full Day'
                            elif (total_hours >= 2 and total_hours < 4) or total_hours == 4:
                                leave_type = 'Half Day'
                            elif total_hours > 4 or total_hours >= 5:
                                leave_type = 'Full Day'
                            else:
                                if total_hours == 0.0001234:
                                    leave_type = 'Leave'
                                else:
                                    leave_type = 'Leave'
                            response_data.append({
                                'date': date_str,
                                'status': leave_type
                            })

                        resp['data'] = response_data
                    else:
                        resp['status'] = 404
                        resp['message'] = "Record Not Found"
                        return resp
                else:
                    resp['status'] = 404
                    resp['message'] = "Record Not Found"
                    return resp
            else:
                resp['status'] = 404
                resp['message'] = "Record Not Found"
                return resp
        except Exception as e:
            resp['status'] = 500
            resp['message'] = str(e)

        return resp

    @http.route('/run-my-cron', type='json', auth='public', csrf=False, cors='*', website=True)
    def run_my_cron(self):
        cron = request.env.ref('attandance_app_api.ir_cron_auto_checkout').sudo()
        cron.method_direct_trigger()
        return {"status": "ok", "message": "Cron executed"}

    @http.route('/upd/<int:id>', type='json', auth='public', csrf=False, cors='*', website=True)
    def upd(self,id,**kwargs):
        resp={}
        try:
            emp_id = request.env['hr.employee'].sudo().search([('user_id','=',id)],limit=1)
            local_zone = pytz.timezone("Asia/Kolkata")
            utc_now = datetime.datetime.utcnow().replace(tzinfo=pytz.utc)
            local_now = utc_now.astimezone(local_zone)
            local_start = local_now.replace(hour=0, minute=0, second=0, microsecond=0)
            local_end = local_start + timedelta(days=1)
            utc_start = local_start.astimezone(pytz.utc)
            utc_end = local_end.astimezone(pytz.utc)
            utc_start = utc_start.astimezone(pytz.utc).replace(tzinfo=None)
            utc_end = utc_end.astimezone(pytz.utc).replace(tzinfo=None)
            data = json.loads(request.httprequest.data.decode())

            if not emp_id.exists():
                resp['status']=400
                resp['message']="Employee not found!"
                return resp
            if emp_id.id:
                attnd = request.env['hr.attendance'].sudo().search([
                    ('employee_id', '=', emp_id.id),
                    ('check_out', '=', False),
                    ('check_in', '>=', utc_start),
                    ('check_in', '<', utc_end)
                ], limit=1)
                if attnd:
                    attnd.write({
                        "check_out":data.get('check_out')
                    })
                    resp['status']=200
                    resp['message']="success"
                    return resp
        except Exception as e:
            resp['message']="Error During Attendance Update!"
            resp['status']=['500']
            resp['MessageError']=str(e)
        return resp
